package com.example.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.example.model.ServiceRequest.RequestData;
import com.example.model.ServiceResponse.ResponseData;
import com.example.model.unblockcard.UnBlockCardResponse;
import com.example.model.unblockcard.unBlockRequest.UnBlockRequest;
import com.example.service.RestSSLService;


@RestController
@RequestMapping("/v1")
public class RestSSLControler {
	private static final Logger log = LoggerFactory.getLogger(RestSSLControler.class);
	UnBlockCardResponse response = null;
	ResponseData responseData = null;
	@Autowired
	RestSSLService service;
	
	
	@RequestMapping(value = "/customers/card/block", method = RequestMethod.POST)
	public ResponseData blockCard(@RequestBody RequestData req){
		
		ResponseData data  = service.blockCard(req);	
		log.info("Return data ::::." +  data);
		return data;
	}
	
	@RequestMapping(value = "/customers/card/unblock", method = RequestMethod.POST)
	public UnBlockCardResponse unBlockCard(@RequestBody UnBlockRequest req){
		response = new UnBlockCardResponse();
		UnBlockCardResponse response  = service.unBlockCard(req);		
		
		return response;
	}
}
