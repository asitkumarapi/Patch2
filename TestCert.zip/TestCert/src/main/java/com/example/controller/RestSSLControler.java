package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.ServiceResponse.ResponseData;
import com.example.service.RestSSLService;


@RestController
public class RestSSLControler {

	@Autowired
	RestSSLService service;
	
	
	@RequestMapping(value = "/block", method = RequestMethod.POST)
	public ResponseData blockCard(){
		
		ResponseData data  = service.blockCard();		
		return data;
	}
}
