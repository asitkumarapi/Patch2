package com.example.model.ServiceResponse;

public class ResponseData {

	public EWOEW2XLOperationResponse EWOEW2XLOperationResponse;

    public EWOEW2XLOperationResponse getEWOEW2XLOperationResponse ()
    {
        return EWOEW2XLOperationResponse;
    }

    public void setEWOEW2XLOperationResponse (EWOEW2XLOperationResponse EWOEW2XLOperationResponse)
    {
        this.EWOEW2XLOperationResponse = EWOEW2XLOperationResponse;
    }

    /*@Override
    public String toString()
    {
        return "ClassPojo [EWOEW2XLOperationResponse = "+EWOEW2XLOperationResponse+"]";
    }*/
}
