package com.example.model.ServiceResponse;

public class ResponseData {

	private EWOEW2XMOperationResponse EWOEW2XMOperationResponse;

    public EWOEW2XMOperationResponse getEWOEW2XMOperationResponse ()
    {
        return EWOEW2XMOperationResponse;
    }

    public void setEWOEW2XMOperationResponse (EWOEW2XMOperationResponse EWOEW2XMOperationResponse)
    {
        this.EWOEW2XMOperationResponse = EWOEW2XMOperationResponse;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [EWOEW2XMOperationResponse = "+EWOEW2XMOperationResponse+"]";
    }
}
