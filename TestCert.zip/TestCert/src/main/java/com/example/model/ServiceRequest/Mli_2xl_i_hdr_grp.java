package com.example.model.ServiceRequest;

public class Mli_2xl_i_hdr_grp {

	public String mli_2xl_i_message_id;

	public String mli_2xl_i_version_nbr;

	public String mli_2xl_i_terminal_id;

	public String mli_2xl_i_user_id;

	public String mli_2xl_i_timestamp;

	public String mli_2xl_i_org;

	public String mli_2xl_i_card_nbr;

	public String mli_2xl_i_ovc_cd;

	public String mli_2xl_i_ovc_pur_days;

    public void setMli_2xl_i_message_id(String mli_2xl_i_message_id){
        this.mli_2xl_i_message_id = mli_2xl_i_message_id;
    }
    public String getMli_2xl_i_message_id(){
        return this.mli_2xl_i_message_id;
    }
    public void setMli_2xl_i_version_nbr(String mli_2xl_i_version_nbr){
        this.mli_2xl_i_version_nbr = mli_2xl_i_version_nbr;
    }
    public String getMli_2xl_i_version_nbr(){
        return this.mli_2xl_i_version_nbr;
    }
    public void setMli_2xl_i_terminal_id(String mli_2xl_i_terminal_id){
        this.mli_2xl_i_terminal_id = mli_2xl_i_terminal_id;
    }
    public String getMli_2xl_i_terminal_id(){
        return this.mli_2xl_i_terminal_id;
    }
    public void setMli_2xl_i_user_id(String mli_2xl_i_user_id){
        this.mli_2xl_i_user_id = mli_2xl_i_user_id;
    }
    public String getMli_2xl_i_user_id(){
        return this.mli_2xl_i_user_id;
    }
    public void setMli_2xl_i_timestamp(String mli_2xl_i_timestamp){
        this.mli_2xl_i_timestamp = mli_2xl_i_timestamp;
    }
    public String getMli_2xl_i_timestamp(){
        return this.mli_2xl_i_timestamp;
    }
    public void setMli_2xl_i_org(String mli_2xl_i_org){
        this.mli_2xl_i_org = mli_2xl_i_org;
    }
    public String getMli_2xl_i_org(){
        return this.mli_2xl_i_org;
    }
    public void setMli_2xl_i_card_nbr(String mli_2xl_i_card_nbr){
        this.mli_2xl_i_card_nbr = mli_2xl_i_card_nbr;
    }
    public String getMli_2xl_i_card_nbr(){
        return this.mli_2xl_i_card_nbr;
    }
    public void setMli_2xl_i_ovc_cd(String mli_2xl_i_ovc_cd){
        this.mli_2xl_i_ovc_cd = mli_2xl_i_ovc_cd;
    }
    public String getMli_2xl_i_ovc_cd(){
        return this.mli_2xl_i_ovc_cd;
    }
    public void setMli_2xl_i_ovc_pur_days(String mli_2xl_i_ovc_pur_days){
        this.mli_2xl_i_ovc_pur_days = mli_2xl_i_ovc_pur_days;
    }
    public String getMli_2xl_i_ovc_pur_days(){
        return this.mli_2xl_i_ovc_pur_days;
    }
}
