package com.example.model.ServiceResponse;

public class EWOEW2XMOperationResponse {

	private Mli_2xm_o_area mli_2xm_o_area;

    public Mli_2xm_o_area getMli_2xm_o_area ()
    {
        return mli_2xm_o_area;
    }

    public void setMli_2xm_o_area (Mli_2xm_o_area mli_2xm_o_area)
    {
        this.mli_2xm_o_area = mli_2xm_o_area;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [mli_2xm_o_area = "+mli_2xm_o_area+"]";
    }
}
