package com.example.model.unblockcard.unBlockRequest;

public class Mli_2xm_i_hdr_grp {

	public String mli_2xm_i_message_id;

	public String mli_2xm_i_version_nbr;

	public String mli_2xm_i_terminal_id;

	public String mli_2xm_i_user_id;

	public String mli_2xm_i_timestamp;

	public String mli_2xm_i_org;

	public String mli_2xm_i_card_nbr;

    public void setMli_2xm_i_message_id(String mli_2xm_i_message_id){
        this.mli_2xm_i_message_id = mli_2xm_i_message_id;
    }
    public String getMli_2xm_i_message_id(){
        return this.mli_2xm_i_message_id;
    }
    public void setMli_2xm_i_version_nbr(String mli_2xm_i_version_nbr){
        this.mli_2xm_i_version_nbr = mli_2xm_i_version_nbr;
    }
    public String getMli_2xm_i_version_nbr(){
        return this.mli_2xm_i_version_nbr;
    }
    public void setMli_2xm_i_terminal_id(String mli_2xm_i_terminal_id){
        this.mli_2xm_i_terminal_id = mli_2xm_i_terminal_id;
    }
    public String getMli_2xm_i_terminal_id(){
        return this.mli_2xm_i_terminal_id;
    }
    public void setMli_2xm_i_user_id(String mli_2xm_i_user_id){
        this.mli_2xm_i_user_id = mli_2xm_i_user_id;
    }
    public String getMli_2xm_i_user_id(){
        return this.mli_2xm_i_user_id;
    }
    public void setMli_2xm_i_timestamp(String mli_2xm_i_timestamp){
        this.mli_2xm_i_timestamp = mli_2xm_i_timestamp;
    }
    public String getMli_2xm_i_timestamp(){
        return this.mli_2xm_i_timestamp;
    }
    public void setMli_2xm_i_org(String mli_2xm_i_org){
        this.mli_2xm_i_org = mli_2xm_i_org;
    }
    public String getMli_2xm_i_org(){
        return this.mli_2xm_i_org;
    }
    public void setMli_2xm_i_card_nbr(String mli_2xm_i_card_nbr){
        this.mli_2xm_i_card_nbr = mli_2xm_i_card_nbr;
    }
    public String getMli_2xm_i_card_nbr(){
        return this.mli_2xm_i_card_nbr;
    }

}
