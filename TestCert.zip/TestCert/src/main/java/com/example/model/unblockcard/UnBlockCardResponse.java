package com.example.model.unblockcard;

public class UnBlockCardResponse {

	public EWOEW2XMOperationResponse EWOEW2XMOperationResponse;

    public void setEWOEW2XMOperationResponse(EWOEW2XMOperationResponse EWOEW2XMOperationResponse){
        this.EWOEW2XMOperationResponse = EWOEW2XMOperationResponse;
    }
    public EWOEW2XMOperationResponse getEWOEW2XMOperationResponse(){
        return this.EWOEW2XMOperationResponse;
    }
}
