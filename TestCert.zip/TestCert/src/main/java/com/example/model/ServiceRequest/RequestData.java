package com.example.model.ServiceRequest;

public class RequestData {

	private EWOEW2XLOperation EWOEW2XLOperation;

    public EWOEW2XLOperation getEWOEW2XLOperation ()
    {
        return EWOEW2XLOperation;
    }

    public void setEWOEW2XLOperation (EWOEW2XLOperation EWOEW2XLOperation)
    {
        this.EWOEW2XLOperation = EWOEW2XLOperation;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [EWOEW2XLOperation = "+EWOEW2XLOperation+"]";
    }
}
