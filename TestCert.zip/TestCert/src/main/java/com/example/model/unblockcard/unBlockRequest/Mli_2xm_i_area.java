package com.example.model.unblockcard.unBlockRequest;

public class Mli_2xm_i_area {

	public Mli_2xm_i_hdr_grp mli_2xm_i_hdr_grp;

    public void setMli_2xm_i_hdr_grp(Mli_2xm_i_hdr_grp mli_2xm_i_hdr_grp){
        this.mli_2xm_i_hdr_grp = mli_2xm_i_hdr_grp;
    }
    public Mli_2xm_i_hdr_grp getMli_2xm_i_hdr_grp(){
        return this.mli_2xm_i_hdr_grp;
    }
}
