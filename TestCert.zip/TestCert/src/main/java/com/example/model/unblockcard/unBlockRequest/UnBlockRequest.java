package com.example.model.unblockcard.unBlockRequest;

public class UnBlockRequest {

	public EWOEW2XMOperation EWOEW2XMOperation;

    public void setEWOEW2XMOperation(EWOEW2XMOperation EWOEW2XMOperation){
        this.EWOEW2XMOperation = EWOEW2XMOperation;
    }
    public EWOEW2XMOperation getEWOEW2XMOperation(){
        return this.EWOEW2XMOperation;
    }
}
