package com.example.model.ServiceResponse;

public class Mli_2xm_o_area {

	private Mli_2xm_o_hdr_grp mli_2xm_o_hdr_grp;

    public Mli_2xm_o_hdr_grp getMli_2xm_o_hdr_grp ()
    {
        return mli_2xm_o_hdr_grp;
    }

    public void setMli_2xm_o_hdr_grp (Mli_2xm_o_hdr_grp mli_2xm_o_hdr_grp)
    {
        this.mli_2xm_o_hdr_grp = mli_2xm_o_hdr_grp;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [mli_2xm_o_hdr_grp = "+mli_2xm_o_hdr_grp+"]";
    }
}
