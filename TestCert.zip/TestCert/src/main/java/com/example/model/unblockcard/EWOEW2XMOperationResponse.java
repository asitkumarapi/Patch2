package com.example.model.unblockcard;

public class EWOEW2XMOperationResponse {

	public Mli_2xm_o_area mli_2xm_o_area;

    public void setMli_2xm_o_area(Mli_2xm_o_area mli_2xm_o_area){
        this.mli_2xm_o_area = mli_2xm_o_area;
    }
    public Mli_2xm_o_area getMli_2xm_o_area(){
        return this.mli_2xm_o_area;
    }
}
