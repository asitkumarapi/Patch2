package com.example.model.ServiceResponse;

public class EWOEW2XLOperationResponse {

	public Mli_2xl_o_area mli_2xl_o_area;

    public Mli_2xl_o_area getMli_2xl_o_area ()
    {
        return mli_2xl_o_area;
    }

    public void setMli_2xl_o_area (Mli_2xl_o_area mli_2xl_o_area)
    {
        this.mli_2xl_o_area = mli_2xl_o_area;
    }

    /*@Override
    public String toString()
    {
        return "ClassPojo [mli_2xl_o_area = "+mli_2xl_o_area+"]";
    }*/
}
