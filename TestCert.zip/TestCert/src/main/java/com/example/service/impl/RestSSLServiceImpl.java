package com.example.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.Socket;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.Security;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509ExtendedTrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.model.ServiceRequest.RequestData;
import com.example.model.ServiceResponse.ResponseData;
import com.example.service.RestSSLService;

@Service
public class RestSSLServiceImpl implements RestSSLService {

private static final Logger log = LoggerFactory.getLogger(RestSSLServiceImpl.class);
	
	/*@Value("${server.ssl.key-store-password}")
	private String keyStorePassword;
	@Value("${server.ssl.key-store-type}")
	private String keyStoreType;
	@Value("${server.ssl.key-store}")
	private Resource keyStoreLocation;
	
	
	private String serviceAPI = "https://mt01vip1.mt01.mex.nsroot.net:10443/v1/card/afews/blkOvcAtch";
	HttpClient httpClient = null;
	HttpComponentsClientHttpRequestFactory requestFactory = null;
	RestTemplate rt = null;
	KeyStore keyStore = null;
	
	public RestTemplate getRestTemplate(){
		
		try {
			keyStore = KeyStore.getInstance("PKCS12");
			log.info("########### keyStore");
			log.info("########### keyStore " + keyStoreLocation.getFilename());
			log.info("########### keyStore " + keyStorePassword);
				keyStore.load(new FileInputStream(new File(keyStoreLocation.getFilename())), keyStorePassword.toCharArray());
			
		
			SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(
			        new SSLContextBuilder()
			                .loadTrustMaterial(null, new TrustSelfSignedStrategy())
			                .loadKeyMaterial(keyStore, keyStorePassword.toCharArray())
			                .build(),
			        NoopHostnameVerifier.INSTANCE);
		
			httpClient = HttpClients.custom().setSSLSocketFactory(socketFactory).build();

	    requestFactory = new HttpComponentsClientHttpRequestFactory();
	    requestFactory.setHttpClient(httpClient);
		} catch (CertificateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (KeyManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnrecoverableKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (KeyStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     return new RestTemplate(requestFactory);
	}*/
@Autowired
RestTemplate rt;

	@Override
	public ResponseData blockCard() {
		//enableSSL();
		
		/*rt = new RestTemplate();
		rt = getRestTemplate();
		
		RequestData data = new RequestData();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type","application/json");
		
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		
		ResponseEntity<ResponseData> serviceResp = rt.exchange(serviceAPI, HttpMethod.POST,entity,ResponseData.class,data);
		
		return serviceResp.getBody();*/
		String serviceAPI = "https://mt01vip1.mt01.mex.nsroot.net:10443/v1/card/afews/blkOvcAtch";
		RequestData data = new RequestData();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type","application/json");
		
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		
		ResponseEntity<ResponseData> serviceResp = rt.exchange(serviceAPI, HttpMethod.POST,entity,ResponseData.class,data);
		
		return serviceResp.getBody();
	}

}
