package com.example.service.impl;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.model.ServiceRequest.RequestData;
import com.example.model.ServiceResponse.ResponseData;
import com.example.model.unblockcard.UnBlockCardResponse;
import com.example.model.unblockcard.unBlockRequest.UnBlockRequest;
import com.example.service.RestSSLService;

@Service
public class RestSSLServiceImpl implements RestSSLService {

private static final Logger log = LoggerFactory.getLogger(RestSSLServiceImpl.class);	
String blockService = "https://mt01vip1.mt01.mex.nsroot.net:10443/v1/card/afews/blkOvcAtch";
String unBlockService = "https://mt01vip1.mt01.mex.nsroot.net:10443/v1/card/afews/blkOvcDtch";
@Autowired
RestTemplate rt;

	@Override
	public ResponseData blockCard(RequestData data) {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type","application/json");
		log.info("enter !!!!!!!!!");
		
		JSONObject jObject2  = new JSONObject();
		JSONObject jObject3  = new JSONObject();
		JSONObject jObject4  = new JSONObject();
		JSONObject jObject  = new JSONObject();
		//log.info("Payaload data ::::" + data.getEWOEW2XLOperation().getMli_2xl_i_area().getMli_2xl_i_hdr_grp().getMli_2xl_i_message_id());
		try {
			jObject.put("mli_2xl_i_message_id",data.getEWOEW2XLOperation().getMli_2xl_i_area().getMli_2xl_i_hdr_grp().getMli_2xl_i_message_id());
			 jObject.put("mli_2xl_i_version_nbr", data.getEWOEW2XLOperation().getMli_2xl_i_area().getMli_2xl_i_hdr_grp().getMli_2xl_i_version_nbr());
			    jObject.put("mli_2xl_i_terminal_id", data.getEWOEW2XLOperation().getMli_2xl_i_area().getMli_2xl_i_hdr_grp().getMli_2xl_i_terminal_id());
			    jObject.put("mli_2xl_i_user_id", data.getEWOEW2XLOperation().getMli_2xl_i_area().getMli_2xl_i_hdr_grp().getMli_2xl_i_user_id());
			    jObject.put("mli_2xl_i_timestamp", data.getEWOEW2XLOperation().getMli_2xl_i_area().getMli_2xl_i_hdr_grp().getMli_2xl_i_timestamp());
			    jObject.put("mli_2xl_i_org", data.getEWOEW2XLOperation().getMli_2xl_i_area().getMli_2xl_i_hdr_grp().getMli_2xl_i_org());
			    jObject.put("mli_2xl_i_card_nbr", data.getEWOEW2XLOperation().getMli_2xl_i_area().getMli_2xl_i_hdr_grp().getMli_2xl_i_card_nbr());
			    jObject.put("mli_2xl_i_ovc_cd", data.getEWOEW2XLOperation().getMli_2xl_i_area().getMli_2xl_i_hdr_grp().getMli_2xl_i_ovc_cd());
			    jObject.put("mli_2xl_i_ovc_pur_days", data.getEWOEW2XLOperation().getMli_2xl_i_area().getMli_2xl_i_hdr_grp().getMli_2xl_i_ovc_pur_days());
			    jObject4.put("mli_2xl_i_hdr_grp", jObject);
			    jObject3.put("mli_2xl_i_area", jObject4);	    
			    jObject2.put("EWOEW2XLOperation", jObject3);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   
	    
		HttpEntity<?> entity = new HttpEntity<>(jObject2.toString(), headers);
		ResponseEntity<ResponseData> serviceResp = rt.exchange(blockService, HttpMethod.POST,entity,ResponseData.class);
		
		log.info("Response ///////// " + serviceResp.getBody());
		return serviceResp.getBody();
	}

	@Override
	public UnBlockCardResponse unBlockCard(UnBlockRequest data) {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type","application/json");
		log.info("enter !!!!!!!!!");
		JSONObject jObject2  = new JSONObject();
		JSONObject jObject3  = new JSONObject();
		JSONObject jObject4  = new JSONObject();
		JSONObject jObject  = new JSONObject();
		try {
			jObject.put("mli_2xm_i_message_id",data.getEWOEW2XMOperation().getMli_2xm_i_area().getMli_2xm_i_hdr_grp().getMli_2xm_i_message_id());
			 jObject.put("mli_2xm_i_version_nbr", data.getEWOEW2XMOperation().getMli_2xm_i_area().getMli_2xm_i_hdr_grp().getMli_2xm_i_version_nbr());
			    jObject.put("mli_2xm_i_terminal_id", data.getEWOEW2XMOperation().getMli_2xm_i_area().getMli_2xm_i_hdr_grp().getMli_2xm_i_terminal_id());
			    jObject.put("mli_2xm_i_user_id", data.getEWOEW2XMOperation().getMli_2xm_i_area().getMli_2xm_i_hdr_grp().getMli_2xm_i_user_id());
			    jObject.put("mli_2xm_i_timestamp", data.getEWOEW2XMOperation().getMli_2xm_i_area().getMli_2xm_i_hdr_grp().getMli_2xm_i_timestamp());
			    jObject.put("mli_2xm_i_org", data.getEWOEW2XMOperation().getMli_2xm_i_area().getMli_2xm_i_hdr_grp().getMli_2xm_i_org());
			    jObject.put("mli_2xm_i_card_nbr", data.getEWOEW2XMOperation().getMli_2xm_i_area().getMli_2xm_i_hdr_grp().getMli_2xm_i_card_nbr());
			    jObject4.put("mli_2xm_i_hdr_grp", jObject);
			    jObject3.put("mli_2xm_i_area", jObject4);	    
			    jObject2.put("EWOEW2XMOperation", jObject3);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	   
	    
		HttpEntity<?> entity = new HttpEntity<>(jObject2.toString(), headers);
		ResponseEntity<UnBlockCardResponse> serviceResp1 = rt.exchange(unBlockService, HttpMethod.POST,entity,UnBlockCardResponse.class);
		log.info("Unblock card Response ///////// " + serviceResp1.getBody());
		return serviceResp1.getBody();
	}

}
