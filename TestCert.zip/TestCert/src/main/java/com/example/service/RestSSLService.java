package com.example.service;

import com.example.model.ServiceRequest.RequestData;
import com.example.model.ServiceResponse.ResponseData;
import com.example.model.unblockcard.UnBlockCardResponse;
import com.example.model.unblockcard.unBlockRequest.UnBlockRequest;


public interface RestSSLService {

	public ResponseData blockCard(RequestData data);
	public UnBlockCardResponse unBlockCard(UnBlockRequest data);
}
