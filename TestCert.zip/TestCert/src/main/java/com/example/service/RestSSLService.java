package com.example.service;

import com.example.model.ServiceResponse.ResponseData;


public interface RestSSLService {

	public ResponseData blockCard();
}
