package com.citibanamex.api.cards.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;



public class RequestJson {

	public final GBOF0003Operation gBOF0003Operation;

    @JsonCreator
    public RequestJson(@JsonProperty("gBOF0003Operation") GBOF0003Operation gBOF0003Operation){
        this.gBOF0003Operation = gBOF0003Operation;
    }

    public static final class GBOF0003Operation {
        public final GetRelationshipAcctReq getRelationshipAcctReq;

        @JsonCreator
        public GBOF0003Operation(@JsonProperty("getRelationshipAcctReq") GetRelationshipAcctReq getRelationshipAcctReq){
            this.getRelationshipAcctReq = getRelationshipAcctReq;
        }

        public static final class GetRelationshipAcctReq {
            public final String requestMessageId;
            public final long requestVersionNumber;
            public final String requestTerminalId;
            public final String requestUserId;
            public final String requestDateTime;
            public final String requestChannelInd;
            public final String requestCustomerOrg;
            public final String requestRelationshipNumber;
    
            @JsonCreator
            public GetRelationshipAcctReq(@JsonProperty("requestMessageId") String requestMessageId, @JsonProperty("requestVersionNumber") long requestVersionNumber, @JsonProperty("requestTerminalId") String requestTerminalId, @JsonProperty("requestUserId") String requestUserId, @JsonProperty("requestDateTime") String requestDateTime, @JsonProperty("requestChannelInd") String requestChannelInd, @JsonProperty("requestCustomerOrg") String requestCustomerOrg, @JsonProperty("requestRelationshipNumber") String requestRelationshipNumber){
                this.requestMessageId = requestMessageId;
                this.requestVersionNumber = requestVersionNumber;
                this.requestTerminalId = requestTerminalId;
                this.requestUserId = requestUserId;
                this.requestDateTime = requestDateTime;
                this.requestChannelInd = requestChannelInd;
                this.requestCustomerOrg = requestCustomerOrg;
                this.requestRelationshipNumber = requestRelationshipNumber;
            }
        }
    }
}
