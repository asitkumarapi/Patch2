package com.citibanamex.api.cards.model.cardlistresp;

import java.util.ArrayList;

public class CardResponse {

	private ArrayList<Cards> cards;
	private String status;

	public CardResponse() {
		super();
	}

	public ArrayList<Cards> getCards() {
		return this.cards;
	}

	public void setCards(ArrayList<Cards> cards) {
		this.cards = cards;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
}
