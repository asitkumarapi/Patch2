package com.citibanamex.api.cards.model.cardlistreq;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CardListPayload {

	 @JsonProperty("GBOF0003Operation")
	    private Gbof0003operation gbof0003operation;
	    public void setGbof0003operation(Gbof0003operation gbof0003operation) {
	         this.gbof0003operation = gbof0003operation;
	     }
	     public Gbof0003operation getGbof0003operation() {
	         return gbof0003operation;
	     }
}
