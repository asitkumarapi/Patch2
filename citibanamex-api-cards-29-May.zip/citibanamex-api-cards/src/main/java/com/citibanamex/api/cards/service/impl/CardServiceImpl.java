/**
 * 
 */
package com.citibanamex.api.cards.service.impl;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;

import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.citibanamex.api.cards.model.cardlistreq.CardListPayload;
import com.citibanamex.api.cards.model.cardlistreq.Gbof0003operation;
import com.citibanamex.api.cards.model.cardlistreq.Getrelationshipacctreq;
import com.citibanamex.api.cards.model.cardlistresp.AccountInfoTable;
import com.citibanamex.api.cards.model.cardlistresp.CardResponse;
import com.citibanamex.api.cards.model.cardlistresp.Cards;
import com.citibanamex.api.cards.model.cardlistresp.CreditCardAccounts;
import com.citibanamex.api.cards.model.cardlistresp.CreditCardResponse;
import com.citibanamex.api.cards.model.cardlistresp.OperationResponse;
import com.citibanamex.api.cards.aggregator.CardServiceAggregator;
import com.citibanamex.api.cards.exception.Error;
import com.citibanamex.api.cards.exception.Errors;
import com.citibanamex.api.cards.model.Constant;
import com.citibanamex.api.cards.service.CardService;
import com.netflix.hystrix.HystrixCommandProperties;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

/**
 * @author Asit Samantray Service implementation to retrive list of of credit
 *         cards based on customer relationship number.
 *
 */
@Service
//public class CardServiceImpl implements CardService{
public class CardServiceImpl{

	@Autowired
	private CardServiceAggregator cardService;
	
	public static final Logger logger = LoggerFactory.getLogger(CardServiceImpl.class);
	// @value("${client.url}")
	// private String url;
	RestTemplate restTemplate = null;
	CreditCardResponse CCResponse = null;
	CardResponse cardResp = null;
	CreditCardAccounts creditCardAcc = null;
	ArrayList<CreditCardAccounts> creditCard = null;
	ArrayList<Cards> cards = null;
	Cards cardObject = null;
	String timeStamp = null;

	CardListPayload payload = null;
	Gbof0003operation operation = null;
	Getrelationshipacctreq req = null;

	CardResponse cardStatus = null;
	List<AccountInfoTable> accounts = null;
	HttpHeaders headers = null;	
	public ResponseEntity<?> executeService(String custRelNbr, Map<String, String> data)
			throws JSONException, DatatypeConfigurationException {
		Object objResponse = null;
		objResponse = cardService
				.getCardsByCustomer(custRelNbr, data).getBody();
		// return cardResp;
		return new ResponseEntity<>(objResponse, HttpStatus.OK);
	}
	
	Errors errors = null;
	Error error = null;
	ArrayList<Error> errorList = null;
	
	//Hystrix fallback method call
	public ResponseEntity<?> fallbackGetCards(String custRelNbr, Map<String, String> data, Throwable t) {
		System.out.println("Inside fallback method..");
		//String status = "fail" + t.toString();
		errors = new Errors();
		error = new Error();
		error.setType("Error");
		error.setCode(String.valueOf(HttpStatus.NOT_FOUND.value()));
		error.setDetails(HttpStatus.NOT_FOUND.name());
		error.setLocation("");
		error.setMoreInfo("Back-end service is down");
		errorList = new ArrayList<Error>();
		errorList.add(error);
		errors.setErrors(errorList);
		return new ResponseEntity<Errors>(errors, null, HttpStatus.NOT_FOUND);
		//throw new RuntimeException("throwing exception in fallback method.");
	}
	
	private static void disableSslVerification() {
		try {
			// Create a trust manager that does not validate certificate chains

			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				public void checkClientTrusted(X509Certificate[] certs, String authType) {
				}

				public void checkServerTrusted(X509Certificate[] certs, String authType) {
				}
			} };

			// Install the all-trusting trust manager
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

			// Create all-trusting host name verifier
			HostnameVerifier allHostsValid = new HostnameVerifier() {

				@Override
				public boolean verify(String arg0, SSLSession arg1) {
					return true;
				}

			};
			// Install the all-trusting host verifier
			HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (KeyManagementException e) {
			e.printStackTrace();
		}
	}

}
