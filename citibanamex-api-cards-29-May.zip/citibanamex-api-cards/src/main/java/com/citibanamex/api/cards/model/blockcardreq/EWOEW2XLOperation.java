package com.citibanamex.api.cards.model.blockcardreq;

public class EWOEW2XLOperation {

	private Mli_2xl_i_area mli_2xl_i_area;

    
	public EWOEW2XLOperation() {
		super();
	}

	public Mli_2xl_i_area getMli_2xl_i_area ()
    {
        return mli_2xl_i_area;
    }

    public void setMli_2xl_i_area (Mli_2xl_i_area mli_2xl_i_area)
    {
        this.mli_2xl_i_area = mli_2xl_i_area;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [mli_2xl_i_area = "+mli_2xl_i_area+"]";
    }
}
