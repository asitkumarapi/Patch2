package com.citibanamex.api.cards.model;

public class ResponseNextKey {

	public int responseBsNextOrg;
	public String responseBsNextAccount;
    public int responseEdNextOrg;
    public String responseEdNextCard;
    public int responseEdNextSequence;
    /**
	 * @return the responseBsNextOrg
	 */
	public int getResponseBsNextOrg() {
		return responseBsNextOrg;
	}
	/**
	 * @param responseBsNextOrg the responseBsNextOrg to set
	 */
	public void setResponseBsNextOrg(int responseBsNextOrg) {
		this.responseBsNextOrg = responseBsNextOrg;
	}
	/**
	 * @return the responseBsNextAccount
	 */
	public String getResponseBsNextAccount() {
		return responseBsNextAccount;
	}
	/**
	 * @param responseBsNextAccount the responseBsNextAccount to set
	 */
	public void setResponseBsNextAccount(String responseBsNextAccount) {
		this.responseBsNextAccount = responseBsNextAccount;
	}
	/**
	 * @return the responseEdNextOrg
	 */
	public int getResponseEdNextOrg() {
		return responseEdNextOrg;
	}
	/**
	 * @param responseEdNextOrg the responseEdNextOrg to set
	 */
	public void setResponseEdNextOrg(int responseEdNextOrg) {
		this.responseEdNextOrg = responseEdNextOrg;
	}
	/**
	 * @return the responseEdNextCard
	 */
	public String getResponseEdNextCard() {
		return responseEdNextCard;
	}
	/**
	 * @param responseEdNextCard the responseEdNextCard to set
	 */
	public void setResponseEdNextCard(String responseEdNextCard) {
		this.responseEdNextCard = responseEdNextCard;
	}
	/**
	 * @return the responseEdNextSequence
	 */
	public int getResponseEdNextSequence() {
		return responseEdNextSequence;
	}
	/**
	 * @param responseEdNextSequence the responseEdNextSequence to set
	 */
	public void setResponseEdNextSequence(int responseEdNextSequence) {
		this.responseEdNextSequence = responseEdNextSequence;
	}
	
}
