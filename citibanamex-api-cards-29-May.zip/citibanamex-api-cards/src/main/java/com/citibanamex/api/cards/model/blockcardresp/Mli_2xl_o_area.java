package com.citibanamex.api.cards.model.blockcardresp;

public class Mli_2xl_o_area {

	private Mli_2xl_o_hdr_grp mli_2xl_o_hdr_grp;
	

    public Mli_2xl_o_area() {
		super();
	}

	public Mli_2xl_o_hdr_grp getMli_2xl_o_hdr_grp ()
    {
        return mli_2xl_o_hdr_grp;
    }

    public void setMli_2xl_o_hdr_grp (Mli_2xl_o_hdr_grp mli_2xl_o_hdr_grp)
    {
        this.mli_2xl_o_hdr_grp = mli_2xl_o_hdr_grp;
    }
    
    
   /* @Override
    public String toString()
    {
        return "ClassPojo [mli_2xl_o_hdr_grp = "+mli_2xl_o_hdr_grp+"]";
    }*/
}
