package com.citibanamex.api.cards.model.unblockcardresp;

public class EWOEW2XMOperationResponse {

	private Mli_2xm_o_area mli_2xm_o_area;
	
	
    public EWOEW2XMOperationResponse() {
		super();
	}
	public void setMli_2xm_o_area(Mli_2xm_o_area mli_2xm_o_area){
        this.mli_2xm_o_area = mli_2xm_o_area;
    }
    public Mli_2xm_o_area getMli_2xm_o_area(){
        return this.mli_2xm_o_area;
    }
}
