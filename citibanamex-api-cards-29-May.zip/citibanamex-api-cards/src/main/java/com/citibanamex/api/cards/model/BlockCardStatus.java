package com.citibanamex.api.cards.model;

public class BlockCardStatus {

	private String Status;
	
	public BlockCardStatus(){
		
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}
	
}
