package com.citibanamex.api.cards.exception;

public class Error {

	private String type;
	private String code;
	private String details;
	private String location;
	private String moreInfo;

	  
	public Error() {
		super();
	}	
	
	public Error(String type, String code, String details, String location, String moreInfo) {
		super();
		this.type = type;
		this.code = code;
		this.details = details;
		this.location = location;
		this.moreInfo = moreInfo;
	}
	
	public String getType() { return this.type; }

	public void setType(String type) { this.type = type; }	  

	public String getCode() { return this.code; }

	public void setCode(String code) { this.code = code; }	  

	public String getDetails() { return this.details; }

	public void setDetails(String details) { this.details = details; }	  

	public String getLocation() { return this.location; }

	public void setLocation(String location) { this.location = location; }	  

	public String getMoreInfo() { return this.moreInfo; }

	public void setMoreInfo(String moreInfo) { this.moreInfo = moreInfo; }
}
