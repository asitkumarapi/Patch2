package com.citibanamex.api.cards.aggregator;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.datatype.DatatypeConfigurationException;

import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.citibanamex.api.cards.exception.Error;
import com.citibanamex.api.cards.exception.Errors;
import com.citibanamex.api.cards.model.Constant;
import com.citibanamex.api.cards.model.cardlistreq.CardListPayload;
import com.citibanamex.api.cards.model.cardlistreq.Gbof0003operation;
import com.citibanamex.api.cards.model.cardlistreq.Getrelationshipacctreq;
import com.citibanamex.api.cards.model.cardlistresp.AccountInfoTable;
import com.citibanamex.api.cards.model.cardlistresp.CardResponse;
import com.citibanamex.api.cards.model.cardlistresp.Cards;
import com.citibanamex.api.cards.model.cardlistresp.CreditCardAccounts;
import com.citibanamex.api.cards.model.cardlistresp.CreditCardResponse;
import com.citibanamex.api.cards.model.cardlistresp.OperationResponse;
import com.citibanamex.api.cards.service.impl.CardServiceImpl;
import com.netflix.hystrix.HystrixCommandProperties;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Component
public class CardServiceAggregator {

	public static final Logger logger = LoggerFactory.getLogger(CardServiceImpl.class);
	// @value("${client.url}")
	// private String url;
	RestTemplate restTemplate = null;
	CreditCardResponse CCResponse = null;
	CardResponse cardResp = null;
	CreditCardAccounts creditCardAcc = null;
	ArrayList<CreditCardAccounts> creditCard = null;
	ArrayList<Cards> cards = null;
	Cards cardObject = null;
	String timeStamp = null;

	CardListPayload payload = null;
	Gbof0003operation operation = null;
	Getrelationshipacctreq req = null;

	CardResponse cardStatus = null;
	List<AccountInfoTable> accounts = null;
	HttpHeaders headers = null;
	
	@HystrixCommand(fallbackMethod = "fallbackGetCardsByCustomer")
	public ResponseEntity<?> getCardsByCustomer(String custRelNbr, Map<String, String> data)
			throws JSONException, DatatypeConfigurationException {
		disableSslVerification();
		 logger.info("CC val = "+HystrixCommandProperties.Setter().getCircuitBreakerForceClosed());
	     HystrixCommandProperties.Setter().withExecutionTimeoutInMilliseconds(6000000);
		restTemplate = new RestTemplate();
		GregorianCalendar gc = new GregorianCalendar();
		gc.setTimeInMillis(new Date().getTime());
		// ***Request Header Object
		// .set("DateAndTimeStamp",DatatypeFactory.newInstance().newXMLGregorianCalendar(gc).toString());
		headers = new HttpHeaders();
		headers.set("client_id", data.get("client_id"));
		headers.set("Authorization", data.get("Authorization"));
		headers.set("uuid", data.get("uuid"));
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		logger.info("headers::::" + headers);
		DateFormat df = new SimpleDateFormat("MMddyyyyHHmmss");
		String currentDateTime = df.format(new Date(System.currentTimeMillis()));

		// ****Request Body object
		payload = new CardListPayload();
		operation = new Gbof0003operation();
		req = new Getrelationshipacctreq();
		req.setRequestmessageid("");
		req.setRequestversionnumber(Constant.REQ_VERSION_NO);
		req.setRequestchannelind("");
		req.setRequestcustomerorg(Constant.REQ_CUST_ORG);
		req.setRequestterminalid("");
		req.setRequestrelationshipnumber(custRelNbr);
		req.setRequestdatetime(currentDateTime);
		req.setRequestuserid("");
		operation.setGetrelationshipacctreq(req);
		payload.setGbof0003operation(operation);

		logger.info("Request Payload::::" + payload.toString());
		HttpEntity<?> entity = new HttpEntity<>(payload, headers);
		ResponseEntity<OperationResponse> serviceResponse = restTemplate.exchange(Constant.URI, HttpMethod.POST, entity,
				OperationResponse.class);
		logger.info("serviceResponse >>>>>>" + serviceResponse);

		accounts = serviceResponse.getBody().getgBOF0003OperationResponse().getGetRelationshipAcctRes()
				.getAccountInfoTable();

		creditCard = new ArrayList<CreditCardAccounts>();
		accounts.forEach(account -> {
			if (custRelNbr != null) {
				if (custRelNbr.equals(account.getResponseRelationshipNumber())) {
					creditCardAcc = new CreditCardAccounts();

					creditCardAcc.setAccountNickname(account.getEmbosserName());
					creditCardAcc.setCardNumber(account.getResponseCardNumber());
					creditCardAcc.setAccountStatus(account.getAccountStatus());
					Double balOflastStmt = account.getEndingBalOfLastStmt();
					creditCardAcc.setBalOfLastStmt(Double.toString(balOflastStmt));
					creditCardAcc.setCreditLimit(account.getCardCreditLimit());
					creditCardAcc.setCurrencyCode(account.getCurrencyCode());
					creditCardAcc.setMinimumPaymentAmt(""); // no mapping
															// element available
					Integer miniPaymentDueDate = account.getPaymentDueDate();
					creditCardAcc.setMinimumPaymentDueDate(Integer.toString(miniPaymentDueDate));
					creditCardAcc.setOutstandingBalance(account.getAcctOutstandingAuthAmt());
					Integer lastPaymentDate = account.getPaymentDueDate();
					creditCardAcc.setPaymentDueDate(Integer.toString(lastPaymentDate));
					creditCardAcc.setProductName(account.getCardType());
					creditCard.add(creditCardAcc);
				}
			}
		});
		cardObject = new Cards();
		cardObject.setCreditCardAccounts(creditCard);
		cards = new ArrayList<Cards>();
		cards.add(cardObject);
		cardResp = new CardResponse();
		if (cardResp != null) {
			cardResp.setCards(cards);
		}
		logger.info("Service Response ::: " + cardResp);
		// return cardResp;
		return new ResponseEntity<>(cardResp, HttpStatus.OK);
	}
	
	Errors errors = null;
	Error error = null;
	ArrayList<Error> errorList = null;
	
	//Hystrix fallback method call
	public ResponseEntity<?> fallbackGetCardsByCustomer(String custRelNbr, Map<String, String> data, Throwable t) {
		System.out.println("Inside fallback method..");
		//String status = "fail" + t.toString();
		errors = new Errors();
		error = new Error();
		error.setType("Error");
		error.setCode(String.valueOf(HttpStatus.NOT_FOUND.value()));
		error.setDetails(HttpStatus.NOT_FOUND.name());
		error.setLocation("");
		error.setMoreInfo("Back-end service is down");
		errorList = new ArrayList<Error>();
		errorList.add(error);
		errors.setErrors(errorList);
		return new ResponseEntity<>(errors,HttpStatus.NOT_FOUND);
	}
	
	private static void disableSslVerification() {
		try {
			// Create a trust manager that does not validate certificate chains

			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				public void checkClientTrusted(X509Certificate[] certs, String authType) {
				}

				public void checkServerTrusted(X509Certificate[] certs, String authType) {
				}
			} };

			// Install the all-trusting trust manager
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

			// Create all-trusting host name verifier
			HostnameVerifier allHostsValid = new HostnameVerifier() {

				@Override
				public boolean verify(String arg0, SSLSession arg1) {
					return true;
				}

			};
			// Install the all-trusting host verifier
			HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (KeyManagementException e) {
			e.printStackTrace();
		}
	}
}
