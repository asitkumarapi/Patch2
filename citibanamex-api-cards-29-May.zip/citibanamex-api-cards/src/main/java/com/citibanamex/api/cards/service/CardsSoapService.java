package com.citibanamex.api.cards.service;

import java.io.IOException;
import java.util.List;

import org.springframework.http.HttpHeaders;


import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

/**
 * @author Martin Barcenas
 *
 */
public interface CardsSoapService {
	
	/**
	 * @throws IOException 
	 * @param cardNumber the cardNumber
	 * @return the found account
	 */
	String block(String cardNumber,String status) throws IOException;
	String blockCardByCustomerId(String CustomerId,HttpHeaders hh) throws IOException;
	String blockCardByAccountId(String customerId,String accountId, HttpHeaders hh) throws IOException;
}
