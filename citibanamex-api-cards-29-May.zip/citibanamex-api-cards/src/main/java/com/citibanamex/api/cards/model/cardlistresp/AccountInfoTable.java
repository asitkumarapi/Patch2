package com.citibanamex.api.cards.model.cardlistresp;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AccountInfoTable {

	@JsonProperty("Org")
    private int org;
    @JsonProperty("Logo")
    private int logo;
    private String responseAccountNumber;
    private String responseCardNumber;
    @JsonProperty("CardSequenceNumber")
    private int cardSequenceNumber;
    private int responseCustomerOrg;
    private String responseCustomerNumber;
    private int responseRelationshipOrg;
    private String responseRelationshipNumber;
    private String embosserName;
    private String blockCode;
    private String blockCode1;
    private String blockCode2;
    private double currentBalance;
    private String currentBalanceSign;
    private String currencyCode;
    private int cardCreditLimit;
    private int accountCreditLimit;
    private int expiryDate;
    private String cardToAddressIndicator;
    private String billToAddressIndicator;
    private String accountStatus;
    private int delinquencyStatus;
    private String cardType;
    private double accountOpenToBuy;
    private String accountOpenToBuySign;
    private String staffIndicator;
    private int blockCode1LastMaintainedDate;
    private int blockCode2LastMaintainedDate;
    private int blockCodeLastMaintainedDate;
    private String cardActivationIndicator;
    private int memberSince;
    private String photoFlag;
    private String familyPackIndicator;
    private String cardStatus;
    private String logoDescription;
    private int acctOutstandingAuthAmt;
    private String acctOutstandingAuthAmtSign;
    private int totalDisputedAmount;
    private String totalDisputedAmountSign;
    private int annualIncome;
    private String annualIncomeSign;
    private int cardCashLimit;
    private String cardCashLimitSign;
    private String highestBlockCode;
    private String highestReasonCode;
    private int alopOutstandingAmount;
    private String alopOutstandingAmountSign;
    private String statementFlag;
    private int statementFlagMaintDate;
    private int lastPaymentDate;
    private int lastChequeBounceDate;
    private int behaviorScore;
    private String behaviorScoreSign;
    private String cardArchivalFlag;
    private String accountArchivalFlag;
    private String relationshipArchivalFlag;
    private String ipinStatus;
    private int ipinGenerationDate;
    private int accountCashLimit;
    private String accountCashLimitSign;
    private String combinedCreditLimitFlag;
    private String creditLimitFlagCode;
    private int cardLogo;
    private int cardOpenDate;
    private double endingBalOfLastStmt;
    private String endingBalOfLastStmtSign;
    private int totalAmountDue;
    private String totalAmountDueSign;
    private int paymentDueDate;
    private String nfcFlag;
    private String nfcAssociatedCardNumber;
    private String ppdKycIndicator;
    private String logoCardType;
    private String ppdSourceIndicator;
    private int ppdUniqueId;
    private int priorCVC2;
    private String issueReason;
    
    
    public AccountInfoTable() {
		super();
	}
	/**
	 * @return the org
	 */
	public int getOrg() {
		return org;
	}
	/**
	 * @param org the org to set
	 */
	public void setOrg(int org) {
		this.org = org;
	}
	/**
	 * @return the logo
	 */
	public int getLogo() {
		return logo;
	}
	/**
	 * @param logo the logo to set
	 */
	public void setLogo(int logo) {
		this.logo = logo;
	}
	/**
	 * @return the responseAccountNumber
	 */
	public String getResponseAccountNumber() {
		return responseAccountNumber;
	}
	/**
	 * @param responseAccountNumber the responseAccountNumber to set
	 */
	public void setResponseAccountNumber(String responseAccountNumber) {
		this.responseAccountNumber = responseAccountNumber;
	}
	/**
	 * @return the responseCardNumber
	 */
	public String getResponseCardNumber() {
		return responseCardNumber;
	}
	/**
	 * @param responseCardNumber the responseCardNumber to set
	 */
	public void setResponseCardNumber(String responseCardNumber) {
		this.responseCardNumber = responseCardNumber;
	}
	/**
	 * @return the cardSequenceNumber
	 */
	public int getCardSequenceNumber() {
		return cardSequenceNumber;
	}
	/**
	 * @param cardSequenceNumber the cardSequenceNumber to set
	 */
	public void setCardSequenceNumber(int cardSequenceNumber) {
		this.cardSequenceNumber = cardSequenceNumber;
	}
	/**
	 * @return the responseCustomerOrg
	 */
	public int getResponseCustomerOrg() {
		return responseCustomerOrg;
	}
	/**
	 * @param responseCustomerOrg the responseCustomerOrg to set
	 */
	public void setResponseCustomerOrg(int responseCustomerOrg) {
		this.responseCustomerOrg = responseCustomerOrg;
	}
	/**
	 * @return the responseCustomerNumber
	 */
	public String getResponseCustomerNumber() {
		return responseCustomerNumber;
	}
	/**
	 * @param responseCustomerNumber the responseCustomerNumber to set
	 */
	public void setResponseCustomerNumber(String responseCustomerNumber) {
		this.responseCustomerNumber = responseCustomerNumber;
	}
	/**
	 * @return the responseRelationshipOrg
	 */
	public int getResponseRelationshipOrg() {
		return responseRelationshipOrg;
	}
	/**
	 * @param responseRelationshipOrg the responseRelationshipOrg to set
	 */
	public void setResponseRelationshipOrg(int responseRelationshipOrg) {
		this.responseRelationshipOrg = responseRelationshipOrg;
	}
	/**
	 * @return the responseRelationshipNumber
	 */
	public String getResponseRelationshipNumber() {
		return responseRelationshipNumber;
	}
	/**
	 * @param responseRelationshipNumber the responseRelationshipNumber to set
	 */
	public void setResponseRelationshipNumber(String responseRelationshipNumber) {
		this.responseRelationshipNumber = responseRelationshipNumber;
	}
	/**
	 * @return the embosserName
	 */
	public String getEmbosserName() {
		return embosserName;
	}
	/**
	 * @param embosserName the embosserName to set
	 */
	public void setEmbosserName(String embosserName) {
		this.embosserName = embosserName;
	}
	/**
	 * @return the blockCode
	 */
	public String getBlockCode() {
		return blockCode;
	}
	/**
	 * @param blockCode the blockCode to set
	 */
	public void setBlockCode(String blockCode) {
		this.blockCode = blockCode;
	}
	/**
	 * @return the blockCode1
	 */
	public String getBlockCode1() {
		return blockCode1;
	}
	/**
	 * @param blockCode1 the blockCode1 to set
	 */
	public void setBlockCode1(String blockCode1) {
		this.blockCode1 = blockCode1;
	}
	/**
	 * @return the blockCode2
	 */
	public String getBlockCode2() {
		return blockCode2;
	}
	/**
	 * @param blockCode2 the blockCode2 to set
	 */
	public void setBlockCode2(String blockCode2) {
		this.blockCode2 = blockCode2;
	}
	/**
	 * @return the currentBalance
	 */
	public double getCurrentBalance() {
		return currentBalance;
	}
	/**
	 * @param currentBalance the currentBalance to set
	 */
	public void setCurrentBalance(double currentBalance) {
		this.currentBalance = currentBalance;
	}
	/**
	 * @return the currentBalanceSign
	 */
	public String getCurrentBalanceSign() {
		return currentBalanceSign;
	}
	/**
	 * @param currentBalanceSign the currentBalanceSign to set
	 */
	public void setCurrentBalanceSign(String currentBalanceSign) {
		this.currentBalanceSign = currentBalanceSign;
	}
	/**
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}
	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	/**
	 * @return the cardCreditLimit
	 */
	public int getCardCreditLimit() {
		return cardCreditLimit;
	}
	/**
	 * @param cardCreditLimit the cardCreditLimit to set
	 */
	public void setCardCreditLimit(int cardCreditLimit) {
		this.cardCreditLimit = cardCreditLimit;
	}
	/**
	 * @return the accountCreditLimit
	 */
	public int getAccountCreditLimit() {
		return accountCreditLimit;
	}
	/**
	 * @param accountCreditLimit the accountCreditLimit to set
	 */
	public void setAccountCreditLimit(int accountCreditLimit) {
		this.accountCreditLimit = accountCreditLimit;
	}
	/**
	 * @return the expiryDate
	 */
	public int getExpiryDate() {
		return expiryDate;
	}
	/**
	 * @param expiryDate the expiryDate to set
	 */
	public void setExpiryDate(int expiryDate) {
		this.expiryDate = expiryDate;
	}
	/**
	 * @return the cardToAddressIndicator
	 */
	public String getCardToAddressIndicator() {
		return cardToAddressIndicator;
	}
	/**
	 * @param cardToAddressIndicator the cardToAddressIndicator to set
	 */
	public void setCardToAddressIndicator(String cardToAddressIndicator) {
		this.cardToAddressIndicator = cardToAddressIndicator;
	}
	/**
	 * @return the billToAddressIndicator
	 */
	public String getBillToAddressIndicator() {
		return billToAddressIndicator;
	}
	/**
	 * @param billToAddressIndicator the billToAddressIndicator to set
	 */
	public void setBillToAddressIndicator(String billToAddressIndicator) {
		this.billToAddressIndicator = billToAddressIndicator;
	}
	/**
	 * @return the accountStatus
	 */
	public String getAccountStatus() {
		return accountStatus;
	}
	/**
	 * @param accountStatus the accountStatus to set
	 */
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	/**
	 * @return the delinquencyStatus
	 */
	public int getDelinquencyStatus() {
		return delinquencyStatus;
	}
	/**
	 * @param delinquencyStatus the delinquencyStatus to set
	 */
	public void setDelinquencyStatus(int delinquencyStatus) {
		this.delinquencyStatus = delinquencyStatus;
	}
	/**
	 * @return the cardType
	 */
	public String getCardType() {
		return cardType;
	}
	/**
	 * @param cardType the cardType to set
	 */
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	/**
	 * @return the accountOpenToBuy
	 */
	public double getAccountOpenToBuy() {
		return accountOpenToBuy;
	}
	/**
	 * @param accountOpenToBuy the accountOpenToBuy to set
	 */
	public void setAccountOpenToBuy(double accountOpenToBuy) {
		this.accountOpenToBuy = accountOpenToBuy;
	}
	/**
	 * @return the accountOpenToBuySign
	 */
	public String getAccountOpenToBuySign() {
		return accountOpenToBuySign;
	}
	/**
	 * @param accountOpenToBuySign the accountOpenToBuySign to set
	 */
	public void setAccountOpenToBuySign(String accountOpenToBuySign) {
		this.accountOpenToBuySign = accountOpenToBuySign;
	}
	/**
	 * @return the staffIndicator
	 */
	public String getStaffIndicator() {
		return staffIndicator;
	}
	/**
	 * @param staffIndicator the staffIndicator to set
	 */
	public void setStaffIndicator(String staffIndicator) {
		this.staffIndicator = staffIndicator;
	}
	/**
	 * @return the blockCode1LastMaintainedDate
	 */
	public int getBlockCode1LastMaintainedDate() {
		return blockCode1LastMaintainedDate;
	}
	/**
	 * @param blockCode1LastMaintainedDate the blockCode1LastMaintainedDate to set
	 */
	public void setBlockCode1LastMaintainedDate(int blockCode1LastMaintainedDate) {
		this.blockCode1LastMaintainedDate = blockCode1LastMaintainedDate;
	}
	/**
	 * @return the blockCode2LastMaintainedDate
	 */
	public int getBlockCode2LastMaintainedDate() {
		return blockCode2LastMaintainedDate;
	}
	/**
	 * @param blockCode2LastMaintainedDate the blockCode2LastMaintainedDate to set
	 */
	public void setBlockCode2LastMaintainedDate(int blockCode2LastMaintainedDate) {
		this.blockCode2LastMaintainedDate = blockCode2LastMaintainedDate;
	}
	/**
	 * @return the blockCodeLastMaintainedDate
	 */
	public int getBlockCodeLastMaintainedDate() {
		return blockCodeLastMaintainedDate;
	}
	/**
	 * @param blockCodeLastMaintainedDate the blockCodeLastMaintainedDate to set
	 */
	public void setBlockCodeLastMaintainedDate(int blockCodeLastMaintainedDate) {
		this.blockCodeLastMaintainedDate = blockCodeLastMaintainedDate;
	}
	/**
	 * @return the cardActivationIndicator
	 */
	public String getCardActivationIndicator() {
		return cardActivationIndicator;
	}
	/**
	 * @param cardActivationIndicator the cardActivationIndicator to set
	 */
	public void setCardActivationIndicator(String cardActivationIndicator) {
		this.cardActivationIndicator = cardActivationIndicator;
	}
	/**
	 * @return the memberSince
	 */
	public int getMemberSince() {
		return memberSince;
	}
	/**
	 * @param memberSince the memberSince to set
	 */
	public void setMemberSince(int memberSince) {
		this.memberSince = memberSince;
	}
	/**
	 * @return the photoFlag
	 */
	public String getPhotoFlag() {
		return photoFlag;
	}
	/**
	 * @param photoFlag the photoFlag to set
	 */
	public void setPhotoFlag(String photoFlag) {
		this.photoFlag = photoFlag;
	}
	/**
	 * @return the familyPackIndicator
	 */
	public String getFamilyPackIndicator() {
		return familyPackIndicator;
	}
	/**
	 * @param familyPackIndicator the familyPackIndicator to set
	 */
	public void setFamilyPackIndicator(String familyPackIndicator) {
		this.familyPackIndicator = familyPackIndicator;
	}
	/**
	 * @return the cardStatus
	 */
	public String getCardStatus() {
		return cardStatus;
	}
	/**
	 * @param cardStatus the cardStatus to set
	 */
	public void setCardStatus(String cardStatus) {
		this.cardStatus = cardStatus;
	}
	/**
	 * @return the logoDescription
	 */
	public String getLogoDescription() {
		return logoDescription;
	}
	/**
	 * @param logoDescription the logoDescription to set
	 */
	public void setLogoDescription(String logoDescription) {
		this.logoDescription = logoDescription;
	}
	/**
	 * @return the acctOutstandingAuthAmt
	 */
	public int getAcctOutstandingAuthAmt() {
		return acctOutstandingAuthAmt;
	}
	/**
	 * @param acctOutstandingAuthAmt the acctOutstandingAuthAmt to set
	 */
	public void setAcctOutstandingAuthAmt(int acctOutstandingAuthAmt) {
		this.acctOutstandingAuthAmt = acctOutstandingAuthAmt;
	}
	/**
	 * @return the acctOutstandingAuthAmtSign
	 */
	public String getAcctOutstandingAuthAmtSign() {
		return acctOutstandingAuthAmtSign;
	}
	/**
	 * @param acctOutstandingAuthAmtSign the acctOutstandingAuthAmtSign to set
	 */
	public void setAcctOutstandingAuthAmtSign(String acctOutstandingAuthAmtSign) {
		this.acctOutstandingAuthAmtSign = acctOutstandingAuthAmtSign;
	}
	/**
	 * @return the totalDisputedAmount
	 */
	public int getTotalDisputedAmount() {
		return totalDisputedAmount;
	}
	/**
	 * @param totalDisputedAmount the totalDisputedAmount to set
	 */
	public void setTotalDisputedAmount(int totalDisputedAmount) {
		this.totalDisputedAmount = totalDisputedAmount;
	}
	/**
	 * @return the totalDisputedAmountSign
	 */
	public String getTotalDisputedAmountSign() {
		return totalDisputedAmountSign;
	}
	/**
	 * @param totalDisputedAmountSign the totalDisputedAmountSign to set
	 */
	public void setTotalDisputedAmountSign(String totalDisputedAmountSign) {
		this.totalDisputedAmountSign = totalDisputedAmountSign;
	}
	/**
	 * @return the annualIncome
	 */
	public int getAnnualIncome() {
		return annualIncome;
	}
	/**
	 * @param annualIncome the annualIncome to set
	 */
	public void setAnnualIncome(int annualIncome) {
		this.annualIncome = annualIncome;
	}
	/**
	 * @return the annualIncomeSign
	 */
	public String getAnnualIncomeSign() {
		return annualIncomeSign;
	}
	/**
	 * @param annualIncomeSign the annualIncomeSign to set
	 */
	public void setAnnualIncomeSign(String annualIncomeSign) {
		this.annualIncomeSign = annualIncomeSign;
	}
	/**
	 * @return the cardCashLimit
	 */
	public int getCardCashLimit() {
		return cardCashLimit;
	}
	/**
	 * @param cardCashLimit the cardCashLimit to set
	 */
	public void setCardCashLimit(int cardCashLimit) {
		this.cardCashLimit = cardCashLimit;
	}
	/**
	 * @return the cardCashLimitSign
	 */
	public String getCardCashLimitSign() {
		return cardCashLimitSign;
	}
	/**
	 * @param cardCashLimitSign the cardCashLimitSign to set
	 */
	public void setCardCashLimitSign(String cardCashLimitSign) {
		this.cardCashLimitSign = cardCashLimitSign;
	}
	/**
	 * @return the highestBlockCode
	 */
	public String getHighestBlockCode() {
		return highestBlockCode;
	}
	/**
	 * @param highestBlockCode the highestBlockCode to set
	 */
	public void setHighestBlockCode(String highestBlockCode) {
		this.highestBlockCode = highestBlockCode;
	}
	/**
	 * @return the highestReasonCode
	 */
	public String getHighestReasonCode() {
		return highestReasonCode;
	}
	/**
	 * @param highestReasonCode the highestReasonCode to set
	 */
	public void setHighestReasonCode(String highestReasonCode) {
		this.highestReasonCode = highestReasonCode;
	}
	/**
	 * @return the alopOutstandingAmount
	 */
	public int getAlopOutstandingAmount() {
		return alopOutstandingAmount;
	}
	/**
	 * @param alopOutstandingAmount the alopOutstandingAmount to set
	 */
	public void setAlopOutstandingAmount(int alopOutstandingAmount) {
		this.alopOutstandingAmount = alopOutstandingAmount;
	}
	/**
	 * @return the alopOutstandingAmountSign
	 */
	public String getAlopOutstandingAmountSign() {
		return alopOutstandingAmountSign;
	}
	/**
	 * @param alopOutstandingAmountSign the alopOutstandingAmountSign to set
	 */
	public void setAlopOutstandingAmountSign(String alopOutstandingAmountSign) {
		this.alopOutstandingAmountSign = alopOutstandingAmountSign;
	}
	/**
	 * @return the statementFlag
	 */
	public String getStatementFlag() {
		return statementFlag;
	}
	/**
	 * @param statementFlag the statementFlag to set
	 */
	public void setStatementFlag(String statementFlag) {
		this.statementFlag = statementFlag;
	}
	/**
	 * @return the statementFlagMaintDate
	 */
	public int getStatementFlagMaintDate() {
		return statementFlagMaintDate;
	}
	/**
	 * @param statementFlagMaintDate the statementFlagMaintDate to set
	 */
	public void setStatementFlagMaintDate(int statementFlagMaintDate) {
		this.statementFlagMaintDate = statementFlagMaintDate;
	}
	/**
	 * @return the lastPaymentDate
	 */
	public int getLastPaymentDate() {
		return lastPaymentDate;
	}
	/**
	 * @param lastPaymentDate the lastPaymentDate to set
	 */
	public void setLastPaymentDate(int lastPaymentDate) {
		this.lastPaymentDate = lastPaymentDate;
	}
	/**
	 * @return the lastChequeBounceDate
	 */
	public int getLastChequeBounceDate() {
		return lastChequeBounceDate;
	}
	/**
	 * @param lastChequeBounceDate the lastChequeBounceDate to set
	 */
	public void setLastChequeBounceDate(int lastChequeBounceDate) {
		this.lastChequeBounceDate = lastChequeBounceDate;
	}
	/**
	 * @return the behaviorScore
	 */
	public int getBehaviorScore() {
		return behaviorScore;
	}
	/**
	 * @param behaviorScore the behaviorScore to set
	 */
	public void setBehaviorScore(int behaviorScore) {
		this.behaviorScore = behaviorScore;
	}
	/**
	 * @return the behaviorScoreSign
	 */
	public String getBehaviorScoreSign() {
		return behaviorScoreSign;
	}
	/**
	 * @param behaviorScoreSign the behaviorScoreSign to set
	 */
	public void setBehaviorScoreSign(String behaviorScoreSign) {
		this.behaviorScoreSign = behaviorScoreSign;
	}
	/**
	 * @return the cardArchivalFlag
	 */
	public String getCardArchivalFlag() {
		return cardArchivalFlag;
	}
	/**
	 * @param cardArchivalFlag the cardArchivalFlag to set
	 */
	public void setCardArchivalFlag(String cardArchivalFlag) {
		this.cardArchivalFlag = cardArchivalFlag;
	}
	/**
	 * @return the accountArchivalFlag
	 */
	public String getAccountArchivalFlag() {
		return accountArchivalFlag;
	}
	/**
	 * @param accountArchivalFlag the accountArchivalFlag to set
	 */
	public void setAccountArchivalFlag(String accountArchivalFlag) {
		this.accountArchivalFlag = accountArchivalFlag;
	}
	/**
	 * @return the relationshipArchivalFlag
	 */
	public String getRelationshipArchivalFlag() {
		return relationshipArchivalFlag;
	}
	/**
	 * @param relationshipArchivalFlag the relationshipArchivalFlag to set
	 */
	public void setRelationshipArchivalFlag(String relationshipArchivalFlag) {
		this.relationshipArchivalFlag = relationshipArchivalFlag;
	}
	/**
	 * @return the ipinStatus
	 */
	public String getIpinStatus() {
		return ipinStatus;
	}
	/**
	 * @param ipinStatus the ipinStatus to set
	 */
	public void setIpinStatus(String ipinStatus) {
		this.ipinStatus = ipinStatus;
	}
	/**
	 * @return the ipinGenerationDate
	 */
	public int getIpinGenerationDate() {
		return ipinGenerationDate;
	}
	/**
	 * @param ipinGenerationDate the ipinGenerationDate to set
	 */
	public void setIpinGenerationDate(int ipinGenerationDate) {
		this.ipinGenerationDate = ipinGenerationDate;
	}
	/**
	 * @return the accountCashLimit
	 */
	public int getAccountCashLimit() {
		return accountCashLimit;
	}
	/**
	 * @param accountCashLimit the accountCashLimit to set
	 */
	public void setAccountCashLimit(int accountCashLimit) {
		this.accountCashLimit = accountCashLimit;
	}
	/**
	 * @return the accountCashLimitSign
	 */
	public String getAccountCashLimitSign() {
		return accountCashLimitSign;
	}
	/**
	 * @param accountCashLimitSign the accountCashLimitSign to set
	 */
	public void setAccountCashLimitSign(String accountCashLimitSign) {
		this.accountCashLimitSign = accountCashLimitSign;
	}
	/**
	 * @return the combinedCreditLimitFlag
	 */
	public String getCombinedCreditLimitFlag() {
		return combinedCreditLimitFlag;
	}
	/**
	 * @param combinedCreditLimitFlag the combinedCreditLimitFlag to set
	 */
	public void setCombinedCreditLimitFlag(String combinedCreditLimitFlag) {
		this.combinedCreditLimitFlag = combinedCreditLimitFlag;
	}
	/**
	 * @return the creditLimitFlagCode
	 */
	public String getCreditLimitFlagCode() {
		return creditLimitFlagCode;
	}
	/**
	 * @param creditLimitFlagCode the creditLimitFlagCode to set
	 */
	public void setCreditLimitFlagCode(String creditLimitFlagCode) {
		this.creditLimitFlagCode = creditLimitFlagCode;
	}
	/**
	 * @return the cardLogo
	 */
	public int getCardLogo() {
		return cardLogo;
	}
	/**
	 * @param cardLogo the cardLogo to set
	 */
	public void setCardLogo(int cardLogo) {
		this.cardLogo = cardLogo;
	}
	/**
	 * @return the cardOpenDate
	 */
	public int getCardOpenDate() {
		return cardOpenDate;
	}
	/**
	 * @param cardOpenDate the cardOpenDate to set
	 */
	public void setCardOpenDate(int cardOpenDate) {
		this.cardOpenDate = cardOpenDate;
	}
	/**
	 * @return the endingBalOfLastStmt
	 */
	public double getEndingBalOfLastStmt() {
		return endingBalOfLastStmt;
	}
	/**
	 * @param endingBalOfLastStmt the endingBalOfLastStmt to set
	 */
	public void setEndingBalOfLastStmt(double endingBalOfLastStmt) {
		this.endingBalOfLastStmt = endingBalOfLastStmt;
	}
	/**
	 * @return the endingBalOfLastStmtSign
	 */
	public String getEndingBalOfLastStmtSign() {
		return endingBalOfLastStmtSign;
	}
	/**
	 * @param endingBalOfLastStmtSign the endingBalOfLastStmtSign to set
	 */
	public void setEndingBalOfLastStmtSign(String endingBalOfLastStmtSign) {
		this.endingBalOfLastStmtSign = endingBalOfLastStmtSign;
	}
	/**
	 * @return the totalAmountDue
	 */
	public int getTotalAmountDue() {
		return totalAmountDue;
	}
	/**
	 * @param totalAmountDue the totalAmountDue to set
	 */
	public void setTotalAmountDue(int totalAmountDue) {
		this.totalAmountDue = totalAmountDue;
	}
	/**
	 * @return the totalAmountDueSign
	 */
	public String getTotalAmountDueSign() {
		return totalAmountDueSign;
	}
	/**
	 * @param totalAmountDueSign the totalAmountDueSign to set
	 */
	public void setTotalAmountDueSign(String totalAmountDueSign) {
		this.totalAmountDueSign = totalAmountDueSign;
	}
	/**
	 * @return the paymentDueDate
	 */
	public int getPaymentDueDate() {
		return paymentDueDate;
	}
	/**
	 * @param paymentDueDate the paymentDueDate to set
	 */
	public void setPaymentDueDate(int paymentDueDate) {
		this.paymentDueDate = paymentDueDate;
	}
	/**
	 * @return the nfcFlag
	 */
	public String getNfcFlag() {
		return nfcFlag;
	}
	/**
	 * @param nfcFlag the nfcFlag to set
	 */
	public void setNfcFlag(String nfcFlag) {
		this.nfcFlag = nfcFlag;
	}
	/**
	 * @return the nfcAssociatedCardNumber
	 */
	public String getNfcAssociatedCardNumber() {
		return nfcAssociatedCardNumber;
	}
	/**
	 * @param nfcAssociatedCardNumber the nfcAssociatedCardNumber to set
	 */
	public void setNfcAssociatedCardNumber(String nfcAssociatedCardNumber) {
		this.nfcAssociatedCardNumber = nfcAssociatedCardNumber;
	}
	/**
	 * @return the ppdKycIndicator
	 */
	public String getPpdKycIndicator() {
		return ppdKycIndicator;
	}
	/**
	 * @param ppdKycIndicator the ppdKycIndicator to set
	 */
	public void setPpdKycIndicator(String ppdKycIndicator) {
		this.ppdKycIndicator = ppdKycIndicator;
	}
	/**
	 * @return the logoCardType
	 */
	public String getLogoCardType() {
		return logoCardType;
	}
	/**
	 * @param logoCardType the logoCardType to set
	 */
	public void setLogoCardType(String logoCardType) {
		this.logoCardType = logoCardType;
	}
	/**
	 * @return the ppdSourceIndicator
	 */
	public String getPpdSourceIndicator() {
		return ppdSourceIndicator;
	}
	/**
	 * @param ppdSourceIndicator the ppdSourceIndicator to set
	 */
	public void setPpdSourceIndicator(String ppdSourceIndicator) {
		this.ppdSourceIndicator = ppdSourceIndicator;
	}
	/**
	 * @return the ppdUniqueId
	 */
	public int getPpdUniqueId() {
		return ppdUniqueId;
	}
	/**
	 * @param ppdUniqueId the ppdUniqueId to set
	 */
	public void setPpdUniqueId(int ppdUniqueId) {
		this.ppdUniqueId = ppdUniqueId;
	}
	/**
	 * @return the priorCVC2
	 */
	public int getPriorCVC2() {
		return priorCVC2;
	}
	/**
	 * @param priorCVC2 the priorCVC2 to set
	 */
	public void setPriorCVC2(int priorCVC2) {
		this.priorCVC2 = priorCVC2;
	}
	/**
	 * @return the issueReason
	 */
	public String getIssueReason() {
		return issueReason;
	}
	/**
	 * @param issueReason the issueReason to set
	 */
	public void setIssueReason(String issueReason) {
		this.issueReason = issueReason;
	}
}
