package com.citibanamex.api.cards.model.unblockcardresp;

public class Mli_2xm_o_hdr_grp {

	private int mli_2xm_o_message_id;

	private int mli_2xm_o_version_nbr;

	private String mli_2xm_o_terminal_id;

	private String mli_2xm_o_user_id;

	private String mli_2xm_o_timestamp;

	private String mli_2xm_o_error_code;

	private String mli_2xm_o_resp_msg;
	
	
    public Mli_2xm_o_hdr_grp() {
		super();
	}
	public void setMli_2xm_o_message_id(int mli_2xm_o_message_id){
        this.mli_2xm_o_message_id = mli_2xm_o_message_id;
    }
    public int getMli_2xm_o_message_id(){
        return this.mli_2xm_o_message_id;
    }
    public void setMli_2xm_o_version_nbr(int mli_2xm_o_version_nbr){
        this.mli_2xm_o_version_nbr = mli_2xm_o_version_nbr;
    }
    public int getMli_2xm_o_version_nbr(){
        return this.mli_2xm_o_version_nbr;
    }
    public void setMli_2xm_o_terminal_id(String mli_2xm_o_terminal_id){
        this.mli_2xm_o_terminal_id = mli_2xm_o_terminal_id;
    }
    public String getMli_2xm_o_terminal_id(){
        return this.mli_2xm_o_terminal_id;
    }
    public void setMli_2xm_o_user_id(String mli_2xm_o_user_id){
        this.mli_2xm_o_user_id = mli_2xm_o_user_id;
    }
    public String getMli_2xm_o_user_id(){
        return this.mli_2xm_o_user_id;
    }
    public void setMli_2xm_o_timestamp(String mli_2xm_o_timestamp){
        this.mli_2xm_o_timestamp = mli_2xm_o_timestamp;
    }
    public String getMli_2xm_o_timestamp(){
        return this.mli_2xm_o_timestamp;
    }
    public void setMli_2xm_o_error_code(String mli_2xm_o_error_code){
        this.mli_2xm_o_error_code = mli_2xm_o_error_code;
    }
    public String getMli_2xm_o_error_code(){
        return this.mli_2xm_o_error_code;
    }
    public void setMli_2xm_o_resp_msg(String mli_2xm_o_resp_msg){
        this.mli_2xm_o_resp_msg = mli_2xm_o_resp_msg;
    }
    public String getMli_2xm_o_resp_msg(){
        return this.mli_2xm_o_resp_msg;
    }
}
