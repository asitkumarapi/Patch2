package com.citibanamex.api.cards.service;

import static com.jayway.jsonpath.Criteria.where;
import static com.jayway.jsonpath.Filter.filter;
import static com.jayway.jsonpath.JsonPath.parse;

import java.io.IOException;
import java.util.*;

import com.citibanamex.api.cards.wsdl.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Service;

import com.citibanamex.api.cards.model.Card;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.jayway.jsonpath.Filter;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import javax.xml.bind.JAXBElement;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * This service works as an example and will be replace for a real service one later.
 * 
 * @author Martin Barcenas
 *
 */
@Service("accountService")

public class CardsSoapServiceImpl extends WebServiceGatewaySupport implements CardsSoapService  {

	private static final Logger log = LoggerFactory.getLogger(CardsSoapServiceImpl.class);


	private ObjectMapper mapper = new ObjectMapper();


	/**
	 * @see CardsSoapService#block(java.lang.String)
	 */
	@Override
	public String block(String cardNumber) throws IOException {
		mapper.setPropertyNamingStrategy(PropertyNamingStrategy.SNAKE_CASE);

		LostStolenRq request = new ObjectFactory().createLostStolenRq();
		request.setCardNumber(cardNumber);

		log.info("Requesting block for " + cardNumber);

		WebServiceTemplate webServiceTemplate = getWebServiceTemplate();
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setContextPath("com.citibanamex.api.cards.wsdl");
		webServiceTemplate.setMarshaller(marshaller);
		webServiceTemplate.setUnmarshaller(marshaller);

		LostStolenRs response = (LostStolenRs) webServiceTemplate
				.marshalSendAndReceive("http://rmxap-dev4502:48201",
						new ObjectFactory().createLostStolenRq(request),
						new SoapActionCallback("/SvcImpl/common/esms/v115_1_0_0/SOAPEndpoint/EsmsService.serviceagent/OpEndpointJMS/LostStolen") {
							@Override
							public void doWithMessage(WebServiceMessage message) throws IOException {
								super.doWithMessage(message);
								SoapMessage soapMessage = (SoapMessage)message;
								soapMessage.getSoapHeader().getResult();

								try {
									log.info("try-----");
									getMarshaller().marshal(createHeader(), soapMessage.getSoapHeader().getResult());
								} catch (DatatypeConfigurationException e) {
									throw new RuntimeException(e);
								}

							}
						}
						);

		return response.getRsHeader().getResponseCode();
	}

	private JAXBElement<RqHeader> createHeader() throws DatatypeConfigurationException {
		log.info("Creating header ...");
		RqHeader header = new RqHeader();
		ClientDetails clientDetails = new ClientDetails();
		GregorianCalendar gc = new GregorianCalendar();
		gc.setTimeInMillis(new Date().getTime());

		clientDetails.setOrg("CITI");
		clientDetails.setOrgUnit("CITI");
		clientDetails.setChannelID("BMX");
		clientDetails.setTerminalID("0000");
		clientDetails.setUserID("CITI");
		clientDetails.setSrcCountryCode("MX");
		clientDetails.setDestCountryCode("MX");

		header.setUUID(UUID.randomUUID().toString()); // DEMO
		header.setDateAndTimeStamp(DatatypeFactory.newInstance().newXMLGregorianCalendar(gc)); //DEMO
		header.setClientDetails(clientDetails);

		return new ObjectFactory().createRqHeader(header);
	}

}
