package com.citibanamex.api.cards.model;

public class Constant {
	
	// Card List
	public static final String URI = "https://sit.api.banamex.com/ccp/sit/v1/card/cardinfo/RelatedCardListInq";
	public static final String URI2 = "https://sit.externalapib2b.wlb.nam.nsroot.net/ccp/sit/v1/card/cardinfo/RelatedCardListInq";
	public static final String AUTHORIZATION = "Basic dGVzdDAwMTpwd2QwMDE=";
	public static final String REQ_MESSAGE_ID = "0003";
	public static final int REQ_VERSION_NO = 15;
	public static final String REQ_TERMINAL_ID = "00000000MX";
	public static final String REQ_USER_ID = "0003";
	public static final String REQ_DATE_TIME = "07132015120500";
	public static final String REQ_CHANNEL_IND = "ECL";
	public static final String REQ_CUST_ORG = "322";
	public static final String REQ_RELATIONSHIP_NO = "000000311703";

	// Block card
	public static final String ORG = "CITI";
	public static final String ORG_UNIT = "CITI";
	public static final String CHANNEL_ID = "BMX";
	public static final String TERMINAL_ID = "0000";
	public static final String USER_ID = "CITI";
	public static final String SRC_COUNTRY_CODE = "MX";
	public static final String DEST_COUNTRY_CODE = "MX";
	
	public static final String BLOCK_SERVICE = "https://mt01vip1.mt01.mex.nsroot.net:10443/v1/card/afews/blkOvcAtch";
	public static final String UNBLOCK_SERVICE = "https://mt01vip1.mt01.mex.nsroot.net:10443/v1/card/afews/blkOvcDtch";
	
}
