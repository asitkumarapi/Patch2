package com.citibanamex.api.cards.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.xml.datatype.DatatypeConfigurationException;

import com.citibanamex.api.cards.exception.CustomException;
import com.citibanamex.api.cards.handler.GlobalExceptionHandler;

import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.citibanamex.api.cards.service.CardService;
import com.citibanamex.api.cards.service.impl.CardServiceImpl;
import com.citibanamex.api.cards.model.BlockCardStatus;
import com.citibanamex.api.cards.model.blockcardresp.ResponseData;
import com.citibanamex.api.cards.model.cardlistresp.CardResponse;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author Asit Samantray
 * 
 * 
 *         This service is returns list of credit card based on customer number
 *         or relationship number associated with a
 *         customer. @PathVariable("customerRelationsNumber") - customer number
 *         is passed as request path variable. @RequestHeader("client_id") -
 *         ClientId is passed as request header
 *         variable. @RequestHeader("Authorization") - Authorization is passed
 *         as request header variable. @RequestHeader("releationshipNbr") -
 *         customer relationship number is passed as request header variable.
 * 
 * 
 */

@RestController
@RequestMapping("/api/v1")
public class CardsController {

	private static final Logger log = LoggerFactory.getLogger(CardsController.class);

	String data = null;
	ResponseData responseData = null;
	BlockCardStatus status = null;
	CardResponse creditCards = null;
	Map<String, String> requestData = null;
	GlobalExceptionHandler globalHandler = null;
	CustomException ce = null;
	

	//@Autowired
	//CardService cardService;
	@Autowired
	CardServiceImpl cardImpl;

	@RequestMapping(value = "/creditCards/customerAccounts/customer/{customerId}/accounts", method = RequestMethod.GET)
	@ApiOperation(value = "getCardsByCustomer", nickname = "Get the list of cards by customer account")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 403, message = "Forbidden"),
			@ApiResponse(code = 500, message = "Failure") })
	public ResponseEntity<?> getCardsByCustomerId(@RequestHeader("client_id") String clientId, @RequestHeader("Authorization") String auth,@RequestHeader("Content-Type") String contentType,
			@RequestHeader("uuid") String uuid,@RequestHeader("Accept") String accept,@PathVariable("customerId") String relationshipNbr) throws Exception {		
		
		requestData = new HashMap<String,String>();
		requestData.put("client_id", clientId);
		requestData.put("Authorization", auth);
		requestData.put("uuid", uuid);
		
		// Create request payload for backend service
		if((relationshipNbr != "" && relationshipNbr != null)){
			
			requestData.put("relationshipNumber", relationshipNbr);
		}else{
			globalHandler = new GlobalExceptionHandler();
			ce = new CustomException("The parameter must not be null or empty");
			globalHandler.specialException(ce);			
		}		
		//creditCards = new CardResponse();
		ResponseEntity<?> creditCards = null;
		log.info("Get carLidt Call start........");
		try {
			//creditCards = cardService.getCardsByCustomer(relationshipNbr,requestData);
			//creditCards = cardImpl.getCardsByCustomer(relationshipNbr,requestData);
			creditCards = cardImpl.executeService(relationshipNbr,requestData);
		} catch (JSONException e) {
			//log.error(e);
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		} catch (DatatypeConfigurationException e) {
			//log.error(e);
			return new ResponseEntity<>(e.getMessage(), HttpStatus.SERVICE_UNAVAILABLE);
		}	
		return new ResponseEntity<>(creditCards.getBody(),HttpStatus.OK);
	}	
}
