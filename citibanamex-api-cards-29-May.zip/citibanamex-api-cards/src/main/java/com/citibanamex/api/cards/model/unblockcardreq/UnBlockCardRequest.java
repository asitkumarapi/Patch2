package com.citibanamex.api.cards.model.unblockcardreq;

public class UnBlockCardRequest {
	private String cardNumber;
	

	public UnBlockCardRequest() {
		super();
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	
}
