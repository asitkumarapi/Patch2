package com.citibanamex.api.cards.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import com.citibanamex.api.cards.model.GBOF0003OperationResponse;

public class OperationResponse {

	@JsonProperty("GBOF0003OperationResponse")
    public GBOF0003OperationResponse gBOF0003OperationResponse;

	/**
	 * @return the gBOF0003OperationResponse
	 */
	public GBOF0003OperationResponse getgBOF0003OperationResponse() {
		return gBOF0003OperationResponse;
	}

	/**
	 * @param gBOF0003OperationResponse the gBOF0003OperationResponse to set
	 */
	public void setgBOF0003OperationResponse(GBOF0003OperationResponse gBOF0003OperationResponse) {
		this.gBOF0003OperationResponse = gBOF0003OperationResponse;
	}
}
