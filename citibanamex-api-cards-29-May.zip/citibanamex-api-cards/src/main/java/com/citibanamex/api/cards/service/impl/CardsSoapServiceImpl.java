package com.citibanamex.api.cards.service.impl;

import static com.jayway.jsonpath.Criteria.where;
import static com.jayway.jsonpath.Filter.filter;
import static com.jayway.jsonpath.JsonPath.parse;

import java.io.IOException;
import java.util.*;

import com.citibanamex.api.cards.wsdl.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.collections.CollectionUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;


import com.citibanamex.api.cards.model.Constant;
import com.citibanamex.api.cards.model.cardlistresp.AccountInfoTable;
import com.citibanamex.api.cards.model.cardlistresp.CardResponse;
import com.citibanamex.api.cards.model.cardlistresp.Cards;
import com.citibanamex.api.cards.model.cardlistresp.CreditCardAccounts;
import com.citibanamex.api.cards.model.cardlistresp.CreditCardResponse;
import com.citibanamex.api.cards.model.cardlistresp.OperationResponse;
import com.citibanamex.api.cards.service.CardsSoapService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import javax.xml.bind.JAXBElement;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;


/** 
 * 
 * @author Asit Samantray
 *
 */
@Service("accountService")

public class CardsSoapServiceImpl extends WebServiceGatewaySupport implements CardsSoapService  {

	private static final Logger logger = LoggerFactory.getLogger(CardsSoapServiceImpl.class);

	CreditCardResponse CCResponse = null;
	CardResponse cr = null;
	CreditCardAccounts cc = null;
	ArrayList<CreditCardAccounts> creditCard = null;
	ArrayList<Cards> cards = null;
	Cards cardObject = null;
	String response = null;
	private ObjectMapper mapper = new ObjectMapper();


	/**
	 * @see CardsSoapService#block(java.lang.String)
	 */
	@Override
	public String block(String cardNumber,String status) throws IOException {
		mapper.setPropertyNamingStrategy(PropertyNamingStrategy.SNAKE_CASE);
		
		
		LostStolenRq request = new ObjectFactory().createLostStolenRq();
		request.setCardNumber(cardNumber);
		request.setBlockCode(status);

		logger.info("Requesting block for " + cardNumber);

		WebServiceTemplate webServiceTemplate = getWebServiceTemplate();
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setContextPath("com.citibanamex.api.cards.wsdl");
		webServiceTemplate.setMarshaller(marshaller);
		webServiceTemplate.setUnmarshaller(marshaller);

		LostStolenRs response = (LostStolenRs) webServiceTemplate
				.marshalSendAndReceive("http://rmxap-dev4502:48201",
						new ObjectFactory().createLostStolenRq(request),
						new SoapActionCallback("/SvcImpl/common/esms/v115_1_0_0/SOAPEndpoint/EsmsService.serviceagent/OpEndpointJMS/LostStolen") {
							@Override
							public void doWithMessage(WebServiceMessage message) throws IOException {
								super.doWithMessage(message);
								SoapMessage soapMessage = (SoapMessage)message;
								soapMessage.getSoapHeader().getResult();

								try {
									logger.info("try-----");
									getMarshaller().marshal(createHeader(), soapMessage.getSoapHeader().getResult());
								} catch (DatatypeConfigurationException e) {
									throw new RuntimeException(e);
								}

							}
						}
						);

		return response.getRsHeader().getResponseCode();
	}

	private JAXBElement<RqHeader> createHeader() throws DatatypeConfigurationException {
		logger.info("Creating header ...");
		RqHeader header = new RqHeader();
		ClientDetails clientDetails = new ClientDetails();
		GregorianCalendar gc = new GregorianCalendar();
		gc.setTimeInMillis(new Date().getTime());

		clientDetails.setOrg(Constant.ORG);
		clientDetails.setOrgUnit(Constant.ORG_UNIT);
		clientDetails.setChannelID(Constant.CHANNEL_ID);
		clientDetails.setTerminalID(Constant.TERMINAL_ID);
		clientDetails.setUserID(Constant.USER_ID);
		clientDetails.setSrcCountryCode(Constant.SRC_COUNTRY_CODE);
		clientDetails.setDestCountryCode(Constant.DEST_COUNTRY_CODE);

		header.setUUID(UUID.randomUUID().toString());
		header.setDateAndTimeStamp(DatatypeFactory.newInstance().newXMLGregorianCalendar(gc));
		header.setClientDetails(clientDetails);

		return new ObjectFactory().createRqHeader(header);
	}

	@Override
	public String blockCardByCustomerId(String CustomerId, HttpHeaders headers) throws IOException {		
		String URI = Constant.URI;
		logger.info("Credit card service POST URI ::::" + URI);
		RestTemplate restTemplate = new RestTemplate();

		logger.info("***Request Header Object start");		
		headers.set("UUID",UUID.randomUUID().toString());
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		logger.info("Request Header :::" + headers);
		logger.info("****Request Body object start");

		JSONObject payload = null;
		JSONObject jsonOpObject = null;
		JSONObject jsonAccObject = null;
		try {
			jsonAccObject = new JSONObject();
			jsonAccObject.put("requestMessageId", Constant.REQ_MESSAGE_ID);
			jsonAccObject.put("requestVersionNumber", Constant.REQ_VERSION_NO);
			jsonAccObject.put("requestTerminalId", Constant.REQ_TERMINAL_ID);
			jsonAccObject.put("requestUserId", Constant.REQ_USER_ID);
			jsonAccObject.put("requestDateTime", Constant.REQ_DATE_TIME);
			jsonAccObject.put("requestChannelInd", Constant.REQ_CHANNEL_IND);
			jsonAccObject.put("requestCustomerOrg", Constant.REQ_CUST_ORG);
			jsonAccObject.put("requestRelationshipNumber", Constant.REQ_RELATIONSHIP_NO);
			jsonOpObject = new JSONObject().put("getRelationshipAcctReq", jsonAccObject);
			payload = new JSONObject().put("GBOF0003Operation", jsonOpObject);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		logger.info("Request Payload::::" + payload);
		HttpEntity<String> entity = new HttpEntity<String>(payload.toString(), headers);
		// Service Response Logic Start
		ResponseEntity<OperationResponse> serviceResponse = restTemplate.exchange(URI, HttpMethod.POST, entity,
				OperationResponse.class);

		List<AccountInfoTable> accounts = serviceResponse
				.getBody().gBOF0003OperationResponse.getRelationshipAcctRes.accountInfoTable;

		logger.info("Accounts List ::::::" + accounts);
		creditCard = new ArrayList<CreditCardAccounts>();
		accounts.forEach(account -> {
			if (CustomerId != null) {
				if ((CustomerId.equals(account.getResponseCardNumber()))) {
					//logger.info(" Inside Account loop ::::::" + account.responseCustomerNumber);
					try {
						String status = "block";
						response = block(account.getResponseCardNumber(),status);
					} catch (IOException e) {
						e.printStackTrace();
					}
					
				}
			}
		});
		return response;
	}

	@Override
	public String blockCardByAccountId(String customerId, String accountId, HttpHeaders headers) throws IOException {
		String URI = Constant.URI;
		logger.info("Credit card service POST URI ::::" + URI);
		RestTemplate restTemplate = new RestTemplate();

		logger.info("***Request Header Object start");		
		headers.set("UUID",UUID.randomUUID().toString());
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		logger.info("Request Header :::" + headers);
		logger.info("****Request Body object start");

		JSONObject payload = null;
		JSONObject jsonOpObject = null;
		JSONObject jsonAccObject = null;
		try {
			jsonAccObject = new JSONObject();
			jsonAccObject.put("requestMessageId", Constant.REQ_MESSAGE_ID);
			jsonAccObject.put("requestVersionNumber", Constant.REQ_VERSION_NO);
			jsonAccObject.put("requestTerminalId", Constant.REQ_TERMINAL_ID);
			jsonAccObject.put("requestUserId", Constant.REQ_USER_ID);
			jsonAccObject.put("requestDateTime", Constant.REQ_DATE_TIME);
			jsonAccObject.put("requestChannelInd", Constant.REQ_CHANNEL_IND);
			jsonAccObject.put("requestCustomerOrg", Constant.REQ_CUST_ORG);
			jsonAccObject.put("requestRelationshipNumber", Constant.REQ_RELATIONSHIP_NO);
			jsonOpObject = new JSONObject().put("getRelationshipAcctReq", jsonAccObject);
			payload = new JSONObject().put("GBOF0003Operation", jsonOpObject);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		logger.info("Request Payload::::" + payload);
		HttpEntity<String> entity = new HttpEntity<String>(payload.toString(), headers);
		// Service Response Logic Start
		ResponseEntity<OperationResponse> serviceResponse = restTemplate.exchange(URI, HttpMethod.POST, entity,
				OperationResponse.class);

		List<AccountInfoTable> accounts = serviceResponse
				.getBody().gBOF0003OperationResponse.getRelationshipAcctRes.accountInfoTable;

		logger.info("Accounts List ::::::" + accounts);
		creditCard = new ArrayList<CreditCardAccounts>();
		accounts.forEach(account -> {
			if (customerId != null && accountId != null) {
				if (((customerId.equals(account.getResponseCustomerNumber()) && (accountId.equals(account.getResponseAccountNumber()))))) {
					logger.info(" Inside Account loop ::::::" + account.getResponseAccountNumber());
					try {
						String status = "block";
						response = block(account.getResponseAccountNumber(),status);
					} catch (IOException e) {
						e.printStackTrace();
					}
					
				}
			}
		});
		return response;
	}

}
