package com.citibanamex.api.cards.model;

import com.citibanamex.api.cards.model.GetRelationshipAcctRes;

public class GBOF0003OperationResponse {

	public GetRelationshipAcctRes getRelationshipAcctRes;

	/**
	 * @return the getRelationshipAcctRes
	 */
	public GetRelationshipAcctRes getGetRelationshipAcctRes() {
		return getRelationshipAcctRes;
	}

	/**
	 * @param getRelationshipAcctRes the getRelationshipAcctRes to set
	 */
	public void setGetRelationshipAcctRes(GetRelationshipAcctRes getRelationshipAcctRes) {
		this.getRelationshipAcctRes = getRelationshipAcctRes;
	}
}
