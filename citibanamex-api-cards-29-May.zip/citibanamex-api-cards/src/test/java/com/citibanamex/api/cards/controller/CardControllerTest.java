package com.citibanamex.api.cards.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.header;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import com.citibanamex.api.cards.CardsApplicationTest;
import com.citibanamex.api.cards.model.CardListResponse.CardResponse;
import com.citibanamex.api.cards.model.CardListResponse.Cards;
import com.citibanamex.api.cards.model.CardListResponse.CheckingAccounts;
import com.citibanamex.api.cards.model.CardListResponse.CreditCardAccounts;
import com.citibanamex.api.cards.model.CardListResponse.SavingsAccounts;
import com.citibanamex.api.cards.service.CardService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;


@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
public class CardControllerTest extends CardsApplicationTest{

	private CreditCardAccounts cc;
	private CardResponse cr;

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private CardService cardService;

	@Before
	public void setUp() throws Exception {
		cc = new CreditCardAccounts();
		cc.setAccountStatus("A");
		cc.setAccountId("0004053060600392296");
		cc.setProductName("A");
		cc.setDisplayAccountNumber("0004053060600392296");
		cc.setAccountNickname("S");
		cc.setOutstandingBalance(23333.00);
		cc.setCurrencyCode("000");
		Integer lastPaymentDate = 3162018;
		cc.setPaymentDueDate(Integer.toString(lastPaymentDate));
		Double balOflastStmt = 200.15;
		cc.setBalOfLastStmt(Double.toString(balOflastStmt));
		cc.setCreditLimit(3000);
		cc.setMinimumPaymentAmt("221212");
		Integer miniPaymentDueDate = 3162018;
		cc.setMinimumPaymentDueDate(Integer.toString(miniPaymentDueDate));

		ArrayList<CreditCardAccounts> creditCard = new ArrayList<CreditCardAccounts>();
		creditCard.add(cc);
		Cards cardsObject = new Cards();
		cardsObject.setCreditCardAccounts(creditCard);
		ArrayList<CheckingAccounts> checkingAccounts = new ArrayList<CheckingAccounts>();
		ArrayList<SavingsAccounts> savingsAccounts = new ArrayList<SavingsAccounts>();
		cardsObject.setCheckingAccounts(checkingAccounts);
		cardsObject.setSavingsAccounts(savingsAccounts);
		ArrayList<Cards> cards = new ArrayList<Cards>();
		cards.add(cardsObject);

		cr = new CardResponse();
		if (cr != null) {
			cr.setCards(cards);
		}
		System.out.println("Card Response ::::: " + cr.getCards().get(0).getCreditCardAccounts().get(0).getAccountId());
	}

	@Test
	public void testGetCardsByCustomerId() throws Exception {
		String customerId = "0005290910022122285";
		String ClientID = "client_id";
		//String authorization = "Basic dGVzdDAwMTpwd2QwMDE=";
		String client_id = "ffe4d269-1c59-493b-94f4-fbca960bc0f02";
		HttpHeaders hh = new HttpHeaders();
		hh.set("client_id", "ffe4d269-1c59-493b-94f4-fbca960bc0f0");
		hh.set("Authorization", "Basic dGVzdDAwMTpwd2QwMDE=");
		hh.set("UUID",UUID.randomUUID().toString());
		hh.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		hh.setContentType(MediaType.APPLICATION_JSON);

		when(cardService.getCardsByCustomer(customerId,hh)).thenReturn(cr);

		this.mockMvc.perform(get("/api/v1/customers/{customerId}/cards",customerId,hh))
		.andExpect(status().isOk())
		.andExpect(header().string("Authorization", "Basic dGVzdDAwMTpwd2QwMDE="))
		.andExpect(header().string("client_id", "ffe4d269-1c59-493b-94f4-fbca960bc0f0"))
		.andExpect(content().contentType(MediaType.APPLICATION_JSON)).andDo(print());
		
		/*MvcResult mvcResult = mockMvc.perform(get("/api/v1/customers/{customerId}/cards", customerId,hh))				
				.andExpect(status().isOk())
				.andExpect(header().string("Authorization", "Basic dGVzdDAwMTpwd2QwMDE="))
				.andExpect(header().string("client_id", "ffe4d269-1c59-493b-94f4-fbca960bc0f0"))
				.andExpect(content().contentType(MediaType.APPLICATION_JSON))
				.andReturn();
		ObjectMapper objectMapper = new ObjectMapper();

		CardResponse cardRes = objectMapper.readValue(mvcResult.getResponse().getContentAsString(),
				new TypeReference<CardResponse>() {
				});
		assertEquals(cardRes.getCards().get(0).getCreditCardAccounts().get(0).getAccountId(),
				cr.getCards().get(0).getCreditCardAccounts().get(0).getAccountId());*/		

	}
	
}
