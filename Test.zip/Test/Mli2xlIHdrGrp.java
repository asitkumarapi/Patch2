package com.citibanamex.api.cardsmaintenance.model.blockcardreq;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Mli2xlIHdrGrp {

	@JsonProperty("mli_2xl_i_message_id")
    private String mli2xlIMessageId;
    @JsonProperty("mli_2xl_i_version_nbr")
    private String mli2xlIVersionNbr;
    @JsonProperty("mli_2xl_i_terminal_id")
    private String mli2xlITerminalId;
    @JsonProperty("mli_2xl_i_user_id")
    private String mli2xlIUserId;
    @JsonProperty("mli_2xl_i_timestamp")
    private String mli2xlITimestamp;
    @JsonProperty("mli_2xl_i_org")
    private String mli2xlIOrg;
    @JsonProperty("mli_2xl_i_card_nbr")
    private String mli2xlICardNbr;
    @JsonProperty("mli_2xl_i_ovc_cd")
    private String mli2xlIOvcCd;
    @JsonProperty("mli_2xl_i_ovc_pur_days")
    private String mli2xlIOvcPurDays;
    public void setMli2xlIMessageId(String mli2xlIMessageId) {
         this.mli2xlIMessageId = mli2xlIMessageId;
     }
     public String getMli2xlIMessageId() {
         return mli2xlIMessageId;
     }

    public void setMli2xlIVersionNbr(String mli2xlIVersionNbr) {
         this.mli2xlIVersionNbr = mli2xlIVersionNbr;
     }
     public String getMli2xlIVersionNbr() {
         return mli2xlIVersionNbr;
     }

    public void setMli2xlITerminalId(String mli2xlITerminalId) {
         this.mli2xlITerminalId = mli2xlITerminalId;
     }
     public String getMli2xlITerminalId() {
         return mli2xlITerminalId;
     }

    public void setMli2xlIUserId(String mli2xlIUserId) {
         this.mli2xlIUserId = mli2xlIUserId;
     }
     public String getMli2xlIUserId() {
         return mli2xlIUserId;
     }

    public void setMli2xlITimestamp(String mli2xlITimestamp) {
         this.mli2xlITimestamp = mli2xlITimestamp;
     }
     public String getMli2xlITimestamp() {
         return mli2xlITimestamp;
     }

    public void setMli2xlIOrg(String mli2xlIOrg) {
         this.mli2xlIOrg = mli2xlIOrg;
     }
     public String getMli2xlIOrg() {
         return mli2xlIOrg;
     }

    public void setMli2xlICardNbr(String mli2xlICardNbr) {
         this.mli2xlICardNbr = mli2xlICardNbr;
     }
     public String getMli2xlICardNbr() {
         return mli2xlICardNbr;
     }

    public void setMli2xlIOvcCd(String mli2xlIOvcCd) {
         this.mli2xlIOvcCd = mli2xlIOvcCd;
     }
     public String getMli2xlIOvcCd() {
         return mli2xlIOvcCd;
     }

    public void setMli2xlIOvcPurDays(String mli2xlIOvcPurDays) {
         this.mli2xlIOvcPurDays = mli2xlIOvcPurDays;
     }
     public String getMli2xlIOvcPurDays() {
         return mli2xlIOvcPurDays;
     }
}
