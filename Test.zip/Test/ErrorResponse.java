package com.citibanamex.api.cardsmaintenance.model;

import java.util.List;

public class ErrorResponse {

	 private List<Error> error;
	    public void setErrors(List<Error> error) {
	         this.error = error;
	     }
	     public List<Error> getError() {
	         return error;
	     }

}
