package com.citibanamex.api.cardsmaintenance.model.blockcardreq;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Mli2xlIArea {

	@JsonProperty("mli_2xl_i_hdr_grp")
    private Mli2xlIHdrGrp mli2xlIHdrGrp;
    public void setMli2xlIHdrGrp(Mli2xlIHdrGrp mli2xlIHdrGrp) {
         this.mli2xlIHdrGrp = mli2xlIHdrGrp;
     }
     public Mli2xlIHdrGrp getMli2xlIHdrGrp() {
         return mli2xlIHdrGrp;
     }

}
