package com.citibanamex.api.cardsmaintenance.model.blockcardreq;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BlockCardRequest {

	 @JsonProperty("EWOEW2XLOperation")
	    private Ewoew2xloperation ewoew2xloperation;
	    public void setEwoew2xloperation(Ewoew2xloperation ewoew2xloperation) {
	         this.ewoew2xloperation = ewoew2xloperation;
	     }
	     public Ewoew2xloperation getEwoew2xloperation() {
	         return ewoew2xloperation;
	     }
}
