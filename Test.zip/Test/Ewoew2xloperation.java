package com.citibanamex.api.cardsmaintenance.model.blockcardreq;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Ewoew2xloperation {

	@JsonProperty("mli_2xl_i_area")
    private Mli2xlIArea mli2xlIArea;
    public void setMli2xlIArea(Mli2xlIArea mli2xlIArea) {
         this.mli2xlIArea = mli2xlIArea;
     }
     public Mli2xlIArea getMli2xlIArea() {
         return mli2xlIArea;
     }
}
