package com.citibanamex.api.cards.model.cardlistresp;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

/**
 * 
 * @author Asit Samantray
 *
 */
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class Card {

	private String addressEffDateFrm;
	private String addressEffDateTo;
	private String addressLine1;
	private String addressLine2;
	private String addressLine3;
	private String addressLine4;
	private String blockCode;
	private String cardNumber;
	private String city;
	private String country;
	private String deliveryIns;
	private String embossName;
	private String emergencyReplInd;
	private String feeIndicator;
	private String letterCode;
	private String newCardExpDate;
	private String plasticId;
	private String plasticIndicator;
	private String postCode;
	private String purgeDate;
	private String reasonCode;
	private String regionCode;
	private String renewalFlag;
	private String replaceInd24Hr;
	private String replacementMethod;
	private String requestFlag;
	private String sendToName;
	private String state;

	
	public Card() {
		super();
	}

	public String getAddressEffDateFrm() {
		return addressEffDateFrm;
	}

	public void setAddressEffDateFrm(String addressEffDateFrm) {
		this.addressEffDateFrm = addressEffDateFrm;
	}

	public String getAddressEffDateTo() {
		return addressEffDateTo;
	}

	public void setAddressEffDateTo(String addressEffDateTo) {
		this.addressEffDateTo = addressEffDateTo;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getAddressLine3() {
		return addressLine3;
	}

	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	public String getAddressLine4() {
		return addressLine4;
	}

	public void setAddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
	}

	public String getBlockCode() {
		return blockCode;
	}

	public void setBlockCode(String blockCode) {
		this.blockCode = blockCode;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getDeliveryIns() {
		return deliveryIns;
	}

	public void setDeliveryIns(String deliveryIns) {
		this.deliveryIns = deliveryIns;
	}

	public String getEmbossName() {
		return embossName;
	}

	public void setEmbossName(String embossName) {
		this.embossName = embossName;
	}

	public String getEmergencyReplInd() {
		return emergencyReplInd;
	}

	public void setEmergencyReplInd(String emergencyReplInd) {
		this.emergencyReplInd = emergencyReplInd;
	}

	public String getFeeIndicator() {
		return feeIndicator;
	}

	public void setFeeIndicator(String feeIndicator) {
		this.feeIndicator = feeIndicator;
	}

	public String getLetterCode() {
		return letterCode;
	}

	public void setLetterCode(String letterCode) {
		this.letterCode = letterCode;
	}

	public String getNewCardExpDate() {
		return newCardExpDate;
	}

	public void setNewCardExpDate(String newCardExpDate) {
		this.newCardExpDate = newCardExpDate;
	}

	public String getPlasticId() {
		return plasticId;
	}

	public void setPlasticId(String plasticId) {
		this.plasticId = plasticId;
	}

	public String getPlasticIndicator() {
		return plasticIndicator;
	}

	public void setPlasticIndicator(String plasticIndicator) {
		this.plasticIndicator = plasticIndicator;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getPurgeDate() {
		return purgeDate;
	}

	public void setPurgeDate(String purgeDate) {
		this.purgeDate = purgeDate;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	public String getRenewalFlag() {
		return renewalFlag;
	}

	public void setRenewalFlag(String renewalFlag) {
		this.renewalFlag = renewalFlag;
	}

	public String getReplaceInd24Hr() {
		return replaceInd24Hr;
	}

	public void setReplaceInd24Hr(String replaceInd24Hr) {
		this.replaceInd24Hr = replaceInd24Hr;
	}

	public String getReplacementMethod() {
		return replacementMethod;
	}

	public void setReplacementMethod(String replacementMethod) {
		this.replacementMethod = replacementMethod;
	}

	public String getRequestFlag() {
		return requestFlag;
	}

	public void setRequestFlag(String requestFlag) {
		this.requestFlag = requestFlag;
	}

	public String getSendToName() {
		return sendToName;
	}

	public void setSendToName(String sendToName) {
		this.sendToName = sendToName;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}



}
