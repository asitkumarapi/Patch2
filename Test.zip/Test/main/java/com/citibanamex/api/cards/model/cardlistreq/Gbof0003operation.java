package com.citibanamex.api.cards.model.cardlistreq;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Gbof0003operation {

	 @JsonProperty("getRelationshipAcctReq")
	    private Getrelationshipacctreq getrelationshipacctreq;
	    public void setGetrelationshipacctreq(Getrelationshipacctreq getrelationshipacctreq) {
	         this.getrelationshipacctreq = getrelationshipacctreq;
	     }
	     public Getrelationshipacctreq getGetrelationshipacctreq() {
	         return getrelationshipacctreq;
	     }
}
