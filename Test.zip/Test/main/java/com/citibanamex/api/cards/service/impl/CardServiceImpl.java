/**
 * 
 */
package com.citibanamex.api.cards.service.impl;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.citibanamex.api.cards.model.blockcardreq.BlockCardRequest;
import com.citibanamex.api.cards.model.blockcardresp.ResponseData;
import com.citibanamex.api.cards.model.cardlistreq.CardListPayload;
import com.citibanamex.api.cards.model.cardlistreq.Gbof0003operation;
import com.citibanamex.api.cards.model.cardlistreq.Getrelationshipacctreq;
import com.citibanamex.api.cards.model.cardlistresp.AccountInfoTable;
import com.citibanamex.api.cards.model.cardlistresp.CardResponse;
import com.citibanamex.api.cards.model.cardlistresp.Cards;
import com.citibanamex.api.cards.model.cardlistresp.CreditCardAccounts;
import com.citibanamex.api.cards.model.cardlistresp.CreditCardResponse;
import com.citibanamex.api.cards.model.cardlistresp.OperationResponse;
import com.citibanamex.api.cards.model.unblockcardreq.UnBlockCardRequest;
import com.citibanamex.api.cards.model.unblockcardresp.UnBlockCardResponse;
import com.citibanamex.api.cards.model.Constant;
import com.citibanamex.api.cards.service.CardService;

/**
 * @author Asit Samantray
 * Service implementation to retrive list of of credit cards based on customer relationship number.
 *
 */
@Service
public class CardServiceImpl implements CardService{

	public static final Logger logger = LoggerFactory.getLogger(CardServiceImpl.class);
	
	RestTemplate restTemplate = null;
	CreditCardResponse CCResponse = null;
	CardResponse cardResp = null;
	CreditCardAccounts creditCardAcc = null;
	ArrayList<CreditCardAccounts> creditCard = null;
	ArrayList<Cards> cards = null;
	Cards cardObject = null;
	String timeStamp = null;
	
	CardListPayload payload = null;
	Gbof0003operation operation = null;
	Getrelationshipacctreq req = null;
	
	@Override
	public CardResponse getCardsByCustomer(String customerId, HttpHeaders headers,Map<String, String> data) throws JSONException,DatatypeConfigurationException {
		disableSslVerification();
		restTemplate = new RestTemplate();
		GregorianCalendar gc = new GregorianCalendar();
		gc.setTimeInMillis(new Date().getTime());

		//***Request Header Object
		//headers.set("UUID",UUID.randomUUID().toString());
		headers.set("DateAndTimeStamp",DatatypeFactory.newInstance().newXMLGregorianCalendar(gc).toString());
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		//logger.info("Request Header :::" + headers);
		
		DateFormat df = new SimpleDateFormat("MMddyyyyHHmmss");
		String currentDateTime = df.format(new Date(System.currentTimeMillis()));		

		//****Request Body object
		payload = new CardListPayload();
		operation = new Gbof0003operation();
		req = new Getrelationshipacctreq();
		req.setRequestmessageid(Constant.REQ_MESSAGE_ID);
		req.setRequestversionnumber(Constant.REQ_VERSION_NO);
		req.setRequestchannelind(data.get("channelIndicator"));
		req.setRequestcustomerorg(data.get("org"));
		req.setRequestterminalid(data.get("terminalId"));
		req.setRequestrelationshipnumber(data.get("relationshipNumber"));
		req.setRequestdatetime(currentDateTime);
		req.setRequestuserid(data.get("userId"));
		operation.setGetrelationshipacctreq(req);
		payload.setGbof0003operation(operation);
		
		logger.info("Request Payload::::" + payload.toString());
		HttpEntity<?> entity = new HttpEntity<>(payload, headers);
		ResponseEntity<OperationResponse> serviceResponse = restTemplate.exchange(Constant.URI, HttpMethod.POST, entity,
				OperationResponse.class);

		List<AccountInfoTable> accounts = serviceResponse.getBody().gBOF0003OperationResponse.getRelationshipAcctRes.accountInfoTable;

		
		creditCard = new ArrayList<CreditCardAccounts>();
		accounts.forEach(account -> {
			if (customerId != null) {
				if (customerId.equals(account.getResponseCustomerNumber())) {
				//	logger.info(" Inside Account loop ::::::" + account.responseCustomerNumber);
					
					creditCardAcc = new CreditCardAccounts();
					creditCardAcc.setCardNumber(account.getResponseCardNumber());
					creditCardAcc.setAccountStatus(account.getAccountStatus());
					creditCardAcc.setAccountId(account.getResponseAccountNumber());
					creditCardAcc.setProductName(account.getCardType()); 
					creditCardAcc.setDisplayAccountNumber(account.getResponseAccountNumber());
					creditCardAcc.setAccountNickname(account.getEmbosserName()); 
					creditCardAcc.setOutstandingBalance(account.getAcctOutstandingAuthAmt()); 
					creditCardAcc.setCurrencyCode(account.getCurrencyCode()); 
					Integer lastPaymentDate = account.getPaymentDueDate(); 
					creditCardAcc.setPaymentDueDate(Integer.toString(lastPaymentDate));
					Double balOflastStmt = account.getEndingBalOfLastStmt();
					creditCardAcc.setBalOfLastStmt(Double.toString(balOflastStmt));
					creditCardAcc.setCreditLimit(account.getCardCreditLimit());
					creditCardAcc.setMinimumPaymentAmt(""); // no mapping element available
					Integer miniPaymentDueDate = account.getPaymentDueDate();
					creditCardAcc.setMinimumPaymentDueDate(Integer.toString(miniPaymentDueDate));
					creditCard.add(creditCardAcc);					
				}
			}
			// }
		});
		cardObject = new Cards();
		cardObject.setCreditCardAccounts(creditCard);
		cards = new ArrayList<Cards>();
		cards.add(cardObject);
		cardResp = new CardResponse();
		if (cardResp != null) {
			cardResp.setCards(cards);
		}
		logger.info("Service Response ::: " + cardResp);
		return cardResp;
	}	
	private static void disableSslVerification() {
		    try
		    {
		        // Create a trust manager that does not validate certificate chains
		        
		    	TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
		            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
		                return null;
		            }
		            public void checkClientTrusted(X509Certificate[] certs, String authType) {
		            }
		            public void checkServerTrusted(X509Certificate[] certs, String authType) {
		            }
		        }
		        };

		        // Install the all-trusting trust manager
		        SSLContext sc = SSLContext.getInstance("SSL");
		        sc.init(null, trustAllCerts, new java.security.SecureRandom());
		        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

		        // Create all-trusting host name verifier
		        HostnameVerifier allHostsValid = new HostnameVerifier() {

					@Override
					public boolean verify(String arg0, SSLSession arg1) {
						return true;
					}
		            
		        };

		        // Install the all-trusting host verifier
		        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
		    } catch (NoSuchAlgorithmException e) {
		        e.printStackTrace();
		    } catch (KeyManagementException e) {
		        e.printStackTrace();
		    }
		}


}
