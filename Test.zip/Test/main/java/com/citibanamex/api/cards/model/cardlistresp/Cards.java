package com.citibanamex.api.cards.model.cardlistresp;

import java.util.ArrayList;


public class Cards {

	private ArrayList<CreditCardAccounts> creditCardAccounts;
	
	public Cards() {
		super();
	}

	public ArrayList<CreditCardAccounts> getCreditCardAccounts() {
		return this.creditCardAccounts;
	}

	public void setCreditCardAccounts(ArrayList<CreditCardAccounts> creditCardAccounts) {
		this.creditCardAccounts = creditCardAccounts;
	}
}
