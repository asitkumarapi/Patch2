package com.citibanamex.api.cards.hateoas;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Response for HATEOAS approaching
 * 
 * @author Martin Barcenas
 *
 */
public class Response<T> extends ResourceSupport {

	public final T data;

	@JsonCreator
	public Response(@JsonProperty("data") T data) {
		this.data = data;
	}

	public final T getData() {
		return data;
	}

}
