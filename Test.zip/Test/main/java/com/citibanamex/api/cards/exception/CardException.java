package com.citibanamex.api.cards.exception;

import org.springframework.http.HttpStatus;

public class CardException {
	public void throwMissingParameterException() throws CustomException{
		CustomException ce = new CustomException("Missing parameters");
		ce.setCode(HttpStatus.BAD_REQUEST.value());
		ce.setMessage("Missing parameters");
		throw ce;
	}
	
	public void throwParameterLengthException() throws CustomException{
		CustomException ce = new CustomException("Missing");
		ce.setCode(HttpStatus.BAD_REQUEST.value());
		ce.setMessage("card number should be minimum 16-digits");
		throw ce;
	}

}
