package com.citibanamex.api.cards.model.unblockcardreq;

public class EWOEW2XMOperation {

	private Mli_2xm_i_area mli_2xm_i_area;	

    public EWOEW2XMOperation() {
		super();
	}
	public void setMli_2xm_i_area(Mli_2xm_i_area mli_2xm_i_area){
        this.mli_2xm_i_area = mli_2xm_i_area;
    }
    public Mli_2xm_i_area getMli_2xm_i_area(){
        return this.mli_2xm_i_area;
    }
}
