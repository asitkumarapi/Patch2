package com.citibanamex.api.cards.model.cardlistresp;

public class CreditCardResponse {

	private String accountStatus;
	private String accountId;
	private String productName;
	private String displayAccountNumber;
	private String accountNickname;
	private double outstandingBalance;
	private String currencyCode;
	private String paymentDueDate;
	private String balOfLastStmt;
	private double creditLimit;
	private String minimumPaymentAmt;
	private double minimumPaymentDueDate;
	
	public CreditCardResponse() {
		super();
	}
	/**
	 * @return the accountStatus
	 */
	public String getAccountStatus() {
		return accountStatus;
	}
	/**
	 * @param accountStatus the accountStatus to set
	 */
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	/**
	 * @return the accountId
	 */
	public String getAccountId() {
		return accountId;
	}
	/**
	 * @param accountId the accountId to set
	 */
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	/**
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}
	/**
	 * @param productName the productName to set
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}
	/**
	 * @return the displayAccountNumber
	 */
	public String getDisplayAccountNumber() {
		return displayAccountNumber;
	}
	/**
	 * @param displayAccountNumber the displayAccountNumber to set
	 */
	public void setDisplayAccountNumber(String displayAccountNumber) {
		this.displayAccountNumber = displayAccountNumber;
	}
	/**
	 * @return the accountNickname
	 */
	public String getAccountNickname() {
		return accountNickname;
	}
	/**
	 * @param accountNickname the accountNickname to set
	 */
	public void setAccountNickname(String accountNickname) {
		this.accountNickname = accountNickname;
	}
	/**
	 * @return the outstandingBalance
	 */
	public double getOutstandingBalance() {
		return outstandingBalance;
	}
	/**
	 * @param outstandingBalance the outstandingBalance to set
	 */
	public void setOutstandingBalance(double outstandingBalance) {
		this.outstandingBalance = outstandingBalance;
	}
	/**
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}
	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	/**
	 * @return the paymentDueDate
	 */
	public String getPaymentDueDate() {
		return paymentDueDate;
	}
	/**
	 * @param paymentDueDate the paymentDueDate to set
	 */
	public void setPaymentDueDate(String paymentDueDate) {
		this.paymentDueDate = paymentDueDate;
	}
	/**
	 * @return the balOfLastStmt
	 */
	public String getBalOfLastStmt() {
		return balOfLastStmt;
	}
	/**
	 * @param balOfLastStmt the balOfLastStmt to set
	 */
	public void setBalOfLastStmt(String balOfLastStmt) {
		this.balOfLastStmt = balOfLastStmt;
	}
	/**
	 * @return the creditLimit
	 */
	public double getCreditLimit() {
		return creditLimit;
	}
	/**
	 * @param creditLimit the creditLimit to set
	 */
	public void setCreditLimit(double creditLimit) {
		this.creditLimit = creditLimit;
	}
	/**
	 * @return the minimumPaymentAmt
	 */
	public String getMinimumPaymentAmt() {
		return minimumPaymentAmt;
	}
	/**
	 * @param minimumPaymentAmt the minimumPaymentAmt to set
	 */
	public void setMinimumPaymentAmt(String minimumPaymentAmt) {
		this.minimumPaymentAmt = minimumPaymentAmt;
	}
	/**
	 * @return the minimumPaymentDueDate
	 */
	public double getMinimumPaymentDueDate() {
		return minimumPaymentDueDate;
	}
	/**
	 * @param minimumPaymentDueDate the minimumPaymentDueDate to set
	 */
	public void setMinimumPaymentDueDate(double minimumPaymentDueDate) {
		this.minimumPaymentDueDate = minimumPaymentDueDate;
	}
}
