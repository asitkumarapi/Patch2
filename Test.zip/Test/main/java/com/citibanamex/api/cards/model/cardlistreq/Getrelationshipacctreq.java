package com.citibanamex.api.cards.model.cardlistreq;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Getrelationshipacctreq {

	 @JsonProperty("requestTerminalId")
	    private String requestterminalid;
	    @JsonProperty("requestRelationshipNumber")
	    private String requestrelationshipnumber;
	    @JsonProperty("requestDateTime")
	    private String requestdatetime;
	    @JsonProperty("requestMessageId")
	    private String requestmessageid;
	    @JsonProperty("requestUserId")
	    private String requestuserid;
	    @JsonProperty("requestCustomerOrg")
	    private String requestcustomerorg;
	    @JsonProperty("requestVersionNumber")
	    private int requestversionnumber;
	    @JsonProperty("requestChannelInd")
	    private String requestchannelind;
	    public void setRequestterminalid(String requestterminalid) {
	         this.requestterminalid = requestterminalid;
	     }
	     public String getRequestterminalid() {
	         return requestterminalid;
	     }

	    public void setRequestrelationshipnumber(String requestrelationshipnumber) {
	         this.requestrelationshipnumber = requestrelationshipnumber;
	     }
	     public String getRequestrelationshipnumber() {
	         return requestrelationshipnumber;
	     }

	    public void setRequestdatetime(String requestdatetime) {
	         this.requestdatetime = requestdatetime;
	     }
	     public String getRequestdatetime() {
	         return requestdatetime;
	     }

	    public void setRequestmessageid(String requestmessageid) {
	         this.requestmessageid = requestmessageid;
	     }
	     public String getRequestmessageid() {
	         return requestmessageid;
	     }

	    public void setRequestuserid(String requestuserid) {
	         this.requestuserid = requestuserid;
	     }
	     public String getRequestuserid() {
	         return requestuserid;
	     }

	    public void setRequestcustomerorg(String requestcustomerorg) {
	         this.requestcustomerorg = requestcustomerorg;
	     }
	     public String getRequestcustomerorg() {
	         return requestcustomerorg;
	     }

	    public void setRequestversionnumber(int requestversionnumber) {
	         this.requestversionnumber = requestversionnumber;
	     }
	     public int getRequestversionnumber() {
	         return requestversionnumber;
	     }

	    public void setRequestchannelind(String requestchannelind) {
	         this.requestchannelind = requestchannelind;
	     }
	     public String getRequestchannelind() {
	         return requestchannelind;
	     }

}
