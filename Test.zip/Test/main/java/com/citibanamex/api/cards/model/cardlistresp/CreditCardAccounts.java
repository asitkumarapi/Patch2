package com.citibanamex.api.cards.model.cardlistresp;

public class CreditCardAccounts {

	private String cardNumber;
	private String accountStatus;
	private String accountId;
	private String productName;
	private String displayAccountNumber;
	private String accountNickname;
	private double outstandingBalance;
	private String currencyCode;
	private String paymentDueDate;
	private String balOfLastStmt;
	private double creditLimit;
	private String minimumPaymentAmt;
	private String minimumPaymentDueDate;

	public String getAccountStatus() {
		return this.accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

	public String getAccountId() {
		return this.accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getProductName() {
		return this.productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getDisplayAccountNumber() {
		return this.displayAccountNumber;
	}

	public void setDisplayAccountNumber(String displayAccountNumber) {
		this.displayAccountNumber = displayAccountNumber;
	}

	public String getAccountNickname() {
		return this.accountNickname;
	}

	public void setAccountNickname(String accountNickname) {
		this.accountNickname = accountNickname;
	}

	public double getOutstandingBalance() {
		return this.outstandingBalance;
	}

	public void setOutstandingBalance(double outstandingBalance) {
		this.outstandingBalance = outstandingBalance;
	}

	public String getCurrencyCode() {
		return this.currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getPaymentDueDate() {
		return this.paymentDueDate;
	}

	public void setPaymentDueDate(String paymentDueDate) {
		this.paymentDueDate = paymentDueDate;
	}

	public String getBalOfLastStmt() {
		return this.balOfLastStmt;
	}

	public void setBalOfLastStmt(String balOfLastStmt) {
		this.balOfLastStmt = balOfLastStmt;
	}

	public double getCreditLimit() {
		return this.creditLimit;
	}

	public void setCreditLimit(double creditLimit) {
		this.creditLimit = creditLimit;
	}

	public String getMinimumPaymentAmt() {
		return this.minimumPaymentAmt;
	}

	public void setMinimumPaymentAmt(String minimumPaymentAmt) {
		this.minimumPaymentAmt = minimumPaymentAmt;
	}

	public String getMinimumPaymentDueDate() {
		return this.minimumPaymentDueDate;
	}

	public void setMinimumPaymentDueDate(String minimumPaymentDueDate) {
		this.minimumPaymentDueDate = minimumPaymentDueDate;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

}
