package com.citibanamex.api.cardsmaintenance.Handler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;


import com.citibanamex.api.cardsmaintenance.model.ErrorResponse;
import com.citibanamex.api.cardsmaintenance.Exception.CustomException;
import com.citibanamex.api.cardsmaintenance.model.Error;

@ControllerAdvice  
@RestController
public class GlobalExceptionHandler {
	private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);
	ErrorResponse errorResponse = null;
	List<Error> errors = null;
	Error error = null;
	@ExceptionHandler(value = Exception.class)
	public ResponseEntity<ErrorResponse> generalException(Exception e) throws Exception {
		/*ExceptionResponse eR = new ExceptionResponse();
		eR.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		eR.setErrorMessage("Internal server error");
		eR.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.name());
		logger.info("Http response -" + eR.getCode() + "-" + eR.getDescription() + "-" + eR.getErrorMessage());*/
		errorResponse = new ErrorResponse();
		error = new Error();
		error.setType("Fatal");
		error.setCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
		error.setDetails(HttpStatus.INTERNAL_SERVER_ERROR.name());
		error.setLocation("");
		error.setMoreinfo("Internal server error");
		errors = new ArrayList<Error>();
		errors.add(error);
		return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(value = CustomException.class)
	public ResponseEntity<ErrorResponse> specialException(CustomException e) throws Exception {
		/*ExceptionResponse eR = new ExceptionResponse();
		eR.setCode(HttpStatus.BAD_REQUEST.value());
		eR.setErrorMessage("Bad Request");
		eR.setDescription(e.getMessage());
		logger.info("Http response -" + eR.getCode() + "-" + eR.getDescription() + "-" + eR.getErrorMessage());*/
		errorResponse = new ErrorResponse();
		error = new Error();
		error.setType("Error");
		error.setCode(String.valueOf(HttpStatus.BAD_REQUEST.value()));
		error.setDetails(HttpStatus.INTERNAL_SERVER_ERROR.name());
		error.setLocation("");
		error.setMoreinfo("Bad request error");
		errors = new ArrayList<Error>();
		errors.add(error);
		return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler({IllegalArgumentException.class, NullPointerException.class})
	public ResponseEntity<ErrorResponse> handleBadRequests(HttpServletResponse response) throws IOException {
	    
	    return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.BAD_REQUEST);
	}


}
