/*
 * Copyright Banco Nacional de Mexico, S.A.
 * Integrante de Grupo Financiero Banamex.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
package com.citibanamex.api.locator.atm.exceptions;

/**
 * This is a Error Response Class to return error object
 * 
 * @author AM241297
 *
 */
public class Response {
	private String type;
	private String details;
	private int code;
	private String moreInfo;
	private Long location;
	
	/**
	 * Default Constructor
	 */
	public Response(){}

	/**
	 * Parameterized Constructor
	 * @param description
	 * @param errorCode
	 * @param message
	 * @param timeStamp
	 */
	public Response(String description, int errorCode, String message, long timeStamp) {
		super();
		this.details= description;
		this.code = errorCode;
		this.moreInfo = message;
		this.location = timeStamp;
	}


	/**
	 * To get errorCode
	 * 
	 * @return errorCode
	 */
	public int getCode() {
		return code;
	}

	/**
	 * To ser errorCode
	 * 
	 * @param errorCode
	 */
	public void setCode(int errorCode) {
		this.code = errorCode;
	}

	/**
	 * To get message
	 * 
	 * @return message
	 */
	public String getMoreInfo() {
		return moreInfo;
	}

	/**
	 * To set message
	 * 
	 * @param message
	 */
	public void setMoreInfo(String message) {
		this.moreInfo = message;
	}

	/**
	 * To get description
	 * 
	 * @return description
	 */
	public String getDetails() {
		return details;
	}

	/**
	 * To set description
	 * 
	 * @param description
	 */
	public void setDetails(String description) {
		this.details = description;
	}

	/**
	 * To get timeStamp
	 * 
	 * @return timeStamp
	 */
	public long getLocation() {
		return location;
	}

	/**
	 * To set timeStamp
	 * 
	 * @param timeStamp
	 */
	public void setLocation(long timeStamp) {
		this.location = timeStamp;
	}
	/**
	 * To get status
	 * @return status
	 */
	public String getType() {
		return type;
	}
	/**
	 * To set status
	 * @param status
	 */
	public void setType(String status) {
		this.type = status;
	}

}
