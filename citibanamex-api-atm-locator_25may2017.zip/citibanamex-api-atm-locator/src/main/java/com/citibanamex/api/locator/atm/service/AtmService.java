/*
 * Copyright Banco Nacional de Mexico, S.A.
 * Integrante de Grupo Financiero Banamex.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */

package com.citibanamex.api.locator.atm.service;

import com.citibanamex.api.locator.atm.model.Response;

/**
 * This is a service class to fetch list of nearby banamex ATMs from google places api.
 * @author AM241297
 *
 */
public interface AtmService {
	/**
	 * This method is to fetch list of nearby banamex ATMs by calling google places API.
	 * @param type
	 * @param radius
	 * @param address
	 * @param nextStartIndex
	 * @return list of ATMs
	 * @throws InterruptedException 
	 */
	Response getNearByAtmsOrBranches(String type, String radius, String addressLine1,String addressLine2, String nextStartIndex) throws InterruptedException;
}
