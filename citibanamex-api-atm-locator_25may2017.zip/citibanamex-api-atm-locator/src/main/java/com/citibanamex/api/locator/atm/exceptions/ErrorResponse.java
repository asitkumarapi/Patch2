/*
 * Copyright Banco Nacional de Mexico, S.A.
 * Integrante de Grupo Financiero Banamex.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
package com.citibanamex.api.locator.atm.exceptions;

import java.util.List;

/**
 * This is a Error Response Class to return error object
 * 
 * @author 
 *
 */
public class ErrorResponse {
	 
	private List<Response> errors;

	public List<Response> getErrors() {
		return errors;
	}

	public void setErrors(List<Response> error) {
		this.errors = error;
	}

	@Override
	public String toString() {
		return "ErrorResponse [error=" + errors + "]";
	}
	
	
	
}
