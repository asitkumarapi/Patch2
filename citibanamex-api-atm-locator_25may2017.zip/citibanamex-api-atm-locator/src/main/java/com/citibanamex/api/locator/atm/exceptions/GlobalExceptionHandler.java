/*
 * Copyright Banco Nacional de Mexico, S.A.
 * Integrante de Grupo Financiero Banamex.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
package com.citibanamex.api.locator.atm.exceptions;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

/**
 * This is a GlobalExceptionHandler class to handle all Exceptions
 * 
 * @author AM241297
 *
 */
@RestControllerAdvice
@EnableWebMvc
public class GlobalExceptionHandler {
	private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);
	/**
	 * This method is to handle BadRequestException category
	 * 
	 * @param BadRequestException
	 * @return Response
	 */
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(value = BadRequestException.class)
	public ResponseEntity<?> handleBadRequestException(BadRequestException ex) {
		Response respObj = new Response();
		ErrorResponse errorResponseObj= new ErrorResponse();
		respObj.setType("FAILURE");
		respObj.setCode(HttpStatus.BAD_REQUEST.value());
		respObj.setDetails("Bad Request");
		respObj.setMoreInfo("Invalid 'radius' or/and 'addressLine1' parameters");
		respObj.setLocation(new Date().getTime());	
		List<Response> respList = new ArrayList<>();
		respList.add(respObj);
		errorResponseObj.setErrors(respList);	
		
		logger.info("Http response -" + respObj.getCode() + "-" + respObj.getDetails() + "-" + respObj.getMoreInfo());
		return new ResponseEntity<ErrorResponse>(errorResponseObj, HttpStatus.BAD_REQUEST);
	}

	/**
	 * This method is to handle BaseException category
	 * 
	 * @param ServerError
	 * @return Response
	 */
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(value = ServerError.class)
	public ResponseEntity<?> handleBaseException(ServerError e) {
		Response response = new Response();
		response.setType("FAILURE");
		response.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		response.setDetails("Internal Server Error");
		response.setLocation(new Date().getTime());
		response.setMoreInfo("Internal Server Error");	
		
		ErrorResponse errorResponseObj= new ErrorResponse();
		List<Response> respList = new ArrayList<>();
		respList.add(response);
		errorResponseObj.setErrors(respList);
		
		logger.info("Http response -" + response.getCode() + "-" + response.getDetails() + "-" + response.getMoreInfo());
		return new ResponseEntity<ErrorResponse>(errorResponseObj, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	/**
	 * This method is to handle NotFoundException category
	 * 
	 * @param NotFoundException
	 * @return Response
	 */
	@ExceptionHandler
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	@ResponseBody
	public ResponseEntity<?> handleResourceNotFoundException(final NoHandlerFoundException ex) {
		Response eR = new Response();
		eR.setType("FAILURE");
		eR.setCode(HttpStatus.NOT_FOUND.value());
		eR.setDetails("Resource Not Found");
		eR.setMoreInfo("Resource you are trying to reach is not found");
		eR.setLocation(new Date().getTime());	
		ErrorResponse errorResponseObj= new ErrorResponse();
		List<Response> respList = new ArrayList<>();
		respList.add(eR);
		errorResponseObj.setErrors(respList);
		
		logger.info("Http response -" + eR.getCode() + "-" + eR.getDetails() + "-" + eR.getMoreInfo());
		return new ResponseEntity<ErrorResponse>(errorResponseObj, HttpStatus.NOT_FOUND);
	}

	/**
	 * This method is to handle NotFoundException category
	 * 
	 * @param NotFoundException
	 * @return Response
	 */
	@ResponseStatus(HttpStatus.OK)
	@ExceptionHandler(value = DataNotFoundException.class)
	public ResponseEntity<?> handleDataNotFoundException(DataNotFoundException ne) {
		Response resp = new Response();
		resp.setType("SUCCESS");		
		resp.setCode(HttpStatus.OK.value());
		resp.setDetails("Data Not Found");
		resp.setLocation(new Date().getTime());
		resp.setMoreInfo("0 Results Returned");
		logger.info("Http response -" + resp.getCode() + "-" + resp.getDetails() + "-" + resp.getMoreInfo());
		ErrorResponse errorResponseObj= new ErrorResponse();
		List<Response> respList = new ArrayList<>();
		respList.add(resp);
		errorResponseObj.setErrors(respList);		
		
		return new ResponseEntity<ErrorResponse>(errorResponseObj, HttpStatus.OK);
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MissingServletRequestParameterException.class)
	public ResponseEntity<?> handleMissingParams(MissingServletRequestParameterException ex) {
		Response resp = new Response();
		
		resp.setType("SUCCESS");
		resp.setCode(HttpStatus.BAD_REQUEST.value());
		resp.setDetails("The 'radius' and 'addressLine1' parameters required");
		resp.setLocation(new Date().getTime());
		resp.setMoreInfo("Missing Request Parameters");
		logger.info("Http response -" + resp.getCode() + "-" + resp.getDetails() + "-" + resp.getMoreInfo());
		ErrorResponse errorResponseObj= new ErrorResponse();
		List<Response> respList = new ArrayList<>();
		respList.add(resp);
		errorResponseObj.setErrors(respList);		
				
		return new ResponseEntity<ErrorResponse>(errorResponseObj, HttpStatus.BAD_REQUEST);
	}
}
