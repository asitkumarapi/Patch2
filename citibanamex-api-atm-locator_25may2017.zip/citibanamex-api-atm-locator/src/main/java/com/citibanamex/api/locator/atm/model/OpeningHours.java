package com.citibanamex.api.locator.atm.model;

import java.util.List;
public class OpeningHours
{
    private boolean open_now;

    private List<String> weekday_text;

    public void setOpen_now(boolean open_now){
        this.open_now = open_now;
    }
    public boolean getOpen_now(){
        return this.open_now;
    }
    public void setWeekday_text(List<String> weekday_text){
        this.weekday_text = weekday_text;
    }
    public List<String> getWeekday_text(){
        return this.weekday_text;
    }
}
