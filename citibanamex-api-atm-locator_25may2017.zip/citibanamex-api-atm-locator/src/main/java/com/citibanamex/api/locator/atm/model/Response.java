/*
 * Copyright Banco Nacional de Mexico, S.A.
 * Integrante de Grupo Financiero Banamex.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
package com.citibanamex.api.locator.atm.model;

import java.util.List;

/**
 * This is a ATM Branch locator Resource Model class
 * 
 * @author AM241297
 *
 */
public class Response {

	private List<ATM> facility;
	private String nextStartIndex;
	public List<ATM> getFacility() {
		return facility;
	}
	public void setFacility(List<ATM> facility) {
		this.facility = facility;
	}
	public String getNextStartIndex() {
		return nextStartIndex;
	}
	public void setNextStartIndex(String nextStartIndex) {
		this.nextStartIndex = nextStartIndex;
	}
	@Override
	public String toString() {
		return "Response [facility=" + facility + ", nextStartIndex=" + nextStartIndex + "]";
	}
		
	
}
