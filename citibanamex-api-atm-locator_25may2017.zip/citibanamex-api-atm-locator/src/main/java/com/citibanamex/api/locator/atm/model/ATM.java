/*
 * Copyright Banco Nacional de Mexico, S.A.
 * Integrante de Grupo Financiero Banamex.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
package com.citibanamex.api.locator.atm.model;

/**
 * This is a ATM Branch locator Resource Model class
 * 
 * @author AM241297
 *
 */
public class ATM {

	private String facilityType;
	private String facilityName;
	private Address address;
	private GeographicalLocation geographicalLocation;
	private Boolean currentlyOpenFlag;
	private String availableTimes;
	private String phoneNumber;
	public String getFacilityType() {
		return facilityType;
	}
	public void setFacilityType(String facilityType) {
		this.facilityType = facilityType;
	}
	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public Boolean getCurrentlyOpenFlag() {
		return currentlyOpenFlag;
	}
	public void setCurrentlyOpenFlag(Boolean currentlyOpenFlag) {
		this.currentlyOpenFlag = currentlyOpenFlag;
	}
	public String getAvailableTimes() {
		return availableTimes;
	}
	public void setAvailableTimes(String availableTimes) {
		this.availableTimes = availableTimes;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public GeographicalLocation getGeographicalLocation() {
		return geographicalLocation;
	}
	public void setGeographicalLocation(GeographicalLocation geographicalLocation) {
		this.geographicalLocation = geographicalLocation;
	}
	@Override
	public String toString() {
		return "ATM [facilityType=" + facilityType + ", facilityName=" + facilityName + ", address=" + address
				+ ", geographicalLocation=" + geographicalLocation + ", currentlyOpenFlag=" + currentlyOpenFlag
				+ ", availableTimes=" + availableTimes + ", phoneNumber=" + phoneNumber + "]";
	}
	
}
