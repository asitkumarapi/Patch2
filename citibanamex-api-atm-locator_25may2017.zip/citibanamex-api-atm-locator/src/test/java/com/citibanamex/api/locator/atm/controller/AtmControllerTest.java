/*
 * Copyright Banco Nacional de Mexico, S.A.
 * Integrante de Grupo Financiero Banamex.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
package com.citibanamex.api.locator.atm.controller;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.citibanamex.api.locator.atm.model.ATM;
import com.citibanamex.api.locator.atm.model.Location;
import com.citibanamex.api.locator.atm.model.Response;
import com.citibanamex.api.locator.atm.service.AtmService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * This is a AtmController test class to verify the functionality
 * 
 * @author AM241297
 *
 */
@RunWith(SpringRunner.class)
@WebMvcTest(AtmController.class)
@ComponentScan("com.citibanamex.api.locator.atm.service")
public class AtmControllerTest {
	Response atms = null;
	ATM atm1 = null;
	ATM atm2 = null;
	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private AtmService service;

	/**
	 * This setUp method is for initializing work
	 * 
	 * @throws InterruptedException
	 */
	@Before
	public void setUp() throws InterruptedException {
		atms = service.getNearByAtmsOrBranches("","1000", "bosque+de+duraznos+78+Mexico+city","ATM", " ");
		atm1 = new ATM();
		atm1.setFacilityType("atm");
		atm1.setFacilityName("Banamex Plaza Bosques");
	}

	/**
	 * This funtion is to test the status codes
	 * 
	 * @throws Exception
	 */
	@Test
	public void testGetNearByAtmsStatus() throws Exception {
		this.mockMvc
				.perform(get("/v1/bank/facility/locator?radius=5000&addressLine1=bosque+de+duraznos+78&facilityType=ATM")
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(content().contentType("application/json;charset=UTF-8"));
		this.mockMvc.perform(get("/v1/bank/facility/locator?radius=1000&addressLine1=bosque+de+duraznos+78&facilityType=BRANCH"))
				.andDo(print());
	}

	/**
	 * This function is test the actual functionality of getNearByAtms
	 * controller.
	 * 
	 * @throws Exception
	 */
	@Test
	public void testGetNearByAtms() throws Exception {
		MvcResult result = this.mockMvc
				.perform(get("/v1/bank/facility/locator?radius=1000&addressLine1=bosque+de+duraznos+78&facilityType=BOTH"))
				.andReturn();
	/*	ObjectMapper objectMapper = new ObjectMapper();
		Response atmslist = objectMapper.readValue(result.getResponse().getContentAsString(),
				new TypeReference<Iterable<ATM>>() {
				});*/
	}
}
