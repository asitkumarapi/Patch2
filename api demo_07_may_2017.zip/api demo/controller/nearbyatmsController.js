'use strick';
// create the controller and inject Angular's $scope
	citiApp.controller('nearbyatmsController', ['$scope','cardlistService','$route',function($scope,cardlistService,$route) {

        $scope.address="";
        $scope.addressline1="";
        $scope.addressline2="";
		$scope.radius="";
        $scope.radiuslist = [1000,2000,3000,4000,5000];
        $scope.facilitytypelist = ["atm","bank","atm|bank"];
        $scope.facilitytype="";
	
	
		$scope.searchatm=function(facilitytype,radious,addressline1,addressline2){
			//alert(" Am here "+facilitytype+radious+addressline1+addressline2);
			$scope.address=addressline1+" "+addressline2;
		cardlistService.nearbyatms(facilitytype,radious,$scope.address).success(function(data) {
			$scope.nearbyatmslist=data;
			console.log("return data ");
			console.log($scope.nearbyatmslist);
		});	
			
		};
	     

	}]);

	