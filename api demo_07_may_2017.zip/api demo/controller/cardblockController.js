'use strick';
// create the controller and inject Angular's $scope
	citiApp.controller('cardblockController', ['$scope','cardlistService','$route',function($scope,cardlistService,$route) {

        $scope.cardno = "";
        $scope.unblockcardno = "";
        $scope.blockedmsg = "";
        $scope.unblockedmsg = "";


        $scope.blockcard = function (cardno) {
            //alert(" Am here "+cardno);
            var cardObj = {
                "payload": {
                    "cardNumber": cardno,
                    "durationdays": 10
                }
            };
            $scope.blockedmsg = cardno + " has been blocked successfully";
            cardlistService.cardblock(cardObj).success(function (data) {
                $scope.nearbyatmslist = data;
                console.log("return data ");

            });

        };
        $scope.unblockcard = function (cardno) {
            //  alert(" Am here to unblock "+cardno);


            cardlistService.uncardblock(cardno).success(function (data) {
                $scope.nearbyatmslist = data;
                console.log("return data ");
                $scope.unblockedmsg = cardno + " has been Unblocked successfully";

            });

        };


        $scope.getListofcards = function (cardno) {
            cardlistService.cardblockandunblocklist(cardno).success(function (data) {
                $scope.carlistdata = data.GBOF0003OperationResponse.getRelationshipAcctRes.accountInfoTable;;
                $scope.embosserName = "";
                $scope.responseCardNumber = "";
                $scope.currentBalance = "";
                $scope.cardType = "";
                $scope.cardStatus = "";
                $scope.cardCashLimit = "";
                $scope.lastPaymentDate = "";
                $scope.thankYouPoints = "";
                $scope.minimumPaymentDueDate = "";
                console.log("JSON data 123");
                console.log(data);

                console.log($scope.carlistdata);


            });
        }
    }]);



	