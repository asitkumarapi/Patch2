'use strick';
// create the controller and inject Angular's $scope
	citiApp.controller('myaccountController', ['$scope','cardlistService','$route',function($scope,cardlistService,$route) {

        $scope.accountno="";
        $scope.customerid="";
        $scope.branchid="";
		$scope.cashcode="";
		$scope.showhistory=false;
		$scope.showdetails=false;

	    $scope.showHistoryFunction=function(){
            $scope.showhistory=!$scope.showhistory;
        }
		$scope.searchAccountDetails=function(accountno,customerid,branchid,cashcode){
			//alert(" Am here "+accountno+customerid+branchid+cashcode);
            $scope.showdetails=true;
			$scope.accountRequestObj={
                "accountNumber": accountno,
                "bigCustomerID": customerid,
                "branchNumber": branchid,
                "cashCode": cashcode,
                "nextMovement": "",
                "prefix": 0,
                "subCodeTx": 781
            };
         console.log("Inpur  request object");
         console.log($scope.accountRequestObj);
		cardlistService.searchAccountDetails($scope.accountRequestObj).success(function(data) {

			console.log("return data ");
            console.log(data);
            $scope.accountDetails=data;


		});
			
		};
	     

	}]);

	