package com.citibanamex.api.cards;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = CardsApplication.class, webEnvironment = WebEnvironment.RANDOM_PORT)
public abstract class CardsApplicationTest {

	@LocalServerPort
    private int port;
	RestTemplate restTemplate;
	Map req = null;
	@Test
    public void TestGetCardsByCustomer() throws Exception {
        URI uri = URI.create("https://localhost:" + port + "");
        
       // Map<String, Object> whoami = restTemplate.getForObject(uri, Map.class);
       // assertThat(whoami).containsEntry("name", "client");
    }
	
}
