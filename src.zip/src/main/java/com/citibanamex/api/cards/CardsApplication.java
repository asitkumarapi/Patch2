package com.citibanamex.api.cards;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import com.citibanamex.web.annotation.ApiVersionRequestMappingHandlerMapping;
import org.springframework.ws.soap.security.support.KeyManagersFactoryBean;
import org.springframework.ws.soap.security.support.KeyStoreFactoryBean;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import static springfox.documentation.builders.PathSelectors.regex;

@SpringBootApplication
@EnableSwagger2
public class CardsApplication {

private static final Logger logger = LoggerFactory.getLogger(CardsApplication.class);
	
	@Value("${citi.security.uat.keyStore}")
	Resource keyStoreLocation;	

	public static void main(String[] args) {
		SpringApplication.run(CardsApplication.class, args);
	}
	
	@Bean
	public KeyStoreFactoryBean keyStore() {

		logger.info("############################## keyStore");
		logger.info("############################## keyStore" + keyStoreLocation.getFilename());

		KeyStoreFactoryBean keyStoreFactoryBean = new KeyStoreFactoryBean();
		keyStoreFactoryBean.setLocation(keyStoreLocation);
		keyStoreFactoryBean.setPassword("changeit");

		return keyStoreFactoryBean;
	}


	@Bean
	public KeyManagersFactoryBean keyManagersFactoryBean() {

		logger.info("############################## keyManagersFactoryBean");
		KeyManagersFactoryBean keyManagersFactoryBean = new KeyManagersFactoryBean();
		keyManagersFactoryBean.setKeyStore(keyStore().getObject());
		keyManagersFactoryBean.setPassword("rmxusr");

		return keyManagersFactoryBean;
	}
	
	@Bean
	public Docket newsApi() {
		return new Docket(DocumentationType.SWAGGER_2)
				.groupName("CreditCards API")
				.apiInfo(apiInfo())
				.select()
				.paths(regex("/customers.*"))
				.build();
	}
	                            
	private ApiInfo apiInfo() {
		return new ApiInfoBuilder()
				.title("Spring REST Cards API Sample with Swagger")
				.description("Spring REST Cards API Sample with Swagger")
				.termsOfServiceUrl("http://www-03.ibm.com/software/sla/sladb.nsf/sla/bm?Open")
				.license("Apache License Version 2.0")
				.licenseUrl("https://github.com/IBM-Bluemix/news-aggregator/blob/master/LICENSE").version("2.0")
				.build();
	}
	
	@Configuration
	public static class WebMvcConfig extends WebMvcConfigurationSupport {
		@Override
		public RequestMappingHandlerMapping requestMappingHandlerMapping() {
			return new ApiVersionRequestMappingHandlerMapping("api/v");
		}

	}
}
