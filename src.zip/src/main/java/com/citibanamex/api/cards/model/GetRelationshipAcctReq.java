package com.citibanamex.api.cards.model;

public class GetRelationshipAcctReq {

	public String requestTerminalId;

	public String requestRelationshipNumber;

	public String requestDateTime;

	public String requestMessageId;

	public String requestUserId;

	public String requestCustomerOrg;

	public int requestVersionNumber;

	public String requestChannelInd;

    public void setRequestTerminalId(String requestTerminalId){
        this.requestTerminalId = requestTerminalId;
    }
    public String getRequestTerminalId(){
        return this.requestTerminalId;
    }
    public void setRequestRelationshipNumber(String requestRelationshipNumber){
        this.requestRelationshipNumber = requestRelationshipNumber;
    }
    public String getRequestRelationshipNumber(){
        return this.requestRelationshipNumber;
    }
    public void setRequestDateTime(String requestDateTime){
        this.requestDateTime = requestDateTime;
    }
    public String getRequestDateTime(){
        return this.requestDateTime;
    }
    public void setRequestMessageId(String requestMessageId){
        this.requestMessageId = requestMessageId;
    }
    public String getRequestMessageId(){
        return this.requestMessageId;
    }
    public void setRequestUserId(String requestUserId){
        this.requestUserId = requestUserId;
    }
    public String getRequestUserId(){
        return this.requestUserId;
    }
    public void setRequestCustomerOrg(String requestCustomerOrg){
        this.requestCustomerOrg = requestCustomerOrg;
    }
    public String getRequestCustomerOrg(){
        return this.requestCustomerOrg;
    }
    public void setRequestVersionNumber(int requestVersionNumber){
        this.requestVersionNumber = requestVersionNumber;
    }
    public int getRequestVersionNumber(){
        return this.requestVersionNumber;
    }
    public void setRequestChannelInd(String requestChannelInd){
        this.requestChannelInd = requestChannelInd;
    }
    public String getRequestChannelInd(){
        return this.requestChannelInd;
    }
}
