package com.citibanamex.api.cards.model.CardListResponse;

public class CreditCardAccounts {

	private String accountStatus;

	public String getAccountStatus() {
		return this.accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

	private String accountId;

	public String getAccountId() {
		return this.accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	private String productName;

	public String getProductName() {
		return this.productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	private String displayAccountNumber;

	public String getDisplayAccountNumber() {
		return this.displayAccountNumber;
	}

	public void setDisplayAccountNumber(String displayAccountNumber) {
		this.displayAccountNumber = displayAccountNumber;
	}

	private String accountNickname;

	public String getAccountNickname() {
		return this.accountNickname;
	}

	public void setAccountNickname(String accountNickname) {
		this.accountNickname = accountNickname;
	}

	private double outstandingBalance;

	public double getOutstandingBalance() {
		return this.outstandingBalance;
	}

	public void setOutstandingBalance(double outstandingBalance) {
		this.outstandingBalance = outstandingBalance;
	}

	private String currencyCode;

	public String getCurrencyCode() {
		return this.currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	private String paymentDueDate;

	public String getPaymentDueDate() {
		return this.paymentDueDate;
	}

	public void setPaymentDueDate(String paymentDueDate) {
		this.paymentDueDate = paymentDueDate;
	}

	private String balOfLastStmt;

	public String getBalOfLastStmt() {
		return this.balOfLastStmt;
	}

	public void setBalOfLastStmt(String balOfLastStmt) {
		this.balOfLastStmt = balOfLastStmt;
	}

	private double creditLimit;

	public double getCreditLimit() {
		return this.creditLimit;
	}

	public void setCreditLimit(double creditLimit) {
		this.creditLimit = creditLimit;
	}

	private String minimumPaymentAmt;

	public String getMinimumPaymentAmt() {
		return this.minimumPaymentAmt;
	}

	public void setMinimumPaymentAmt(String minimumPaymentAmt) {
		this.minimumPaymentAmt = minimumPaymentAmt;
	}

	private String minimumPaymentDueDate;

	public String getMinimumPaymentDueDate() {
		return this.minimumPaymentDueDate;
	}

	public void setMinimumPaymentDueDate(String minimumPaymentDueDate) {
		this.minimumPaymentDueDate = minimumPaymentDueDate;
	}
}
