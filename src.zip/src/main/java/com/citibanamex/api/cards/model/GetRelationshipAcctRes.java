package com.citibanamex.api.cards.model;

import java.util.List;



public class GetRelationshipAcctRes {

	public int responseMessageId;
	public int responseVersionNo;
    public String responseTermId;
    public String responseUserId;
    public long responseDateTime;
    public int responseCode;
    public String responseMoreIndicator;
    public int responseAccountEntries;
    public List<AccountInfoTable> accountInfoTable;
    public ResponseNextKey responseNextKey;
    /**
	 * @return the responseMessageId
	 */
	public int getResponseMessageId() {
		return responseMessageId;
	}
	/**
	 * @param responseMessageId the responseMessageId to set
	 */
	public void setResponseMessageId(int responseMessageId) {
		this.responseMessageId = responseMessageId;
	}
	/**
	 * @return the responseVersionNo
	 */
	public int getResponseVersionNo() {
		return responseVersionNo;
	}
	/**
	 * @param responseVersionNo the responseVersionNo to set
	 */
	public void setResponseVersionNo(int responseVersionNo) {
		this.responseVersionNo = responseVersionNo;
	}
	/**
	 * @return the responseTermId
	 */
	public String getResponseTermId() {
		return responseTermId;
	}
	/**
	 * @param responseTermId the responseTermId to set
	 */
	public void setResponseTermId(String responseTermId) {
		this.responseTermId = responseTermId;
	}
	/**
	 * @return the responseUserId
	 */
	public String getResponseUserId() {
		return responseUserId;
	}
	/**
	 * @param responseUserId the responseUserId to set
	 */
	public void setResponseUserId(String responseUserId) {
		this.responseUserId = responseUserId;
	}
	/**
	 * @return the responseDateTime
	 */
	public long getResponseDateTime() {
		return responseDateTime;
	}
	/**
	 * @param responseDateTime the responseDateTime to set
	 */
	public void setResponseDateTime(long responseDateTime) {
		this.responseDateTime = responseDateTime;
	}
	/**
	 * @return the responseCode
	 */
	public int getResponseCode() {
		return responseCode;
	}
	/**
	 * @param responseCode the responseCode to set
	 */
	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}
	/**
	 * @return the responseMoreIndicator
	 */
	public String getResponseMoreIndicator() {
		return responseMoreIndicator;
	}
	/**
	 * @param responseMoreIndicator the responseMoreIndicator to set
	 */
	public void setResponseMoreIndicator(String responseMoreIndicator) {
		this.responseMoreIndicator = responseMoreIndicator;
	}
	/**
	 * @return the responseAccountEntries
	 */
	public int getResponseAccountEntries() {
		return responseAccountEntries;
	}
	/**
	 * @param responseAccountEntries the responseAccountEntries to set
	 */
	public void setResponseAccountEntries(int responseAccountEntries) {
		this.responseAccountEntries = responseAccountEntries;
	}
	/**
	 * @return the accountInfoTable
	 */
	public List<AccountInfoTable> getAccountInfoTable() {
		return accountInfoTable;
	}
	/**
	 * @param accountInfoTable the accountInfoTable to set
	 */
	public void setAccountInfoTable(List<AccountInfoTable> accountInfoTable) {
		this.accountInfoTable = accountInfoTable;
	}
	/**
	 * @return the responseNextKey
	 */
	public ResponseNextKey getResponseNextKey() {
		return responseNextKey;
	}
	/**
	 * @param responseNextKey the responseNextKey to set
	 */
	public void setResponseNextKey(ResponseNextKey responseNextKey) {
		this.responseNextKey = responseNextKey;
	}	
}
