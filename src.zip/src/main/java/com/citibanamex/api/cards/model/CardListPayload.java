package com.citibanamex.api.cards.model;

public class CardListPayload {

	public GBOF0003Operation GBOF0003Operation;

    public void setGBOF0003Operation(GBOF0003Operation GBOF0003Operation){
        this.GBOF0003Operation = GBOF0003Operation;
    }
    public GBOF0003Operation getGBOF0003Operation(){
        return this.GBOF0003Operation;
    }
}
