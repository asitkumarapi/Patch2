/**
 * 
 */
package com.citibanamex.api.cards.service;

import java.util.Map;

import javax.xml.datatype.DatatypeConfigurationException;

import org.json.JSONException;
import org.springframework.http.HttpHeaders;
import com.citibanamex.api.cards.model.CardListResponse.CardResponse;

/**
 * @author AS283859
 *
 */
public interface CardService {

	/**
	 * Service to retrieve list of cards by customer number 
	 * @param customerNumber - Customer number
	 * @return
	 * @throws JSONException
	 */
	//public CardResponse getCardsByCustomerAccount(String customerNumber, String accountNumber, HttpHeaders hh) throws JSONException,DatatypeConfigurationException;
	public CardResponse getCardsByCustomer(String customerNumber, HttpHeaders hh,Map<String, String> cardData) throws JSONException,DatatypeConfigurationException;
}
