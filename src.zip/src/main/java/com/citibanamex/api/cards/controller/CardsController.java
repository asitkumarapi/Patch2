package com.citibanamex.api.cards.controller;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.xml.datatype.DatatypeConfigurationException;

import com.citibanamex.api.cards.model.CardHeader;
import com.citibanamex.api.cards.model.CardListPayload;
import com.citibanamex.api.cards.model.CardSoapBody;
import com.citibanamex.api.cards.model.CreditCard;
import com.citibanamex.api.cards.model.RequestJson;
import com.citibanamex.api.cards.model.CardListResponse.CardResponse;
import com.citibanamex.api.cards.model.exception.CustomException;

import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.citibanamex.api.cards.hateoas.Response;
import com.citibanamex.api.cards.service.CardService;
import com.citibanamex.api.cards.service.CardsSoapService;
import com.citibanamex.web.annotation.ApiVersion;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author Asit Samantray
 * 
 * 
 *         This service is returns list of credit card based on customer number or relationship number associated with a customer.          
 *         @PathVariable("customernumber") - customer number is passed as request path variable.         
 *         @RequestHeader("client_id") - ClientId is passed as request header variable. 
 *         @RequestHeader("Authorization") - Authorization is passed as request header variable.
 * 		   @RequestHeader("releationshipNbr") - customer relationship number is passed as request header variable.
 * 
 * 
 */


@RestController
@RequestMapping("/customers")
public class CardsController {

	private static final Logger logger = LoggerFactory.getLogger(CardsController.class);

	String uuid = UUID.randomUUID().toString();
	String data = null;

	CardResponse creditCards = null;
	Map<String, String> requestData = null;

	@Autowired
	CardService cardService;

	@Autowired
	private CardsSoapService cardsSoapService;

	@RequestMapping(value = "/{customernumber}/cards", method = RequestMethod.GET)
	@ApiOperation(value = "getCardsByCustomer", nickname = "Get the list of cards by customer account")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 403, message = "Forbidden"),
			@ApiResponse(code = 500, message = "Failure") })
	public CardResponse getCardsByCustomer(@PathVariable("customernumber") String customerId,@RequestHeader("releationshipNbr") String reqReleationshipNbr,
			@RequestHeader("client_id") String clientId, @RequestHeader("Authorization") String auth,@RequestHeader("uuid") String uuid)
			throws DatatypeConfigurationException {
		
		uuid = UUID.randomUUID().toString();
		HttpHeaders headers = new HttpHeaders();
		headers.set("client_id", clientId);
		headers.set("Authorization", auth);
		headers.set("uuid", uuid);
		
		requestData = new HashMap<String, String>();
		requestData.put("releationshipNbr", reqReleationshipNbr);
		creditCards = new CardResponse();

		try {
			creditCards = cardService.getCardsByCustomer(customerId, headers,requestData);

		} catch (JSONException e) {
			e.printStackTrace();
		} catch (DatatypeConfigurationException e) {
			throw new RuntimeException(e);
		}
		return creditCards;
	}

	/*@RequestMapping(value = "/{customerId}/accounts/{accountId}/cards", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "getCardsByCustomerByAccount", nickname = "Get the list of cards by customerId by AccountId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 403, message = "Forbidden"),
			@ApiResponse(code = 500, message = "Failure")})
	public CardResponse getCardsByCustomerAccount(@PathVariable("customerId") String customerId,
			@PathVariable("accountId") String accountId, @RequestHeader("client_id") String clientId,
			@RequestHeader("Authorization") String auth) throws DatatypeConfigurationException {

		logger.info("***List card ");

		HttpHeaders headers = new HttpHeaders();
		headers.set("client_id", clientId);
		headers.set("Authorization", auth);
		try {
			creditCards = new CardResponse();
			creditCards = cardService.getCardsByCustomerAccount(customerId, accountId, headers);

		} catch (JSONException e) {
			e.printStackTrace();
		} catch (DatatypeConfigurationException e) {
			throw new RuntimeException(e);
		}

		return creditCards;
	}*/

	

	/*// Block Card By Customer Id
	@RequestMapping(value = "/customers/{customerId}/cards", method = RequestMethod.PUT)
	@ApiOperation(value = "blockCardByCustmerId", nickname = "Block cards by customerId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 403, message = "Forbidden"),
			@ApiResponse(code = 500, message = "Failure") })
	public ResponseEntity<?> blockCardByCustmerId(@PathVariable("customerId") String customerId,
			@RequestHeader("client_id") String clientId, @RequestHeader("Authorization") String auth)
			throws IOException {

		logger.info("***Blocking card by customer " + customerId);

		HttpHeaders headers = new HttpHeaders();
		headers.set("client_id", clientId);
		headers.set("Authorization", auth);
		try {
			data = cardsSoapService.blockCardByCustomerId(customerId, headers);

		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		Response<String> response = new Response<>(data);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}*/

	/*// Block Card By Customer and account Id
	@RequestMapping(value = "/customers/{customerId}}/accounts/{acctId}/cards", method = RequestMethod.PUT)
	@ApiOperation(value = "blockByCustomerIdAccId", nickname = "Block cards by customerId")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 403, message = "Forbidden"),
			@ApiResponse(code = 500, message = "Failure") })
	public ResponseEntity<?> blockByCustomerIdAccId(@PathVariable("customerId") String customerId,
			@PathVariable("accId") String accountId, @RequestHeader("client_id") String clientId,
			@RequestHeader("Authorization") String auth) throws IOException {
		logger.info("***Blocking card by customer " + customerId);
		HttpHeaders headers = new HttpHeaders();
		headers.set("client_id", clientId);
		headers.set("Authorization", auth);
		try {
			data = cardsSoapService.blockCardByAccountId(customerId, accountId, headers);
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		Response<String> response = new Response<>(data);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}*/
	
	/**
	 * @author Asit Samantray
	 * 
	 * 
	 * This service returns block the card status based on credit card number.         
	 * @RequestBody String cardNumber - cardNumber is passed as body parameter.
	 * @RequestBody String status - status is passed as body parameter.
	 * 
	 * 
	 */

	// Block Card By Card
	@RequestMapping(value = "/cards", method = RequestMethod.PUT)
	@ApiOperation(value = "blockByCards", nickname = "Block cards by card number")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 403, message = "Forbidden"),
			@ApiResponse(code = 500, message = "Failure") })
	public ResponseEntity<?> blockByCards(@RequestBody CardSoapBody cs)
			throws IOException {
		logger.info("***Blocking card by customer " + cs.getCardNumber() + "--" + cs.getStatus());
		String data = cardsSoapService.block(cs);
		Response<String> response = new Response<>(data);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}
