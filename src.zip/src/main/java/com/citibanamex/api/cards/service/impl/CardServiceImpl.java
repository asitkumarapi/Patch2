/**
 * 
 */
package com.citibanamex.api.cards.service.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.citibanamex.api.cards.model.CreditCardResponse;
import com.citibanamex.api.cards.model.CardListResponse.CardResponse;
import com.citibanamex.api.cards.model.CardListResponse.Cards;
import com.citibanamex.api.cards.model.CardListResponse.CreditCardAccounts;
import com.citibanamex.api.cards.model.utilities.Constant;
import com.citibanamex.api.cards.service.CardService;

import com.citibanamex.api.cards.model.AccountInfoTable;
import com.citibanamex.api.cards.model.OperationResponse;


/**
 * @author Asit Samantray
 * Service implementation to retrive list of of credit cards based on customer number or relationship number.
 *
 */
@Service
public class CardServiceImpl implements CardService{

	public static final Logger logger = LoggerFactory.getLogger(CardServiceImpl.class);
	
	RestTemplate restTemplate = null;
	CreditCardResponse CCResponse = null;
	CardResponse cardResp = null;
	CreditCardAccounts creditCardAcc = null;
	ArrayList<CreditCardAccounts> creditCard = null;
	ArrayList<Cards> cards = null;
	Cards cardObject = null;
	
	JSONObject payload = null;
	JSONObject jsonOpObject = null;
	JSONObject jsonAccObject = null;
	
	/*@Override
	public CardResponse getCardsByCustomerAccount(String customerNumber, String accountNumber, HttpHeaders headers)
			throws JSONException {		
		
		restTemplate = new RestTemplate();

		//logger.info("***Request Header Object start");
		
		headers.set("UUID",UUID.randomUUID().toString());
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		//logger.info("Request Header :::" + headers);

		//logger.info("****Request Body object start");		
		try {
			jsonAccObject = new JSONObject();
			jsonAccObject.put("requestMessageId", Constant.REQ_MESSAGE_ID);
			jsonAccObject.put("requestVersionNumber", Constant.REQ_VERSION_NO);
			jsonAccObject.put("requestTerminalId", Constant.REQ_TERMINAL_ID);
			jsonAccObject.put("requestUserId", Constant.REQ_USER_ID);
			jsonAccObject.put("requestDateTime", Constant.REQ_DATE_TIME);
			jsonAccObject.put("requestChannelInd", Constant.REQ_CHANNEL_IND);
			jsonAccObject.put("requestCustomerOrg", Constant.REQ_CUST_ORG);
			jsonAccObject.put("requestRelationshipNumber", Constant.REQ_RELATIONSHIP_NO);
			jsonOpObject = new JSONObject().put("getRelationshipAcctReq", jsonAccObject);
			payload = new JSONObject().put("GBOF0003Operation", jsonOpObject);
		} catch (JSONException e) {
			e.printStackTrace();
		}		
		//logger.info("Request Payload::::" + payload);
		HttpEntity<String> entity = new HttpEntity<String>(payload.toString(), headers);
		// Service Response Logic Start
		ResponseEntity<OperationResponse> serviceResponse = restTemplate.exchange(Constant.URI, HttpMethod.POST, entity,
				OperationResponse.class);

		List<AccountInfoTable> accounts = serviceResponse
				.getBody().gBOF0003OperationResponse.getRelationshipAcctRes.accountInfoTable;

		//logger.info("Accounts List ::::::" + accounts);
		creditCard = new ArrayList<CreditCardAccounts>();
		accounts.forEach(account -> {
			if (customerNumber != null && accountNumber != null) {
				//if (((customerNumber.equals(account.getResponseCustomerNumber()) || (accountNumber.equals(account.getResponseRelationshipNumber()))))) {
				if ((accountNumber.equals(account.getResponseRelationshipNumber()))) {	
				//logger.info(" Inside Account loop ::::::" + account.responseCustomerNumber);
					creditCardAcc = new CreditCardAccounts();
					creditCardAcc.setAccountStatus(account.getAccountStatus());
					creditCardAcc.setAccountId(account.getResponseAccountNumber());
					creditCardAcc.setProductName("A"); // Service response no mapping element available 
					creditCardAcc.setDisplayAccountNumber(account.getResponseAccountNumber());
					creditCardAcc.setAccountNickname("S"); // Service response no mapping element available
					creditCardAcc.setOutstandingBalance(23333.00); // Service response no mapping element available
					creditCardAcc.setCurrencyCode(account.getCurrencyCode()); 
					Integer lastPaymentDate = account.getPaymentDueDate(); 
					creditCardAcc.setPaymentDueDate(Integer.toString(lastPaymentDate));
					Double balOflastStmt = account.getEndingBalOfLastStmt();
					creditCardAcc.setBalOfLastStmt(Double.toString(balOflastStmt));
					creditCardAcc.setCreditLimit(account.getCardCreditLimit());
					creditCardAcc.setMinimumPaymentAmt("221212"); // Service response no mapping element available
					Integer miniPaymentDueDate = account.getPaymentDueDate();
					creditCardAcc.setMinimumPaymentDueDate(Integer.toString(miniPaymentDueDate));
					//logger.info(" Inside cc loop ::::::" + creditCardAcc);
					creditCard.add(creditCardAcc);					
				}
			}
		});
		logger.info(" CreditCard Size::::::" + creditCard.size());
		
		cardObject = new Cards();
		cardObject.setCreditCardAccounts(creditCard);
		//checkingAccounts = new ArrayList<CheckingAccounts>();
		//savingsAccounts = new ArrayList<SavingsAccounts>();
		//cardObject.setCheckingAccounts(checkingAccounts);
		//cardObject.setSavingsAccounts(savingsAccounts);
		cards = new ArrayList<Cards>();
		cards.add(cardObject);
		// logger.info("Service Response ::: " + cards.get(0));
		cardResp = new CardResponse();
		if (cardResp != null) {
			cardResp.setCards(cards);
		}
		// Service Response Logic End
		//logger.info("Service Response ::: " + cardResp);
		return cardResp;
	}*/

	@Override
	public CardResponse getCardsByCustomer(String customerNbrOrRelNbr, HttpHeaders headers,Map cardData) throws JSONException,DatatypeConfigurationException {
		
		restTemplate = new RestTemplate();
		GregorianCalendar gc = new GregorianCalendar();
		gc.setTimeInMillis(new Date().getTime());

		//***Request Header Object start
		//headers.set("UUID",UUID.randomUUID().toString());
		headers.set("DateAndTimeStamp",DatatypeFactory.newInstance().newXMLGregorianCalendar(gc).toString());
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		//logger.info("Request Header :::" + headers);
		
		DateFormat df = new SimpleDateFormat("MMddyyyyHHmmss");
		String currentDateTime = df.format(new Date(System.currentTimeMillis()));
		
logger.info(":::: date And Time :::::" + currentDateTime);
		//****Request Body object start
		JSONObject payload = null;
		JSONObject jsonOpObject = null;
		JSONObject jsonAccObject = null;
		try {
			jsonAccObject = new JSONObject();
			jsonAccObject.put("requestMessageId", Constant.REQ_MESSAGE_ID);
			jsonAccObject.put("requestVersionNumber", Constant.REQ_VERSION_NO);
			jsonAccObject.put("requestTerminalId", Constant.REQ_TERMINAL_ID);
			jsonAccObject.put("requestUserId", "");
			jsonAccObject.put("requestDateTime", currentDateTime);
			jsonAccObject.put("requestChannelInd", Constant.REQ_CHANNEL_IND);
			jsonAccObject.put("requestCustomerOrg", Constant.REQ_CUST_ORG);
			jsonAccObject.put("requestRelationshipNumber", cardData.get("releationshipNbr"));
			jsonOpObject = new JSONObject().put("getRelationshipAcctReq", jsonAccObject);
			payload = new JSONObject().put("GBOF0003Operation", jsonOpObject);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		//	logger.info("Request Payload::::" + payload);
		HttpEntity<String> entity = new HttpEntity<String>(payload.toString(), headers);
		
		ResponseEntity<OperationResponse> serviceResponse = restTemplate.exchange(Constant.URI, HttpMethod.POST, entity,
				OperationResponse.class);

		List<AccountInfoTable> accounts = serviceResponse
				.getBody().gBOF0003OperationResponse.getRelationshipAcctRes.accountInfoTable;

		
		creditCard = new ArrayList<CreditCardAccounts>();
		accounts.forEach(account -> {
			if (customerNbrOrRelNbr != null) {
				if ((customerNbrOrRelNbr.equals(account.getResponseCustomerNumber())) || (customerNbrOrRelNbr.equals(account.getResponseRelationshipNumber()))) {
				//	logger.info(" Inside Account loop ::::::" + account.responseCustomerNumber);

					creditCardAcc = new CreditCardAccounts();
					creditCardAcc.setAccountStatus(account.getAccountStatus());
					creditCardAcc.setAccountId(account.getResponseAccountNumber());
					creditCardAcc.setProductName(""); // Service response no mapping element available 
					creditCardAcc.setDisplayAccountNumber(account.getResponseAccountNumber());
					creditCardAcc.setAccountNickname(""); // Service response no mapping element available
					creditCardAcc.setOutstandingBalance(0); // Service response no mapping element available
					creditCardAcc.setCurrencyCode(account.getCurrencyCode()); 
					Integer lastPaymentDate = account.getPaymentDueDate(); 
					creditCardAcc.setPaymentDueDate(Integer.toString(lastPaymentDate));
					Double balOflastStmt = account.getEndingBalOfLastStmt();
					creditCardAcc.setBalOfLastStmt(Double.toString(balOflastStmt));
					creditCardAcc.setCreditLimit(account.getCardCreditLimit());
					creditCardAcc.setMinimumPaymentAmt(""); // Service response no mapping element available
					Integer miniPaymentDueDate = account.getPaymentDueDate();
					creditCardAcc.setMinimumPaymentDueDate(Integer.toString(miniPaymentDueDate));
					creditCard.add(creditCardAcc);					
				}
			}
			// }
		});
		cardObject = new Cards();
		cardObject.setCreditCardAccounts(creditCard);
		cards = new ArrayList<Cards>();
		cards.add(cardObject);
		cardResp = new CardResponse();
		if (cardResp != null) {
			cardResp.setCards(cards);
		}
		logger.info("Service Response ::: " + cardResp);
		return cardResp;
	}


}
