package com.citibanamex.api.cards.model.CardListResponse;

import java.util.ArrayList;


public class Cards {

	private ArrayList<CreditCardAccounts> creditCardAccounts;

	public ArrayList<CreditCardAccounts> getCreditCardAccounts() {
		return this.creditCardAccounts;
	}

	public void setCreditCardAccounts(ArrayList<CreditCardAccounts> creditCardAccounts) {
		this.creditCardAccounts = creditCardAccounts;
	}

	/*private ArrayList<CheckingAccounts> checkingAccounts;

	public ArrayList<CheckingAccounts> getCheckingAccounts() {
		return this.checkingAccounts;
	}

	public void setCheckingAccounts(ArrayList<CheckingAccounts> checkingAccounts) {
		this.checkingAccounts = checkingAccounts;
	}

	private ArrayList<SavingsAccounts> savingsAccounts;

	public ArrayList<SavingsAccounts> getSavingsAccounts() {
		return this.savingsAccounts;
	}

	public void setSavingsAccounts(ArrayList<SavingsAccounts> savingsAccounts) {
		this.savingsAccounts = savingsAccounts;
	}*/

}
