package com.citibanamex.api.cards.model.CardListResponse;

import java.util.ArrayList;

public class CardResponse {

	private ArrayList<Cards> cards;

	public ArrayList<Cards> getCards() {
		return this.cards;
	}

	public void setCards(ArrayList<Cards> cards) {
		this.cards = cards;
	}
}
