package com.citibanamex.api.cards.model;

public class GBOF0003Operation {

	public GetRelationshipAcctReq getRelationshipAcctReq;

    public void setGetRelationshipAcctReq(GetRelationshipAcctReq getRelationshipAcctReq){
        this.getRelationshipAcctReq = getRelationshipAcctReq;
    }
    public GetRelationshipAcctReq getGetRelationshipAcctReq(){
        return this.getRelationshipAcctReq;
    }
}
