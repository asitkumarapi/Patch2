package com.citibanamex.api.cardsmaintenance.model.blockcardresp;

public class Mli_2xl_o_hdr_grp {

	public String mli_2xl_o_version_nbr;

	public String mli_2xl_o_message_id;

	public String mli_2xl_o_error_msg;

	public String mli_2xl_o_timestamp;

	public String mli_2xl_o_user_id;

	public String mli_2xl_o_terminal_id;

	public String mli_2xl_o_error_code;

    public String getMli_2xl_o_version_nbr ()
    {
        return mli_2xl_o_version_nbr;
    }

    public void setMli_2xl_o_version_nbr (String mli_2xl_o_version_nbr)
    {
        this.mli_2xl_o_version_nbr = mli_2xl_o_version_nbr;
    }

    public String getMli_2xl_o_message_id ()
    {
        return mli_2xl_o_message_id;
    }

    public void setMli_2xl_o_message_id (String mli_2xl_o_message_id)
    {
        this.mli_2xl_o_message_id = mli_2xl_o_message_id;
    }

    public String getMli_2xl_o_error_msg ()
    {
        return mli_2xl_o_error_msg;
    }

    public void setMli_2xl_o_error_msg (String mli_2xl_o_error_msg)
    {
        this.mli_2xl_o_error_msg = mli_2xl_o_error_msg;
    }

    public String getMli_2xl_o_timestamp ()
    {
        return mli_2xl_o_timestamp;
    }

    public void setMli_2xl_o_timestamp (String mli_2xl_o_timestamp)
    {
        this.mli_2xl_o_timestamp = mli_2xl_o_timestamp;
    }

    public String getMli_2xl_o_user_id ()
    {
        return mli_2xl_o_user_id;
    }

    public void setMli_2xl_o_user_id (String mli_2xl_o_user_id)
    {
        this.mli_2xl_o_user_id = mli_2xl_o_user_id;
    }

    public String getMli_2xl_o_terminal_id ()
    {
        return mli_2xl_o_terminal_id;
    }

    public void setMli_2xl_o_terminal_id (String mli_2xl_o_terminal_id)
    {
        this.mli_2xl_o_terminal_id = mli_2xl_o_terminal_id;
    }

    public String getMli_2xl_o_error_code ()
    {
        return mli_2xl_o_error_code;
    }

    public void setMli_2xl_o_error_code (String mli_2xl_o_error_code)
    {
        this.mli_2xl_o_error_code = mli_2xl_o_error_code;
    }

   /* @Override
    public String toString()
    {
        return "ClassPojo [mli_2xl_o_version_nbr = "+mli_2xl_o_version_nbr+", mli_2xl_o_message_id = "+mli_2xl_o_message_id+", mli_2xl_o_error_msg = "+mli_2xl_o_error_msg+", mli_2xl_o_timestamp = "+mli_2xl_o_timestamp+", mli_2xl_o_user_id = "+mli_2xl_o_user_id+", mli_2xl_o_terminal_id = "+mli_2xl_o_terminal_id+", mli_2xl_o_error_code = "+mli_2xl_o_error_code+"]";
    }*/
}
