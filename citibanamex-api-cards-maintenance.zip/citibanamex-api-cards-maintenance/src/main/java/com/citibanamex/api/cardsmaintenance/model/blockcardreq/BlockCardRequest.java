package com.citibanamex.api.cardsmaintenance.model.blockcardreq;

public class BlockCardRequest {

	private String cardNumber;
	private String durationDays;
	
	public BlockCardRequest() {
		super();
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getDurationDays() {
		return durationDays;
	}
	public void setDurationDays(String durationDays) {
		this.durationDays = durationDays;
	}
	
	
}
