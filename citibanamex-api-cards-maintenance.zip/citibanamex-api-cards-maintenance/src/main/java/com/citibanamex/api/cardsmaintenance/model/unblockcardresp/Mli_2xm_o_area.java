package com.citibanamex.api.cardsmaintenance.model.unblockcardresp;

public class Mli_2xm_o_area {

	public Mli_2xm_o_hdr_grp mli_2xm_o_hdr_grp;
	
	
    public Mli_2xm_o_area() {
		super();
	}
	public void setMli_2xm_o_hdr_grp(Mli_2xm_o_hdr_grp mli_2xm_o_hdr_grp){
        this.mli_2xm_o_hdr_grp = mli_2xm_o_hdr_grp;
    }
    public Mli_2xm_o_hdr_grp getMli_2xm_o_hdr_grp(){
        return this.mli_2xm_o_hdr_grp;
    }
}
