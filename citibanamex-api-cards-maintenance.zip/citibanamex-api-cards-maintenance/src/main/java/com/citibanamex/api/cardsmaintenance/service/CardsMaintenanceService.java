/**
 * 
 */
package com.citibanamex.api.cardsmaintenance.service;

import com.citibanamex.api.cardsmaintenance.model.blockcardreq.BlockCardRequest;
import com.citibanamex.api.cardsmaintenance.model.blockcardresp.ResponseData;

/**
 * @author AS283859
 *
 */
public interface CardsMaintenanceService {
	public ResponseData blockCard(BlockCardRequest data);
}
