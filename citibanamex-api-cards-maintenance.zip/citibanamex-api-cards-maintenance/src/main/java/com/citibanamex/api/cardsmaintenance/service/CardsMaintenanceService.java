/**
 * 
 */
package com.citibanamex.api.cardsmaintenance.service;


import java.util.Map;

import org.springframework.http.HttpHeaders;

import com.citibanamex.api.cardsmaintenance.model.blockcardresp.ResponseData;
import com.citibanamex.api.cardsmaintenance.model.unblockcardreq.UnBlockCardRequest;
import com.citibanamex.api.cardsmaintenance.model.unblockcardresp.UnBlockCardResponse;

/**
 * @author AS283859
 *
 */
public interface CardsMaintenanceService {
	public ResponseData blockCard(String cardNumber,int durations,HttpHeaders headers,Map<String, String> data);
	public UnBlockCardResponse unBlockCard(String cardNumber,HttpHeaders headers,Map<String, String> data);
}
