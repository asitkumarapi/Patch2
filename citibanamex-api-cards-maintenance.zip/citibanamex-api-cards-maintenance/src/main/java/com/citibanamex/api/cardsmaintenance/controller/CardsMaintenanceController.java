/**
 * 
 */
package com.citibanamex.api.cardsmaintenance.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.citibanamex.api.cardsmaintenance.model.blockcardreq.BlockCardRequest;
import com.citibanamex.api.cardsmaintenance.model.blockcardresp.BlockCardStatus;
import com.citibanamex.api.cardsmaintenance.model.blockcardresp.ResponseData;
import com.citibanamex.api.cardsmaintenance.service.CardsMaintenanceService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author AS283859
 * This card maintenance service block/unblock card number based on customer card number.
 */
@RestController
public class CardsMaintenanceController {
	ResponseData responseData = null;
	BlockCardStatus cardStatus = null;
	
	@Autowired
	CardsMaintenanceService cardsMaintenanceService;
	
	/*
	 * 
	 * This service returns block the card status based on credit card number.
	 * 
	 */

	@RequestMapping(value = "/creditCards/cardServicing/{cardId}/block", method = RequestMethod.POST)
	@ApiOperation(value = "blockCard", nickname = "Temporarily block/lock the credit card")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 403, message = "Forbidden"),
			@ApiResponse(code = 500, message = "Failure") })
	public ResponseEntity<BlockCardStatus> blockCard(@RequestBody BlockCardRequest req, @RequestHeader("client_id") String clientId,
			@RequestHeader("Authorization") String auth, @RequestHeader("uuid") String uuid,
			@RequestHeader("Content-Type") String contentType, @RequestHeader("Accept") String accept) throws Exception {
		responseData = new ResponseData();
		ResponseData data = null;
		// uuid = UUID.randomUUID().toString();
		// HttpHeaders headers = new HttpHeaders();
		String cardNumber = req.getCardNumber();
		String durations = req.getDurationDays();
		if (cardNumber != "" && cardNumber!= null) {
			if(cardNumber.length() >= 16){
				if (durations != "" && durations != null) {
					data = cardsMaintenanceService.blockCard(req);
				}else {			
					  // CardException ce = new CardException();
					  // ce.throwMissingParameterException();			
				}
			}else {			
				  // CardException ce = new CardException();
				  // ce.throwParameterLengthException();		
			}
			
		} else {			
			  // CardException ce = new CardException();
			  // ce.throwMissingParameterException();			
		}

		//logger.info("Block card Response code ///////// " + data.getEWOEW2XLOperationResponse().getMli_2xl_o_area()
		//	.getMli_2xl_o_hdr_grp().getMli_2xl_o_error_code());
		if (data != null && data.getEWOEW2XLOperationResponse().getMli_2xl_o_area().getMli_2xl_o_hdr_grp()
				.getMli_2xl_o_error_code() != null) {
			if (data.getEWOEW2XLOperationResponse().getMli_2xl_o_area().getMli_2xl_o_hdr_grp().getMli_2xl_o_error_code()
					.equals("0000")) {
				cardStatus = new BlockCardStatus();
				cardStatus.setStatus("SUCCESS");
			} else {
				cardStatus.setStatus("UNSUCCESSFUL");
			}
		} else {

		}
		return new ResponseEntity<BlockCardStatus>(cardStatus,HttpStatus.OK);
		
	}
}
