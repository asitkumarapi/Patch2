/**
 * 
 */
package com.citibanamex.api.cardsmaintenance.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.citibanamex.api.cardsmaintenance.model.blockcardresp.BlockCardStatus;
import com.citibanamex.api.cardsmaintenance.model.blockcardresp.ResponseData;
import com.citibanamex.api.cardsmaintenance.model.unblockcardresp.UnBlockCardResponse;
import com.citibanamex.api.cardsmaintenance.model.unblockcardresp.UnBlockCardStatus;
import com.citibanamex.api.cardsmaintenance.service.CardsMaintenanceService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author AS283859
 * This card maintenance service block/unblock card number based on customer card number.
 */
@RestController
public class CardsMaintenanceController {
	
	private static final Logger logger = LoggerFactory.getLogger(CardsMaintenanceController.class);
	
	ResponseData responseData = null;
	BlockCardStatus cardStatus = null;
	UnBlockCardStatus status = null;
	UnBlockCardResponse response = null;
	Map<String,String> reqData = null;
	
	@Autowired
	CardsMaintenanceService cardsMaintenanceService;
	
	/*
	 * 
	 * This service returns block the card status based on credit card number.
	 * 
	 */

	@RequestMapping(value = "/creditCards/cardServicing/{cardId}/block?blockDurationInDays={durationInDays}", method = RequestMethod.POST)
	@ApiOperation(value = "blockCard", nickname = "Temporarily block/lock the credit card")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 403, message = "Forbidden"),
			@ApiResponse(code = 500, message = "Failure") })
	public ResponseEntity<BlockCardStatus> blockCard(@PathVariable("cardId") String cardNbr,@RequestParam("durationInDays") int days, @RequestHeader("client_id") String clientId,
			@RequestHeader("Authorization") String auth, @RequestHeader("uuid") String uuid,
			@RequestHeader("Content-Type") String contentType, @RequestHeader("Accept") String accept,@RequestHeader("messageId") String msgId,
			@RequestHeader("versionNbr") String version,@RequestHeader("terminalId") String terminalId,
			@RequestHeader("userId") String userId,@RequestHeader("org") String org) throws Exception {
		
		responseData = new ResponseData();
		ResponseData data = null;
		uuid = UUID.randomUUID().toString();
		// Request headers
		HttpHeaders headers = new HttpHeaders();
		headers.set("uuid",uuid);
		headers.set("client_id",clientId);
		headers.set("Authorization",auth);
		
		reqData = new HashMap<String, String>();
		reqData.put("messageId",msgId);
		reqData.put("versionNbr",version);
		reqData.put("terminalId",terminalId);
		reqData.put("userId",userId);
		reqData.put("org",org);
		
		String cardNumber = cardNbr;
		int durations = days;
		if (cardNumber != "" && cardNumber!= null) {
			if(cardNumber.length() >= 16){
				if (durations != 0) {
					data = cardsMaintenanceService.blockCard(cardNumber,durations,headers,reqData);
				}else {			
					  // CardException ce = new CardException();
					  // ce.throwMissingParameterException();			
				}
			}else {			
				  // CardException ce = new CardException();
				  // ce.throwParameterLengthException();		
			}
			
		} else {			
			  // CardException ce = new CardException();
			  // ce.throwMissingParameterException();			
		}

		//logger.info("Block card Response code ///////// " + data.getEWOEW2XLOperationResponse().getMli_2xl_o_area()
		//	.getMli_2xl_o_hdr_grp().getMli_2xl_o_error_code());
		if (data != null && data.getEWOEW2XLOperationResponse().getMli_2xl_o_area().getMli_2xl_o_hdr_grp()
				.getMli_2xl_o_error_code() != null) {
			if (data.getEWOEW2XLOperationResponse().getMli_2xl_o_area().getMli_2xl_o_hdr_grp().getMli_2xl_o_error_code()
					.equals("0000")) {
				cardStatus = new BlockCardStatus();
				cardStatus.setStatus("SUCCESS");
			} else {
				cardStatus.setStatus("UNSUCCESSFUL");
			}
		} else {

		}
		return new ResponseEntity<BlockCardStatus>(cardStatus,HttpStatus.OK);		
	}
	
	/*
	 * 
	 * This service returns block the card status based on credit card number.
	 * 
	 */
	
	@RequestMapping(value = "/creditCards/cardServicing/{cardId}/unblock", method = RequestMethod.POST)
	@ApiOperation(value = "unBlockCard", nickname = "Unblock the card by card number")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 401, message = "Unauthorized"), @ApiResponse(code = 403, message = "Forbidden"),
			@ApiResponse(code = 500, message = "Failure") })
	public ResponseEntity<UnBlockCardStatus> unBlockCard(@PathVariable("cardId") String cardNbr,@RequestHeader("client_id") String clientId,
			@RequestHeader("Authorization") String auth, @RequestHeader("uuid") String uuid,
			@RequestHeader("Content-Type") String contentType, @RequestHeader("Accept") String accept,@RequestHeader("messageId") String msgId,
			@RequestHeader("versionNbr") String version,@RequestHeader("terminalId") String terminalId,
			@RequestHeader("userId") String userId,@RequestHeader("org") String org) throws Exception {
		response = new UnBlockCardResponse();
		String cardNumber = cardNbr;
		
		// Request headers
		HttpHeaders headers = new HttpHeaders();
			headers.set("uuid",uuid);
			headers.set("client_id",clientId);
			headers.set("Authorization",auth);
			
			reqData = new HashMap<String, String>();
			reqData.put("messageId",msgId);
			reqData.put("versionNbr",version);
			reqData.put("terminalId",terminalId);
			reqData.put("userId",userId);
			reqData.put("org",org);
			
				
		if (cardNumber != "" && cardNumber!= null) {
			if(cardNumber.length() >= 16){
				response = cardsMaintenanceService.unBlockCard(cardNumber,headers,reqData);
			}else {			
				  // CardException ce = new CardException();
				  // ce.throwParameterLengthException();			
			}
			
		} else {			
			   //CardException ce = new CardException();
			  // ce.throwMissingParameterException();			
		}
		
		//logger.info("Unblock card Response code ///////// " + response.getEWOEW2XMOperationResponse()
		//		.getMli_2xm_o_area().getMli_2xm_o_hdr_grp().getMli_2xm_o_error_code());
		
		
		if (response != null && response.getEWOEW2XMOperationResponse().getMli_2xm_o_area().getMli_2xm_o_hdr_grp()
				.getMli_2xm_o_error_code() != null) {
			if (response.getEWOEW2XMOperationResponse().getMli_2xm_o_area().getMli_2xm_o_hdr_grp()
					.getMli_2xm_o_error_code().equals("0000")) {
				status = new UnBlockCardStatus();
				status.setStatus("SUCCESS");
			} else {
				status.setStatus("UNSUCCESSFUL");
			}
		} else {

		}
		return new ResponseEntity<UnBlockCardStatus>(status,HttpStatus.OK);
	}
}
