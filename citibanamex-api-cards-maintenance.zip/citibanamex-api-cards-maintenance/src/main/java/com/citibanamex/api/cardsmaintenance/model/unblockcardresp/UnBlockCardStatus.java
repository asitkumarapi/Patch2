package com.citibanamex.api.cardsmaintenance.model.unblockcardresp;

public class UnBlockCardStatus {

private String Status;
	
	public UnBlockCardStatus(){
		super();
	}
	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}
}
