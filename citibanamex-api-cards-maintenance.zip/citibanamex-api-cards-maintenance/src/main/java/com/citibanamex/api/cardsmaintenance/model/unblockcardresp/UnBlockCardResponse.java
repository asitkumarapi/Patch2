package com.citibanamex.api.cardsmaintenance.model.unblockcardresp;

public class UnBlockCardResponse {

	public EWOEW2XMOperationResponse EWOEW2XMOperationResponse;
	
	public UnBlockCardResponse() {
		super();
	}
	public void setEWOEW2XMOperationResponse(EWOEW2XMOperationResponse EWOEW2XMOperationResponse){
        this.EWOEW2XMOperationResponse = EWOEW2XMOperationResponse;
    }
    public EWOEW2XMOperationResponse getEWOEW2XMOperationResponse(){
        return this.EWOEW2XMOperationResponse;
    }
}
