package com.citibanamex.api.cardsmaintenance.model.blockcardresp;

public class BlockCardStatus {

	private String Status;
	
	public BlockCardStatus(){
		super();
	}
	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}
	
}
