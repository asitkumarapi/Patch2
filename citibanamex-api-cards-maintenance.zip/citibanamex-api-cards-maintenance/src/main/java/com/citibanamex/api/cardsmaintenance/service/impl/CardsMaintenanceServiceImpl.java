/**
 * 
 */
package com.citibanamex.api.cardsmaintenance.service.impl;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.citibanamex.api.cardsmaintenance.model.Constant;
import com.citibanamex.api.cardsmaintenance.model.blockcardreq.BlockCardRequest;
import com.citibanamex.api.cardsmaintenance.model.blockcardresp.ResponseData;
import com.citibanamex.api.cardsmaintenance.model.unblockcardresp.UnBlockCardResponse;
import com.citibanamex.api.cardsmaintenance.service.CardsMaintenanceService;


/**
 * @author AS283859
 *
 */
@Service
public class CardsMaintenanceServiceImpl implements CardsMaintenanceService{
	public static final Logger logger = LoggerFactory.getLogger(CardsMaintenanceServiceImpl.class);
	String timeStamp = null;
	
	@Autowired
	RestTemplate rt;

	@Override
	public ResponseData blockCard(String cardNumber, int durations, HttpHeaders hdr,Map<String, String> data) {
		HttpHeaders headers = hdr;
		JSONObject operation  = new JSONObject();
		JSONObject area  = new JSONObject();
		JSONObject grp  = new JSONObject();
		JSONObject jObject  = new JSONObject();
		timeStamp = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSSSSS").format(new Date(System.currentTimeMillis()));
		try {
			jObject.put("mli_2xl_i_message_id",data.get("messageId"));
			jObject.put("mli_2xl_i_version_nbr", data.get("versionNbr"));
			jObject.put("mli_2xl_i_terminal_id", data.get("terminalId"));
			jObject.put("mli_2xl_i_user_id", data.get("userId"));
			jObject.put("mli_2xl_i_timestamp", timeStamp);
			jObject.put("mli_2xl_i_org", data.get("org"));
			jObject.put("mli_2xl_i_card_nbr", cardNumber);
			jObject.put("mli_2xl_i_ovc_cd", "7");
			jObject.put("mli_2xl_i_ovc_pur_days", durations);
			grp.put("mli_2xl_i_hdr_grp", jObject);
			area.put("mli_2xl_i_area", grp);	    
			operation.put("EWOEW2XLOperation", area);
		} catch (JSONException e) {				
			e.printStackTrace();
		}
		
		logger.info("Payload >>>>" + operation);
		HttpEntity<?> entity = new HttpEntity<>(operation.toString(), headers);
		ResponseEntity<ResponseData> serviceResp = rt.exchange(Constant.BLOCK_SERVICE, HttpMethod.POST,entity,ResponseData.class);
		
		logger.info("Response ///////// " + serviceResp.getBody());
		return serviceResp.getBody();
	}

	@Override
	public UnBlockCardResponse unBlockCard(String cardNumber, HttpHeaders hdr,Map<String, String> data) {
		
		HttpHeaders headers = hdr;		
		
		JSONObject Operation  = new JSONObject();
		JSONObject xmArea  = new JSONObject();
		JSONObject hdrGrp  = new JSONObject();
		JSONObject jObject  = new JSONObject();
		timeStamp = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSSSSS").format(new Date(System.currentTimeMillis()));
		try {
			 //jObject.put("mli_2xm_i_version_nbr", data.getEWOEW2XMOperation().getMli_2xm_i_area().getMli_2xm_i_hdr_grp().getMli_2xm_i_version_nbr());
				jObject.put("mli_2xm_i_message_id", data.get("messageId")); 	
				jObject.put("mli_2xm_i_version_nbr", data.get("versionNbr"));  
			 	jObject.put("mli_2xm_i_terminal_id", data.get("terminalId"));
			    jObject.put("mli_2xm_i_user_id", data.get("userId"));
			    jObject.put("mli_2xm_i_timestamp", timeStamp);
			    jObject.put("mli_2xm_i_org", data.get("org"));
			    jObject.put("mli_2xm_i_card_nbr", cardNumber);
			    hdrGrp.put("mli_2xm_i_hdr_grp", jObject);
			    xmArea.put("mli_2xm_i_area", hdrGrp);	    
			    Operation.put("EWOEW2XMOperation", xmArea);
		} catch (JSONException e) {
			e.printStackTrace();
		}   
	    
		HttpEntity<?> entity = new HttpEntity<>(Operation.toString(), headers);
		ResponseEntity<UnBlockCardResponse> serviceResp1 = rt.exchange(Constant.UNBLOCK_SERVICE, HttpMethod.POST,entity,UnBlockCardResponse.class);
		//logger.info("Unblock card Response ///////// " + serviceResp1.getBody());
		return serviceResp1.getBody();
	}
	

			
		
}
