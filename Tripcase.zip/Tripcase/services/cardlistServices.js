citiApp.factory('cardlistService', ['$http',function($http){
	var data = {};
	var headerinfo= {
        headers: { 'Content-Type': 'application/json',
		           'client_id':'ffe4d269-1c59-493b-94f4-fbca960bc0f0'}
        };



    // get the itenary details of particular account number
    data.itenarylist = function(){
        // return $http.get('http://localhost:8888/cards/'+cardno) ;
        return $http.get('json/itenarylist.json') ;
    };

	// get the card details of particular account number
	data.cardlist = function(cardno){
 	// return $http.get('http://localhost:8888/cards/'+cardno) ;
        return $http.get('json/carddetail.json') ;
	};


    data.searchAccountDetails = function(cardObj){
        // return $http.get('http://localhost:8888/cards/'+cardno) ;
        return $http.get('json/accountsummary1.json') ;
    };

    // Get the List of cards
	data.cardlisthome = function(){
	//return $http.get('http://localhost:8888/cards') ;
        return $http.get('json/cardlist.json') ;
			var postdata={
		"GBOF0003Operation":{
		"getRelationshipAcctReq":{
		"requestTerminalId":"00000000MX",
		"requestRelationshipNumber":"000000311703",
		"requestDateTime":"07132015120500",
		"requestMessageId":"0003",
		"requestUserId":"",
		"requestCustomerOrg":"322",
		"requestVersionNumber":15,
		"requestChannelInd":"ECL"
		}
		}
		};
		
	
	//return $http.post('https://sit.api.banamex.com/ccp/sit/v1/card/cardinfo/RelatedCardListInq',postdata,headerinfo);

    };


    data.cardblockandunblocklist = function(cardno) {
        //return $http.get('http://localhost:8888/cards') ;
        return $http.get('json/cardlist.json');
    };

	// Perform the card blocking process
	data.blockcard=function(carddetails) {
		//console.log("Service call block details");
		//console.log(carddetails);
		return $http.post('http://localhost:8888/cards/'+carddetails.cardNumber+'/status',carddetails) ;

	};
    data.cardblock=function(cardObj) {
        console.log("Service call block details");
        console.log(cardObj);
        console.log("https://citibanamex-api-cards.cfapps-gcg-gtdc1.citipaas-dev.dyn.nsroot.net/cards/serving/block");
      //  return $http.post('https://citibanamex-api-cards.cfapps-gcg-gtdc1.citipaas-dev.dyn.nsroot.net/cards/serving/block,cardObj) ;
        return $http.get('json/atmlist.json');

    };

    data.uncardblock=function(cardno) {
        console.log("Service call Un-block details");
        console.log(cardno);
        console.log("https://citibanamex-api-cards.cfapps-gcg-gtdc1.citipaas-dev.dyn.nsroot.net/cards/serving/"+cardno+"/unblock");
        //  return $http.post('https://citibanamex-api-cards.cfapps-gcg-gtdc1.citipaas-dev.dyn.nsroot.net/cards/serving/block,cardObj) ;
        return $http.get('json/atmlist.json');

    };



		data.nearbyatms=function(facilitytype,radius,address) {
		console.log("Service call block details 2");
		console.log('http://localhost:8080/v1/banamex/atms/nearby?radius='+radius+'&address='+address);
			//return $http.get('http://citibanamex-api-atm-locator.mybluemix.net/v1/banamex/atms/nearby?radius=1000&address=bosque+de+duraznos+78+Mexico+city');
			var servicename="";
			if(facilitytype==="atm") servicename="atms";
            if(facilitytype==="bank") servicename="branches";
            if(facilitytype==="atm|bank") servicename="atmsandbranches";

console.log('http://citibanamex-api-atm-locator.mybluemix.net/v1/banamex/'+servicename+'/nearby?type='+facilitytype+'&radius='+radius+'&addressLine1='+address);
	//	return $http.get('http://citibanamex-api-atm-locator.mybluemix.net/v1/banamex/atms/nearby?radius='+radius+'&addressLine1='+address) ;
			return $http.get('https://atmlocator.cfapps.io/v1/banamex/'+servicename+'/nearby?&radius='+radius+'&addressLine1='+address);
			//return $http.get('json/atmlist.json');
				
	};
	
	
	console.log("Service data");
	console.log(data);
	return data;

}]);