// create the controller and inject Angular's $scope
	citiApp.controller('itenaryController', ['$scope','cardlistService','$route','$interval','$timeout',function($scope,cardlistService,$route,$interval,$timeout) {
			// create a message to display in our view

        cardlistService.itenarylist().success(function(data) {

            $scope.itenarylist=data.itenarylist;
            console.log("return data detail ");
            console.log(data);

            gethrs();
            $interval(gethrs,1000);

             function gethrs() {

            angular.forEach($scope.itenarylist, function(itenaryitem, key) {
                if(itenaryitem.timerforunlock>0 ){
                    itenaryitem.timerforunlock=itenaryitem.timerforunlock-1;
                }else {
                    if(itenaryitem.cardblock==false &&(itenaryitem.loadimage == false) && itenaryitem.loopend==true) {
                    itenaryitem.cardblock=true;
                    itenaryitem.loadimage = true;
                    $timeout(function () { itenaryitem.loadimage = false; }, 5000);
                    console.log("am in first loop");
                   }
                }
                if(itenaryitem.timerforlock>0){
                    itenaryitem.timerforlock=itenaryitem.timerforlock-1;
                }else {
                    if(itenaryitem.cardblock==true &&(itenaryitem.loadimage == false && itenaryitem.loopend==true)) {
                        itenaryitem.cardblock=false;
                        itenaryitem.loadimage = true;
                        $timeout(function () { itenaryitem.loadimage = false;itenaryitem.loopend=false; }, 5000);
                        console.log("am in second loop");
                    }
                    itenaryitem.cardblock=false;

                }

            });


        };
    });

	}]);

