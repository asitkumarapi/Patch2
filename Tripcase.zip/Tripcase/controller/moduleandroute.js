	// create the module and name it scotchApp
	var citiApp = angular.module('mycitiApp', ['ngRoute']);

	// configure our routes
	citiApp.config(function($routeProvider) {

		$routeProvider

			.when('/', {
				templateUrl : 'templates/loginpage.html',
				controller  : 'loginController'
			})
            .when('/cardbub', {
                templateUrl : 'templates/cardblockandunblock.html',
                controller  : 'itenaryController'
            })
			.when('/itenarylist', {
            templateUrl : 'templates/itenarylist.html',
            controller  : 'itenaryController'
     	   });

	});



